declare class PanelBg extends eui.Skin{
}
declare class PanelPopBg extends eui.Skin{
}
declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class BuyGoodItemSkin extends eui.Skin{
}
declare class CertificationSkin extends eui.Skin{
}
declare class DividendItemSkin extends eui.Skin{
}
declare class DividendSkin extends eui.Skin{
}
declare class DownLoadSkin extends eui.Skin{
}
declare class ExchangeItemSkin extends eui.Skin{
}
declare class ExchangeSkin extends eui.Skin{
}
declare class HelpMainSkin extends eui.Skin{
}
declare class HelpTipSkin extends eui.Skin{
}
declare class InjectListItemSkin extends eui.Skin{
}
declare class InjectListSkin extends eui.Skin{
}
declare class InjectLogItemSkin extends eui.Skin{
}
declare class InjectSkin extends eui.Skin{
}
declare class InviteCodeItemSkin extends eui.Skin{
}
declare class InviteCodeSkin extends eui.Skin{
}
declare class Mainui extends eui.Skin{
}
declare class MineIDSkin extends eui.Skin{
}
declare class MineKADLogItemSkin extends eui.Skin{
}
declare class MinePassSkin extends eui.Skin{
}
declare class MoneyLogItemSkin extends eui.Skin{
}
declare class MoneyLogSkin extends eui.Skin{
}
declare class PanelModuleDemo extends eui.Skin{
}
declare class PetItemSkin extends eui.Skin{
}
declare class PetViewSkin extends eui.Skin{
}
declare class PriceSkin extends eui.Skin{
}
declare class PromptInputSkin extends eui.Skin{
}
declare class PromptSkin extends eui.Skin{
}
declare class ShopItemSkin extends eui.Skin{
}
declare class ShopSkin extends eui.Skin{
}
declare class USDTLogItemSkin extends eui.Skin{
}
declare class USDTLogVSkin extends eui.Skin{
}
declare class CheckBoxLoginSkin extends eui.Skin{
}
declare class CommonTipSkin extends eui.Skin{
}
declare class DisConnectSkin extends eui.Skin{
}
declare class GameLoadingProgressBarSkin extends eui.Skin{
}
declare class GameLoadingViewSkin extends eui.Skin{
}
declare class LoginViewSkin extends eui.Skin{
}
declare class ServerListTextInputSkin extends eui.Skin{
}
