class MainAfterLogin extends eui.UILayer {
	
    protected createChildren(): void
    {
		
	}
}