module qmr
{
	export class BaseModel extends BaseNotify
	{
        public constructor() {
            super();
        }
	}
}