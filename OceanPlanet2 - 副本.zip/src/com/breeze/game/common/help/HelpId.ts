module qmr {
    export class HelpId {

            /** 兑换面板帮助说明*/
            public static ID_1 = 1;
            /** 兑换面板帮助说明*/
            public static ID_2 = 2;
            /** 兑换面板帮助说明*/
            public static ID_3 = 3;
            /** 兑换面板帮助说明*/
            public static ID_4 = 4;
            /** 兑换面板帮助说明*/
            public static ID_5 = 5;
            /** 兑换面板帮助说明*/
            public static ID_6 = 6;
            
    }
}