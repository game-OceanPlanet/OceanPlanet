module qmr{
    export class DataManager
    {
        public constructor ()
        {
            
        }
    }
}