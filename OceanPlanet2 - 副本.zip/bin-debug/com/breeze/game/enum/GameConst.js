//货币常量
var CoinType;
(function (CoinType) {
    /**金币*/
    CoinType[CoinType["JINBI"] = 1] = "JINBI";
    /**元宝*/
})(CoinType || (CoinType = {}));
//战斗特效播放位置,UI层特效无需此值
var EffectPosition;
(function (EffectPosition) {
    EffectPosition[EffectPosition["CARD_BOTTOM"] = 0] = "CARD_BOTTOM";
    EffectPosition[EffectPosition["CARD_OVER"] = 1] = "CARD_OVER";
    EffectPosition[EffectPosition["CARD_FRONT"] = 2] = "CARD_FRONT";
    EffectPosition[EffectPosition["CARD_TOP"] = 3] = "CARD_TOP";
})(EffectPosition || (EffectPosition = {}));
//角色类型
var ActorType;
(function (ActorType) {
    ActorType[ActorType["HERO"] = 0] = "HERO";
    ActorType[ActorType["MONSTER"] = 1] = "MONSTER";
    ActorType[ActorType["BOSS"] = 2] = "BOSS";
    ActorType[ActorType["DROP"] = 3] = "DROP"; //掉落物
})(ActorType || (ActorType = {}));
//技能动作类型
var SkillActionType;
(function (SkillActionType) {
    SkillActionType[SkillActionType["ACTION_1"] = 1] = "ACTION_1";
    SkillActionType[SkillActionType["ACTION_2"] = 2] = "ACTION_2";
    SkillActionType[SkillActionType["ACTION_3"] = 3] = "ACTION_3";
    SkillActionType[SkillActionType["ACTION_4"] = 4] = "ACTION_4";
    SkillActionType[SkillActionType["ACTION_5"] = 5] = "ACTION_5";
    SkillActionType[SkillActionType["ACTION_6"] = 6] = "ACTION_6";
    SkillActionType[SkillActionType["ACTION_7"] = 7] = "ACTION_7";
    SkillActionType[SkillActionType["ACTION_8"] = 8] = "ACTION_8";
    SkillActionType[SkillActionType["ACTION_9"] = 9] = "ACTION_9";
    SkillActionType[SkillActionType["ACTION_10"] = 10] = "ACTION_10";
    SkillActionType[SkillActionType["ACTION_11"] = 11] = "ACTION_11";
    SkillActionType[SkillActionType["ACTION_12"] = 12] = "ACTION_12";
    SkillActionType[SkillActionType["ACTION_13"] = 13] = "ACTION_13";
})(SkillActionType || (SkillActionType = {}));
//敌我阵营
var CampType;
(function (CampType) {
    CampType[CampType["FOE"] = 0] = "FOE";
    CampType[CampType["OUR"] = 1] = "OUR";
})(CampType || (CampType = {}));
//特效常量
var EffectConst;
(function (EffectConst) {
    EffectConst[EffectConst["ACTOR_DIE_EFFECT"] = 3007] = "ACTOR_DIE_EFFECT";
    EffectConst[EffectConst["VICOTYR_EFFECT"] = 8027] = "VICOTYR_EFFECT";
    EffectConst[EffectConst["HALO_SHUI"] = 100] = "HALO_SHUI";
    EffectConst[EffectConst["HALO_SHUIDI"] = 101] = "HALO_SHUIDI";
    EffectConst[EffectConst["CHANGE_HERO_EFFECT"] = 102] = "CHANGE_HERO_EFFECT";
    EffectConst[EffectConst["CARD_QUALITY_EFFECT_6000"] = 6000] = "CARD_QUALITY_EFFECT_6000";
    EffectConst[EffectConst["CARD_QUALITY_EFFECT_6001"] = 6001] = "CARD_QUALITY_EFFECT_6001";
    EffectConst[EffectConst["CARD_QUALITY_EFFECT_6002"] = 6002] = "CARD_QUALITY_EFFECT_6002";
    EffectConst[EffectConst["CARD_QUALITY_EFFECT_6005"] = 6005] = "CARD_QUALITY_EFFECT_6005";
    EffectConst[EffectConst["CARD_QUALITY_EFFECT_6006"] = 6006] = "CARD_QUALITY_EFFECT_6006";
    EffectConst[EffectConst["HALO_SKILL_6006"] = 6006] = "HALO_SKILL_6006";
    EffectConst[EffectConst["HALO_SKILL_6007"] = 6007] = "HALO_SKILL_6007";
    EffectConst[EffectConst["hang_skill_13004"] = 13004] = "hang_skill_13004";
    EffectConst[EffectConst["hang_skill_13005"] = 13005] = "hang_skill_13005";
    EffectConst[EffectConst["hang_skill_13006"] = 13006] = "hang_skill_13006";
    EffectConst[EffectConst["hang_skill_13007"] = 13007] = "hang_skill_13007";
    EffectConst[EffectConst["hang_skill_13008"] = 13008] = "hang_skill_13008";
    EffectConst[EffectConst["hang_skill_13009"] = 13009] = "hang_skill_13009";
    /** 。。。。。。。。。。以下暂未用到。。。。。。 */
    EffectConst[EffectConst["BIG_SELECT_EFFECT"] = 40107] = "BIG_SELECT_EFFECT";
    EffectConst[EffectConst["AUTO_FIGHT_EFFECT"] = 8001] = "AUTO_FIGHT_EFFECT";
    EffectConst[EffectConst["SMALL_SELECT_EFFECT"] = 40106] = "SMALL_SELECT_EFFECT";
    EffectConst[EffectConst["LEVELUP_EFFECT"] = 8002] = "LEVELUP_EFFECT";
    EffectConst[EffectConst["CLICK_EFFECT"] = 8003] = "CLICK_EFFECT";
    EffectConst[EffectConst["TASK_COMPLETE_EFFECT"] = 8004] = "TASK_COMPLETE_EFFECT";
    EffectConst[EffectConst["MELT_EFFECT"] = 8005] = "MELT_EFFECT";
    EffectConst[EffectConst["STRENGTH_EFFECT"] = 8051] = "STRENGTH_EFFECT";
    EffectConst[EffectConst["UPSTAR_EFFECT"] = 8051] = "UPSTAR_EFFECT";
    EffectConst[EffectConst["JINGJIE_EFFECT"] = 8051] = "JINGJIE_EFFECT";
    EffectConst[EffectConst["UP_PING_EFFECT"] = 8051] = "UP_PING_EFFECT";
    EffectConst[EffectConst["SKILL_ADD_EFFECT"] = 8021] = "SKILL_ADD_EFFECT";
    EffectConst[EffectConst["SKILL_UPGRADE"] = 8022] = "SKILL_UPGRADE";
    EffectConst[EffectConst["TASK_AWARD_EFFECT"] = 8023] = "TASK_AWARD_EFFECT";
    EffectConst[EffectConst["TASK_CLICK_EFFECT"] = 8024] = "TASK_CLICK_EFFECT";
    EffectConst[EffectConst["BOX_AWARD_EFFECT"] = 8025] = "BOX_AWARD_EFFECT";
    EffectConst[EffectConst["ICON_SELECT_EFFECT"] = 8026] = "ICON_SELECT_EFFECT";
    EffectConst[EffectConst["GREEN_HANDER"] = 8028] = "GREEN_HANDER";
    EffectConst[EffectConst["TASK_DONE"] = 8029] = "TASK_DONE";
    EffectConst[EffectConst["TOUCH_BTN"] = 8030] = "TOUCH_BTN";
    EffectConst[EffectConst["CANTOUCH_EFFECT"] = 8031] = "CANTOUCH_EFFECT";
    EffectConst[EffectConst["PRESENTGIFT_EFFECT"] = 8032] = "PRESENTGIFT_EFFECT";
    EffectConst[EffectConst["GOLD_EFFECT"] = 8033] = "GOLD_EFFECT";
    EffectConst[EffectConst["PETALSFLY_EFFECT"] = 8034] = "PETALSFLY_EFFECT";
    EffectConst[EffectConst["BEAUTYFIT_EFFECT"] = 8035] = "BEAUTYFIT_EFFECT";
    EffectConst[EffectConst["MARTIAL_EFFECT"] = 8040] = "MARTIAL_EFFECT";
    EffectConst[EffectConst["TAOBAO_WEAPON1"] = 8041] = "TAOBAO_WEAPON1";
    EffectConst[EffectConst["TAOBAO_WEAPON2"] = 8042] = "TAOBAO_WEAPON2";
    EffectConst[EffectConst["TAOBAO_WEAPON3"] = 8043] = "TAOBAO_WEAPON3";
    EffectConst[EffectConst["PROGRESS_EFFECT"] = 8044] = "PROGRESS_EFFECT";
    EffectConst[EffectConst["CAVALRY_EFFECT"] = 8045] = "CAVALRY_EFFECT";
    EffectConst[EffectConst["INTERACTION_EFFECT"] = 8046] = "INTERACTION_EFFECT";
    EffectConst[EffectConst["SKILL_SINGLE_UP"] = 8047] = "SKILL_SINGLE_UP";
    EffectConst[EffectConst["BEAUTY_LIKE_EFFECT"] = 8048] = "BEAUTY_LIKE_EFFECT";
    EffectConst[EffectConst["ANSWER_EFFECT"] = 8049] = "ANSWER_EFFECT";
    EffectConst[EffectConst["INTERACTION_OPERA_EFFECT"] = 8050] = "INTERACTION_OPERA_EFFECT";
    EffectConst[EffectConst["STONE_EFFECT"] = 8051] = "STONE_EFFECT";
    EffectConst[EffectConst["TURNSTAR_EFFECT"] = 8052] = "TURNSTAR_EFFECT";
    EffectConst[EffectConst["RELIVE_EFFECT"] = 9009] = "RELIVE_EFFECT"; //复活特效
})(EffectConst || (EffectConst = {}));
//颜色值常量
var ColorConst;
(function (ColorConst) {
    ColorConst[ColorConst["COLOR_WHITE"] = 16777215] = "COLOR_WHITE";
    ColorConst[ColorConst["COLOR_BLACK"] = 0] = "COLOR_BLACK";
    ColorConst[ColorConst["COLOR_VIOLET"] = 16711935] = "COLOR_VIOLET";
    ColorConst[ColorConst["COLOR_PURPLE"] = 10494192] = "COLOR_PURPLE";
    ColorConst[ColorConst["COLOR_GREEN"] = 65280] = "COLOR_GREEN";
    ColorConst[ColorConst["COLOR_CADMIUM"] = 16748544] = "COLOR_CADMIUM";
    ColorConst[ColorConst["COLOR_RED"] = 16711680] = "COLOR_RED";
    ColorConst[ColorConst["COLOR_BLUE"] = 2263550] = "COLOR_BLUE";
    ColorConst[ColorConst["COLOR_SKILL"] = 65535] = "COLOR_SKILL";
    //游戏用到颜色枚举
    ColorConst[ColorConst["COMMON_GREEN"] = 370701] = "COMMON_GREEN";
    ColorConst[ColorConst["COMMON_GREEN2"] = 1542471] = "COMMON_GREEN2";
    ColorConst[ColorConst["COMMON_BROWN"] = 5910059] = "COMMON_BROWN";
    ColorConst[ColorConst["COMMON_BULE"] = 4758466] = "COMMON_BULE";
    ColorConst[ColorConst["COMMON_YELLOW"] = 16710804] = "COMMON_YELLOW";
    ColorConst[ColorConst["COMMON_BR"] = 8404743] = "COMMON_BR";
    ColorConst[ColorConst["COMMON_BR2"] = 9595719] = "COMMON_BR2";
    ColorConst[ColorConst["COMMON_ORANGE"] = 15684864] = "COMMON_ORANGE";
    ColorConst[ColorConst["COMMON_WHITE"] = 16777215] = "COMMON_WHITE";
    ColorConst[ColorConst["COMMON_RED"] = 14489856] = "COMMON_RED";
    ColorConst[ColorConst["COMMON_PURPLE"] = 9644225] = "COMMON_PURPLE";
    ColorConst[ColorConst["COMMON_BLUE1"] = 2857935] = "COMMON_BLUE1";
})(ColorConst || (ColorConst = {}));
//# sourceMappingURL=GameConst.js.map