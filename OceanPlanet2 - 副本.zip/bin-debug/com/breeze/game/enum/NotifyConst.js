var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var NotifyConst = (function () {
        function NotifyConst() {
        }
        NotifyConst.S_SYN_PROPERTY = "S_SYN_PROPERTY"; //全局属性更新
        NotifyConst.TAB_VIEW_GUIDE = "TAB_VIEW_GUIDE"; //TabView显示关闭引导
        NotifyConst.RED_HOT_UPDATE = "RED_HOT_UPDATE"; //红点系统更新通知
        NotifyConst.SELECT_ITEM_SELECTED = "SELECT_ITEM_SELECTED";
        NotifyConst.S_GET_FINSH_INFO = "S_GET_FINSH_INFO"; // 获取我的鱼儿
        NotifyConst.S_COMBINE_FINSH = "S_COMBINE_FINSH"; // 合并鱼儿
        NotifyConst.S_BUY_FISH = "S_BUY_FISH"; // 购买鱼儿
        NotifyConst.S_GET_MONEY_REWARD = "S_GET_MONEY_REWARD"; // 领取金币奖励
        NotifyConst.S_GET_MONEY_INFO = "S_GET_MONEY_INFO"; // 获取金币信息
        NotifyConst.S_GET_MONEY_LOG_LIST = "S_GET_MONEY_LOG_LIST";
        NotifyConst.S_GET_DIAMOND_LOG_LIST = "S_GET_DIAMOND_LOG_LIST";
        NotifyConst.S_DIAMOND_BUY_FISH = "S_DIAMOND_BUY_FISH";
        NotifyConst.S_GET_OCT_MARKET_INFO = "S_GET_OCT_MARKET_INFO";
        NotifyConst.S_MARKET_BUY = "S_MARKET_BUY";
        NotifyConst.S_MARKET_SELL = "S_MARKET_SELL";
        NotifyConst.S_MARKET_CANCEL = "S_MARKET_CANCEL";
        NotifyConst.S_GET_MONEY_EXCHANGE_INFO = "S_GET_MONEY_EXCHANGE_INFO";
        NotifyConst.S_MONEY_EXCHANGE_KAD = "S_MONEY_EXCHANGE_KAD";
        NotifyConst.S_GET_BONUS_INFO = "S_GET_BONUS_INFO";
        NotifyConst.S_INJECT_KAD = "S_INJECT_KAD";
        NotifyConst.S_GET_INJECT_INFO = "S_GET_INJECT_INFO";
        NotifyConst.ON_PET_SELECTED = "ON_PET_SELECTED";
        return NotifyConst;
    }());
    qmr.NotifyConst = NotifyConst;
    __reflect(NotifyConst.prototype, "qmr.NotifyConst");
})(qmr || (qmr = {}));
//# sourceMappingURL=NotifyConst.js.map