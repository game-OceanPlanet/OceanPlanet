var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ModuleNameConst = (function () {
        function ModuleNameConst() {
        }
        ModuleNameConst.PROMPT_VIEW = "qmr.PromptView";
        ModuleNameConst.PROMPT_INPUT_VIEW = "qmr.PromptInputView";
        ModuleNameConst.HELP_TIP_VIEW = "qmr.HelpTipView";
        ModuleNameConst.EXCHANGE_VIEW = "qmr.ExchangeView";
        ModuleNameConst.MAINUI_VIEW = "qmr.MainView"; //主ui模块
        ModuleNameConst.SHOP_VIEW = "qmr.ShopView"; //主ui模块
        ModuleNameConst.PET_VIEW = "qmr.PetView"; //主ui模块
        ModuleNameConst.GOLD_LOG_VIEW = "qmr.GoldLogView"; //主ui模块
        ModuleNameConst.USDT_LOG_VIEW = "qmr.USDTLogView"; //主ui模块
        ModuleNameConst.TRADE_VIEW = "qmr.TradeView";
        ModuleNameConst.INVITE_CODE_VIEW = "qmr.InviteCodeView";
        ModuleNameConst.INJECT_VIEW = "qmr.InjectView";
        ModuleNameConst.DIVIDEND_VIEW = "qmr.DividendView";
        ModuleNameConst.APP_DOWN_VIEW = "qmr.AppDownloadView";
        ModuleNameConst.MINE_PASSIED_VIEW = "qmr.MinePassIdView";
        ModuleNameConst.MINEID_VIEW = "qmr.MineIdView";
        ModuleNameConst.CERTIFICATION_VIEW = "qmr.CertificationView";
        ModuleNameConst.HELP_MAIN_VIEW = "qmr.HelpMain";
        return ModuleNameConst;
    }());
    qmr.ModuleNameConst = ModuleNameConst;
    __reflect(ModuleNameConst.prototype, "qmr.ModuleNameConst");
})(qmr || (qmr = {}));
//# sourceMappingURL=ModuleNameConst.js.map