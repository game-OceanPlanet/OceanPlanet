var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var MessageID = (function () {
        function MessageID() {
        }
        /** 游戏初始化调用 */
        MessageID.init = function () {
            var self = this;
            var id;
            for (var p in self) {
                id = self[p];
                self.MSG_KEYS.set(id, p);
            }
        };
        /** 通过本类的协议ID映射协议名字 */
        MessageID.getMsgNameById = function (id) {
            return MessageID.MSG_KEYS.get(id);
        };
        /**
         *
         * @author coler 2018.12.11
         * 消息ID自动生成，请勿修改
         *
         */
        /** 映射协议ID对应的协议名 */
        MessageID.MSG_KEYS = new qmr.Dictionary();
        MessageID.MSG_EMPTY = 0;
        /**  异常消息 */
        MessageID.S_EXCEPTION_MSG = 900;
        /**  登录 */
        MessageID.C_USER_LOGIN = 1001;
        /**  登录成功 */
        MessageID.S_USER_LOGIN = 1002;
        /**  被封禁提示 */
        MessageID.S_USER_LOGIN_BAN = 1003;
        /** 注册 */
        MessageID.C_LOGIN_REGISTER = 1005;
        /** 登出 */
        MessageID.C_USER_LOGOUT = 1007;
        MessageID.S_USER_LOGOUT = 1008;
        /**  登录注册完成请求 角色信息 */
        MessageID.C_USER_LOGIN_INIT_FINISH = 1009;
        /**  登录注册完成请求 角色信息 */
        MessageID.S_USER_LOGIN_INIT_FINISH = 1010;
        /**  客户端核查随机名字是否可以使用 */
        MessageID.C_GET_NICKNAME_INFO = 1030;
        MessageID.S_GET_NICKNAME_INFO = 1031;
        /**  客户端通知sdk上报数据操作 */
        MessageID.C_SEND_SDK_DATA = 1032;
        MessageID.S_SEND_SDK_DATA = 1033;
        /** 获取我的鱼儿 */
        MessageID.C_GET_FISH_INFO = 1051;
        MessageID.S_GET_FISH_INFO = 1052;
        /** 购买鱼儿 */
        MessageID.C_BUY_FISH = 1053;
        MessageID.S_BUY_FISH = 1054;
        /** 合并鱼儿 */
        MessageID.C_COMBINE_FISH = 1055;
        MessageID.S_COMBINE_FISH = 1056;
        /** 领取金币奖励 */
        MessageID.C_GET_MONEY_REWARD = 1057;
        MessageID.S_GET_MONEY_REWARD = 1058;
        /** 获取金币信息 */
        MessageID.C_GET_MONEY_INFO = 1059;
        MessageID.S_GET_MONEY_INFO = 1060;
        /**  U购买鱼 */
        MessageID.C_DIAMOND_BUY_FISH = 1061;
        MessageID.S_DIAMOND_BUY_FISH = 1062;
        /**  获取金币日志信息 */
        MessageID.C_GET_MONEY_LOG_LIST = 1063;
        MessageID.S_GET_MONEY_LOG_LIST = 1064;
        /**  获取U日志信息 */
        MessageID.C_GET_DIAMOND_LOG_LIST = 1065;
        MessageID.S_GET_DIAMOND_LOG_LIST = 1066;
        /** C->S 请求: 获取otc信息 */
        MessageID.C_GET_OCT_MARKET_INFO = 1101;
        MessageID.S_GET_OCT_MARKET_INFO = 1102;
        /** C->S 请求: 买入金币（挂单） */
        MessageID.C_MARKET_BUY = 1103;
        MessageID.S_MARKET_BUY = 1104;
        /** C->S 请求: 卖给Ta，获得U */
        MessageID.C_MARKET_SELL = 1105;
        MessageID.S_MARKET_SELL = 1106;
        /** C->S 请求: 撤单 */
        MessageID.C_MARKET_CANCEL = 1107;
        MessageID.S_MARKET_CANCEL = 1108;
        /** 获取兑换信息 */
        MessageID.C_GET_MONEY_EXCHANGE_INFO = 1201;
        MessageID.S_GET_MONEY_EXCHANGE_INFO = 1202;
        /** 金币兑换平台币KAD */
        MessageID.C_MONEY_EXCHANGE_KAD = 1203;
        MessageID.S_MONEY_EXCHANGE_KAD = 1204;
        /** 获取分红信息 */
        MessageID.C_GET_BONUS_INFO = 1205;
        MessageID.S_GET_BONUS_INFO = 1206;
        /** 获取注入信息 */
        MessageID.C_GET_INJECT_INFO = 1207;
        MessageID.S_GET_INJECT_INFO = 1208;
        /** 注入 */
        MessageID.C_INJECT_KAD = 1209;
        MessageID.S_INJECT_KAD = 1210;
        /**  实名验证 */
        MessageID.C_REAL_NAME_VERIFICATION = 1221;
        MessageID.S_REAL_NAME_VERIFICATION = 1222;
        /**  同步属性变化 */
        MessageID.S_SYN_PROPERTY = 2001;
        /** 同步时间 */
        MessageID.C_SYNC_TIME = 2101;
        /** 同步时间 */
        MessageID.S_SYNC_TIME = 2102;
        /** debug */
        MessageID.C_DEBUG_COMMON = 3101;
        MessageID.S_DEBUG_COMMON = 3102;
        /**  跨服服务器心跳 */
        MessageID.CROSS_C_HEART_BEAT = 100001;
        MessageID.CROSS_S_HEART_BEAT = 100002;
        /**  跨服服务器注册 */
        MessageID.CROSS_C_SERVER_REGISTER = 100003;
        MessageID.CROSS_S_SERVER_REGISTER = 100004;
        /** 跨服错误吗 */
        MessageID.CROSS_S_EXCEPTION_MSG = 100005;
        /**  跨服服务器注册成功推送消息 */
        MessageID.CROSS_C_SERVER_PUSH = 100006;
        MessageID.CROSS_S_SERVER_PUSH = 100007;
        /**  坑爹的协议，由于oss不支持跨服的http服务，暂时由游戏服的http接收后发送跨服处理 */
        MessageID.CROSS_C_HTTP_DATA = 100008;
        return MessageID;
    }());
    qmr.MessageID = MessageID;
    __reflect(MessageID.prototype, "qmr.MessageID");
})(qmr || (qmr = {}));
//# sourceMappingURL=MessageID.js.map