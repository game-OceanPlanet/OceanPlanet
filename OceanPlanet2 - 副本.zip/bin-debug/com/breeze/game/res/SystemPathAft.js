var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var SystemPathAft = (function () {
        function SystemPathAft() {
        }
        Object.defineProperty(SystemPathAft, "mapPath", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "map/";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SystemPathAft, "effectPath", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "effect/";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SystemPathAft, "headPath", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "icon/head/";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SystemPathAft, "uieffect", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "effect/ui/";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SystemPathAft, "bgPath", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "unpack/bg/";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SystemPathAft, "unpack_battle", {
            get: function () {
                return qmr.PlatformConfig.webRoot + "unpack/battle/";
            },
            enumerable: true,
            configurable: true
        });
        return SystemPathAft;
    }());
    qmr.SystemPathAft = SystemPathAft;
    __reflect(SystemPathAft.prototype, "qmr.SystemPathAft");
})(qmr || (qmr = {}));
//# sourceMappingURL=SystemPathAft.js.map