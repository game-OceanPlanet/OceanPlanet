var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ModuleManagerAft = (function () {
        function ModuleManagerAft() {
        }
        ModuleManagerAft.init = function () {
            this.setupClass();
        };
        ModuleManagerAft.setupClass = function () {
            var modulelManager = qmr.ModuleManager;
            modulelManager.registerClass(qmr.ModuleNameConst.PROMPT_VIEW, qmr.PromptView);
            modulelManager.registerClass(qmr.ModuleNameConst.PROMPT_INPUT_VIEW, qmr.PromptInputView);
            modulelManager.registerClass(qmr.ModuleNameConst.HELP_TIP_VIEW, qmr.HelpTipView);
            modulelManager.registerClass(qmr.ModuleNameConst.MAINUI_VIEW, qmr.MainView);
            modulelManager.registerClass(qmr.ModuleNameConst.SHOP_VIEW, qmr.ShopView);
            modulelManager.registerClass(qmr.ModuleNameConst.PET_VIEW, qmr.PetView);
            modulelManager.registerClass(qmr.ModuleNameConst.GOLD_LOG_VIEW, qmr.GoldLogView);
            modulelManager.registerClass(qmr.ModuleNameConst.USDT_LOG_VIEW, qmr.USDTLogView);
            modulelManager.registerClass(qmr.ModuleNameConst.TRADE_VIEW, qmr.TradeView);
            modulelManager.registerClass(qmr.ModuleNameConst.EXCHANGE_VIEW, qmr.ExchangeView);
            modulelManager.registerClass(qmr.ModuleNameConst.INVITE_CODE_VIEW, qmr.InviteCodeView);
            modulelManager.registerClass(qmr.ModuleNameConst.INJECT_VIEW, qmr.InjectView);
            modulelManager.registerClass(qmr.ModuleNameConst.DIVIDEND_VIEW, qmr.DividendView);
            modulelManager.registerClass(qmr.ModuleNameConst.APP_DOWN_VIEW, qmr.AppDownloadView);
            modulelManager.registerClass(qmr.ModuleNameConst.MINE_PASSIED_VIEW, qmr.MinePassIdView);
            modulelManager.registerClass(qmr.ModuleNameConst.MINEID_VIEW, qmr.MineIdView);
            modulelManager.registerClass(qmr.ModuleNameConst.CERTIFICATION_VIEW, qmr.CertificationView);
            modulelManager.registerClass(qmr.ModuleNameConst.HELP_MAIN_VIEW, qmr.HelpMain);
        };
        return ModuleManagerAft;
    }());
    qmr.ModuleManagerAft = ModuleManagerAft;
    __reflect(ModuleManagerAft.prototype, "qmr.ModuleManagerAft");
})(qmr || (qmr = {}));
//# sourceMappingURL=ModuleManagerAft.js.map