var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @description 所有模块的基类
     *
     */
    var BaseModule = (function (_super) {
        __extends(BaseModule, _super);
        function BaseModule() {
            return _super.call(this) || this;
        }
        /** 初始化事件 */
        BaseModule.prototype.initListener = function () {
            var t = this;
            t.registerNotify(qmr.StageUtil.STAGE_RESIZE, t.onStageResize, t);
            t.registerNotify(qmr.NotifyConstLogin.CLOSE_PANEL_LAYER, t.onTabViewGuide, t);
            t.registerNotify(qmr.NotifyConst.TAB_VIEW_GUIDE, t.onTabViewGuide, t);
            var btn_return = t["btnReturn"];
            if (btn_return) {
                t.addClickEvent(btn_return, t.onPageBgCloseView, t);
            }
            var btn_close = t["btnClose"];
            if (btn_close) {
                t.addClickEvent(btn_close, t.onPageBgCloseView, t);
            }
            var btn_help = t["btn_help"];
            if (btn_help) {
                t.addClickEvent(btn_help, t.showHelpView, t);
            }
            _super.prototype.initListener.call(this);
        };
        BaseModule.prototype.initData = function () {
            _super.prototype.initData.call(this);
            this.updateTitle(this.title, this.ruleId);
        };
        BaseModule.prototype.onTabViewGuide = function () {
            var t = this;
        };
        BaseModule.prototype.showHelpView = function () {
            var t = this;
            if (!t.helpId) {
                return;
            }
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.HELP_TIP_VIEW, t.helpId);
        };
        return BaseModule;
    }(qmr.SuperBaseModule));
    qmr.BaseModule = BaseModule;
    __reflect(BaseModule.prototype, "qmr.BaseModule");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseModule.js.map