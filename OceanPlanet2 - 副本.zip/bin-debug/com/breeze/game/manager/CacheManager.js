var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var CacheManager = (function () {
        function CacheManager() {
        }
        /** 获取目标缓存值，defValue为没有缓存时的默认值，支持number,string两种数据类型 */
        CacheManager.getCache = function (key, defValue) {
            if (defValue === void 0) { defValue = null; }
            var value = egret.localStorage.getItem(CacheManager.CACHE_GAME_KEY + key);
            if (value != undefined) {
                if (typeof defValue === "string") {
                    return value;
                }
                else if (typeof defValue === "number") {
                    return parseInt(value);
                }
                else if (typeof defValue === "boolean") {
                    return value == "true";
                }
            }
            else {
                return defValue;
            }
        };
        /** 本地永久缓存 */
        CacheManager.setCache = function (key, value) {
            egret.localStorage.setItem(CacheManager.CACHE_GAME_KEY + key, value);
        };
        /** 本次登录缓存 */
        CacheManager.setOneCache = function (key, value) {
            CacheManager.CACHE_DIC[key] = value;
        };
        /** 获取本次登录缓存 */
        CacheManager.getOneCache = function (key, defValue) {
            if (defValue === void 0) { defValue = null; }
            var value = CacheManager.CACHE_DIC[key];
            if (value != undefined) {
                if (typeof defValue === "string") {
                    return value;
                }
                else if (typeof defValue === "number") {
                    return parseInt(value);
                }
                else {
                    return value;
                }
            }
            else {
                return defValue;
            }
        };
        CacheManager.CACHE_GAME_KEY = "guangmang.keji.mt.";
        CacheManager.CACHE_DIC = {};
        return CacheManager;
    }());
    qmr.CacheManager = CacheManager;
    __reflect(CacheManager.prototype, "qmr.CacheManager");
})(qmr || (qmr = {}));
//# sourceMappingURL=CacheManager.js.map