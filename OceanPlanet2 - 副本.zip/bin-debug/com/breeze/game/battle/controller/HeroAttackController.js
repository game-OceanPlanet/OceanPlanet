var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author hh
     * @date 2016.12.08
     * @description 英雄攻击控制器,技能全部是自动释放
     *
     */
    var HeroAttackController = (function (_super) {
        __extends(HeroAttackController, _super);
        function HeroAttackController(moverActor) {
            var _this = _super.call(this, moverActor) || this;
            _this.lastUseTime = 0;
            return _this;
        }
        /**
         * @description 执行此控制器,根据不同技能实现不同效果，这里需要重写
         */
        HeroAttackController.prototype.excute = function () {
            this.attackSpeed = 0;
            if (this.moverActor) {
                this.moverActor.onPlayAtk();
            }
        };
        /**
         * @description 取消执行此控制器,需被子类继承
         */
        HeroAttackController.prototype.cancelExcute = function () {
        };
        /**
         * @description 清除controller,需要被子类继承
         */
        HeroAttackController.prototype.clearController = function () {
        };
        return HeroAttackController;
    }(qmr.BaseMoverActorController));
    qmr.HeroAttackController = HeroAttackController;
    __reflect(HeroAttackController.prototype, "qmr.HeroAttackController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroAttackController.js.map