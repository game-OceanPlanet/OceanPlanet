var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author coler
     * @description 施法控制器
     *
     */
    var HeroSkillController = (function (_super) {
        __extends(HeroSkillController, _super);
        function HeroSkillController(moverActor) {
            return _super.call(this, moverActor) || this;
        }
        /**
         * @description 执行此控制器
         */
        HeroSkillController.prototype.excute = function () {
            if (this.moverActor) {
                this.moverActor.onPlayCast();
            }
        };
        /**
         * @description 取消执行此控制器,需被子类继承
         */
        HeroSkillController.prototype.cancelExcute = function () {
        };
        return HeroSkillController;
    }(qmr.BaseMoverActorController));
    qmr.HeroSkillController = HeroSkillController;
    __reflect(HeroSkillController.prototype, "qmr.HeroSkillController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroSkillController.js.map