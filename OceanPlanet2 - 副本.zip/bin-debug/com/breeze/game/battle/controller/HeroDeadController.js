var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author hh
     * @date 2016.12.08
     * @description 死亡控制器
     *
     */
    var HeroDeadController = (function (_super) {
        __extends(HeroDeadController, _super);
        function HeroDeadController(moverActor) {
            return _super.call(this, moverActor) || this;
        }
        HeroDeadController.prototype.excute = function () {
            if (this.moverActor) {
                this.moverActor.onPlayDead();
            }
        };
        HeroDeadController.prototype.cancelExcute = function () {
        };
        return HeroDeadController;
    }(qmr.BaseMoverActorController));
    qmr.HeroDeadController = HeroDeadController;
    __reflect(HeroDeadController.prototype, "qmr.HeroDeadController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroDeadController.js.map