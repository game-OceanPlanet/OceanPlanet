var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author coler
     * @description 待机状态
     */
    var HeroIdleController = (function (_super) {
        __extends(HeroIdleController, _super);
        function HeroIdleController(moverActor) {
            return _super.call(this, moverActor) || this;
        }
        HeroIdleController.prototype.check = function () {
            if (this.moverActor) {
                this.moverActor.onMoveStop();
            }
        };
        HeroIdleController.prototype.excute = function () {
            if (this.moverActor) {
                this.moverActor.onPlayIdle();
            }
        };
        return HeroIdleController;
    }(qmr.BaseMoverActorController));
    qmr.HeroIdleController = HeroIdleController;
    __reflect(HeroIdleController.prototype, "qmr.HeroIdleController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroIdleController.js.map