var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author coler
     * @description 飞行状态
     */
    var HeroFlyController = (function (_super) {
        __extends(HeroFlyController, _super);
        function HeroFlyController(moverActor) {
            return _super.call(this, moverActor) || this;
        }
        HeroFlyController.prototype.excute = function () {
            if (this.moverActor) {
                this.moverActor.pause();
            }
        };
        HeroFlyController.prototype.cancelExcute = function () {
            if (this.moverActor) {
                this.moverActor.onPlayIdle();
            }
        };
        return HeroFlyController;
    }(qmr.BaseMoverActorController));
    qmr.HeroFlyController = HeroFlyController;
    __reflect(HeroFlyController.prototype, "qmr.HeroFlyController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroFlyController.js.map