var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var SkillModel = (function () {
        function SkillModel() {
            this._skillDic = {};
            this._skillEffectDic = {};
            this._skillUpEffectDic = {};
            this._passiveSkillDic = {};
        }
        Object.defineProperty(SkillModel, "instance", {
            get: function () {
                if (this._instance == null) {
                    this._instance = new SkillModel;
                }
                return this._instance;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *  技能数据
         */
        SkillModel.prototype.getSkillCfg = function (id) {
            if (!isNaN(id) && id > 0) {
                if (this._skillDic.hasOwnProperty(id.toString())) {
                    return this._skillDic[id];
                }
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.SKILL, id);
                if (cfg != null)
                    this._skillDic[id] = cfg;
                return cfg;
            }
            qmr.LogUtil.log("技能数据不存在：" + id);
            return null;
        };
        /** 通过技能ID获得技能效果 */
        SkillModel.prototype.getSkillEffectDataBySkillId = function (skill_id) {
            var skillData = this.getSkillCfg(skill_id);
            if (skillData) {
                return this.getSkillEffectData(skillData.effectId);
            }
            return null;
        };
        /**
         * 通过技能效果ID获得技能效果
         */
        SkillModel.prototype.getSkillEffectData = function (id) {
            if (!isNaN(id) && id > 0) {
                if (this._skillEffectDic.hasOwnProperty(id.toString())) {
                    return this._skillEffectDic[id];
                }
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.SKILLEFFECT, id);
                if (cfg != null)
                    this._skillEffectDic[id] = cfg;
                return cfg;
            }
            return null;
        };
        /** 多段伤害 */
        SkillModel.prototype.getMultiDatas = function (mult) {
            var mulits = mult.split(";");
            var max = 0;
            var mulitRates = [];
            var muStr;
            var rate;
            var count = mulits.length;
            for (var i = 0; i < count; i++) {
                rate = new MultiRateVo();
                muStr = mulits[i];
                if (muStr) {
                    var rates = muStr.split(",").map(Number);
                    rate.time = rates[0];
                    rate.sp = rates[1];
                    max += rate.sp;
                }
                mulitRates.push(rate);
            }
            mulitRates.forEach(function (element) {
                element.updateRate(max);
            });
            return mulitRates;
        };
        return SkillModel;
    }());
    qmr.SkillModel = SkillModel;
    __reflect(SkillModel.prototype, "qmr.SkillModel");
    /** 多段伤害占比 */
    var MultiRateVo = (function () {
        function MultiRateVo() {
        }
        /** 更新占比 */
        MultiRateVo.prototype.updateRate = function (max) {
            this.rate = this.sp / max;
        };
        return MultiRateVo;
    }());
    qmr.MultiRateVo = MultiRateVo;
    __reflect(MultiRateVo.prototype, "qmr.MultiRateVo");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillModel.js.map