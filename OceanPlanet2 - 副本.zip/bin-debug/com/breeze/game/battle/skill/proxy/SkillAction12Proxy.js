var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (12)远程，播放一个弹道效果从己方外面，飞行到对面界面外
     */
    var SkillAction12Proxy = (function (_super) {
        __extends(SkillAction12Proxy, _super);
        function SkillAction12Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.tempTargetList = [];
            _this.dropPos = {};
            _this.flyCount = 0;
            return _this;
        }
        SkillAction12Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction12Proxy", SkillAction12Proxy);
            return proxy;
        };
        SkillAction12Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction12Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction12Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction12Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction12Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                //群体同时播放特效
                if (this.targetList && this.targetList.length > 0) {
                    var targetActor = this.targetList[0];
                    if (targetActor) {
                        // LogUtil.warn("施法了 " + this.flyCount)
                        var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, this.owner, -1, this.timeScale);
                        if (effect) {
                            var starPos = void 0; // = BattlePosionManager.instance.getSkill12PosByType(this.owner.camp, true);
                            var endPos = void 0; // = BattlePosionManager.instance.getSkill12PosByType(targetActor.camp);
                            starPos.x = endPos.x;
                            var dx = 0;
                            var dy = endPos.y - starPos.y;
                            effect.x = starPos.x;
                            effect.y = starPos.y;
                            var effCfg = qmr.SkillModel.instance.getSkillEffectDataBySkillId(this.skillId);
                            effect.speed = effCfg ? effCfg.speed * this.timeScale : 30;
                            effect.rotation = Math.atan2(dy, dx) * 180 / Math.PI;
                            var onArrival = this.onArrival;
                            effect.moveTo(endPos.x, endPos.y, this.onArrival, this);
                            this.addTempEffect(effect);
                            //如果特效没返回到达目的地，去找一下特效表里面，特效配置的播放次数是否满足到达时间
                        }
                        else {
                            qmr.LogUtil.warn("表现特效不存在，需要策划在（特效_EffectData表格）里面配置一下 " + this.skillEffectCfg.show_effect);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能11：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
                qmr.LogUtil.logF("群体同时播放特效 " + this.targetList.length);
            }
            this.delayShowHit();
        };
        /** 到达目标地点 */
        SkillAction12Proxy.prototype.onArrival = function (argArray) {
            qmr.LogUtil.logF("群体同时播放特效");
            this.removeAllTempEffect();
        };
        SkillAction12Proxy.prototype.delayShowHit = function () {
            var show_time = this.skillEffectCfg.show_time / this.timeScale;
            if (show_time > 0) {
                qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
                qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
            }
            else {
                this.onShowHitEffect();
            }
        };
        /** 表现特效播放完毕后 */
        SkillAction12Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            while (this.targetList.length > 0) {
                this.flyCount--;
                //群体同时受击
                var targetActor = this.targetList.pop();
                if (this.skillEffectCfg.hit_effect > 0) {
                    if (targetActor) {
                        if (this.owner) {
                            qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                        }
                        else {
                            qmr.LogUtil.warn("技能11：施法者不存在，这个问题很严重，技能id:" + this.skillId);
                        }
                        var targetFighterMsg = this.getFightMsg(targetActor.id);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, targetFighterMsg);
                    }
                    else {
                        qmr.LogUtil.warn("技能11：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
                qmr.LogUtil.logF("群体同时受击 " + this.flyCount);
            }
            // 避免有点远程特效还没飞到目标位置就结束了，不飘受击特效了。。。
            var delay = 300;
            delay /= this.timeScale;
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, delay, 1);
        };
        SkillAction12Proxy.prototype.getFightMsg = function (id) {
            if (!this.targetFighterMsg)
                return null;
            for (var _i = 0, _a = this.targetFighterMsg; _i < _a.length; _i++) {
                var t = _a[_i];
                if (t.fighterId == id) {
                    return t;
                }
            }
            return null;
        };
        /**  本轮技能释放完毕 */
        SkillAction12Proxy.prototype.onPlayEnd = function () {
            qmr.LogUtil.logF("本轮技能释放完毕 " + this.flyCount);
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction12Proxy.prototype.recycleSkill = function () {
            this.flyCount = 0;
            this.targetList.length = 0;
            this.tempTargetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction12Proxy.recovrySkillProxy(this);
        };
        return SkillAction12Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction12Proxy = SkillAction12Proxy;
    __reflect(SkillAction12Proxy.prototype, "qmr.SkillAction12Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction12Proxy.js.map