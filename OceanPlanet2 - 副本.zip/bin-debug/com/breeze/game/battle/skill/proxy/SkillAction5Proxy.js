var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (4)远程，天降技能，中心受击之后，外网再次受击
     */
    var SkillAction5Proxy = (function (_super) {
        __extends(SkillAction5Proxy, _super);
        function SkillAction5Proxy() {
            var _this = _super.call(this) || this;
            _this.delayTime = 500; //延迟之后，外围再受击
            _this.targetList = [];
            _this.dropPos = {};
            return _this;
        }
        SkillAction5Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction5Proxy", SkillAction5Proxy);
            return proxy;
        };
        SkillAction5Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction5Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction5Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction5Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                //添加施法效果
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction5Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                var targetActor = this.targetList[0];
                var targetState = this.targetFighterMsg[0];
                if (targetActor) {
                    this.showEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, targetActor, -1, targetActor.timeScale, true);
                    //表现持续时间
                    var showDurotion = this.skillEffectCfg.show_durotion / this.timeScale;
                    if (showDurotion > 0) {
                        qmr.FightTimer.instance.registerTick(this.removeShowEffect, this, showDurotion, 1);
                    }
                }
                else {
                    qmr.LogUtil.warn("目标不存在了？？？技能id:" + this.skillId);
                }
                //外围延迟
                qmr.FightTimer.instance.registerTick(this.delayShowEffect, this, this.delayTime / this.timeScale, 1);
            }
            var show_time = this.skillEffectCfg.show_time / this.timeScale;
            if (show_time > 0) {
                qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
            }
            else {
                this.onShowHitEffect();
            }
        };
        SkillAction5Proxy.prototype.delayShowEffect = function () {
            if (this.targetList.length > 1) {
                var count = this.targetList.length;
                for (var i = 1; i < count; i++) {
                    if (this.skillEffectCfg.show_effect > 0) {
                        var targetActor = this.targetList[i];
                        if (targetActor) {
                            qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, targetActor, -1, this.timeScale, true);
                        }
                        else {
                            qmr.LogUtil.warn("目标不存在了？？？技能id:" + this.skillId);
                        }
                    }
                }
            }
        };
        /** 表现特效播放完毕后,中心受击之后，外网再次受击 */
        SkillAction5Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            if (this.skillEffectCfg.hit_effect > 0) {
                var targetActor = this.targetList[0];
                var targetState = this.targetFighterMsg[0];
                if (targetActor) {
                    qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                }
                else {
                    qmr.LogUtil.warn("技能5：受击列表中目标不存在，技能id:" + this.skillId);
                }
                qmr.SceneManager.instance.onAttackResultBack(targetActor, targetState);
            }
            var endTime = 500 / this.timeScale;
            if (this.targetList.length > 1) {
                endTime += this.delayTime / this.timeScale;
                qmr.FightTimer.instance.registerTick(this.delayShowHitEffect, this, this.delayTime / this.timeScale, 1);
            }
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, endTime, 1);
        };
        SkillAction5Proxy.prototype.delayShowHitEffect = function () {
            var count = this.targetList.length;
            for (var i = 1; i < count; i++) {
                if (this.skillEffectCfg.hit_effect > 0) {
                    var targetActor = this.targetList[i];
                    if (targetActor) {
                        qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                    }
                    else {
                        qmr.LogUtil.warn("目标不存在了？？？技能类型5 id:" + this.skillId);
                    }
                    qmr.SceneManager.instance.onAttackResultBack(targetActor, this.targetFighterMsg[i]);
                }
            }
        };
        /**  本轮技能释放完毕 */
        SkillAction5Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction5Proxy.prototype.recycleSkill = function () {
            this.targetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.removeShowEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.delayShowEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.delayShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction5Proxy.recovrySkillProxy(this);
        };
        return SkillAction5Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction5Proxy = SkillAction5Proxy;
    __reflect(SkillAction5Proxy.prototype, "qmr.SkillAction5Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction5Proxy.js.map