var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (13)远程，子弹连发,多段攻击
     */
    var SkillAction13Proxy = (function (_super) {
        __extends(SkillAction13Proxy, _super);
        function SkillAction13Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.tempTargetList = [];
            _this.dropPos = {};
            _this.flyCount = 0;
            return _this;
        }
        SkillAction13Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction13Proxy", SkillAction13Proxy);
            return proxy;
        };
        SkillAction13Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction13Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction13Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction13Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction13Proxy.prototype.onReleaseSkillEffect = function () {
            var self = this;
            if (self.skillEffectCfg.show_effect > 0) {
                //群体同时播放特效
                self.flyCount = 0;
                var _loop_1 = function (targetActor) {
                    if (targetActor) {
                        // LogUtil.warn("施法了 " + self.flyCount)
                        effect = qmr.EffectPlayer.playEffect(self.skillEffectCfg.show_effect, self.owner, -1, self.timeScale);
                        if (effect) {
                            self.flyCount++;
                            dx = targetActor.x - self.owner.x;
                            dy = targetActor.y - self.owner.y;
                            var effCfg = qmr.SkillModel.instance.getSkillEffectDataBySkillId(self.skillId);
                            var t = self.timeScale > 1 ? self.timeScale * 1.3 : 1;
                            var speed_1 = effCfg ? Math.floor(effCfg.speed * t) : 0;
                            effect.speed = speed_1;
                            var rotation_1 = Math.atan2(dy, dx) * 180 / Math.PI;
                            effect.rotation = rotation_1;
                            var onArrival = self.onArrival;
                            var target = targetActor;
                            effect.moveTo(targetActor.x, targetActor.y, onArrival, self, [target, effect]);
                            self.addTempEffect(effect);
                            //如果特效没返回到达目的地，去找一下特效表里面，特效配置的播放次数是否满足到达时间
                            if (effCfg.multiTimes) {
                                var timsArr = effCfg.multiTimes.split(",").map(Number);
                                var count = timsArr[0];
                                var time = timsArr[1];
                                var _loop_2 = function () {
                                    var delayRemove = function (args) {
                                        if (!args || args.length < 1) {
                                            return;
                                        }
                                        var effect = args[0];
                                        if (effect) {
                                            effect.dispos();
                                        }
                                    };
                                    var delayCall = function () {
                                        if (self.canShowEffect) {
                                            effect = qmr.EffectPlayer.playEffect(self.skillEffectCfg.show_effect, self.owner, -1, self.timeScale);
                                            effect.speed = speed_1;
                                            effect.rotation = rotation_1;
                                            effect.moveTo(targetActor.x, targetActor.y, delayRemove, self, [effect]);
                                            self.addTempEffect(effect);
                                        }
                                    };
                                    qmr.FightTimer.instance.registerTick(delayCall, self, i * time / self.timeScale, 1);
                                };
                                for (var i = 1; i < count; i++) {
                                    _loop_2();
                                }
                            }
                            else {
                                qmr.LogUtil.warn("表现特效不存在，需要策划在（特效_EffectData表格）里面配置一下 " + self.skillEffectCfg.show_effect);
                                self.onArrival([targetActor]);
                            }
                        }
                        else {
                            qmr.LogUtil.warn("技能3：受击列表中目标不存在，技能id:" + self.skillId);
                            self.onArrival(null);
                        }
                    }
                    qmr.LogUtil.logF("群体同时播放特效 " + self.targetList.length);
                };
                var effect, dx, dy;
                for (var _i = 0, _a = self.targetList; _i < _a.length; _i++) {
                    var targetActor = _a[_i];
                    _loop_1(targetActor);
                }
            }
        };
        /** 到达目标地点 */
        SkillAction13Proxy.prototype.onArrival = function (args) {
            var self = this;
            qmr.LogUtil.logF("群体同时播放特效");
            if (!args || args.length < 1) {
                self.onShowHitEffect();
                return;
            }
            var targetActor = args[0];
            var effect = args[1];
            if (effect) {
                effect.dispos();
            }
            if (targetActor instanceof qmr.BaseMoverActor) {
                self.tempTargetList.push(targetActor);
            }
            //多段伤害
            if (self.skillEffectCfg.multistage) {
                var mulits = qmr.SkillModel.instance.getMultiDatas(self.skillEffectCfg.multistage);
                self.mulitCount = mulits.length;
                var element = void 0;
                for (var i = 0; i < self.mulitCount; i++) {
                    element = mulits[i];
                    if (element) {
                        qmr.FightTimer.instance.registerTick(self.mulitHuttFunc[i], self, element.time / self.timeScale, 1, element.rate);
                    }
                }
            }
            else {
                var show_time = self.skillEffectCfg.show_time / self.timeScale;
                if (show_time > 0) {
                    qmr.FightTimer.instance.unRegisterTick(self.onShowHitEffect, self);
                    qmr.FightTimer.instance.registerTick(self.onShowHitEffect, self, show_time, 1);
                }
                else {
                    self.onShowHitEffect();
                }
            }
        };
        /** 表现特效播放完毕后 */
        SkillAction13Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            var self = this;
            var count = self.targetList.length;
            if (self.skillEffectCfg.hit_effect > 0) {
                for (var i = 0; i < count; i++) {
                    var targetActor = self.targetList[i];
                    if (targetActor) {
                        qmr.EffectPlayer.playEffect(self.skillEffectCfg.hit_effect, targetActor, -1, self.timeScale, true);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, self.targetFighterMsg[i], rate);
                    }
                    else {
                        qmr.LogUtil.warn("技能13：受击列表中目标不存在，技能id:" + self.skillId);
                    }
                }
            }
            if (isPlayEnd) {
                self.flyCount++;
                qmr.LogUtil.logF("群体同时受击结束 " + self.flyCount);
            }
            // 避免有点远程特效还没飞到目标位置就结束了，不飘受击特效了。。。
            var delay = (self.flyCount < count) ? 1000 : 300;
            delay /= self.timeScale;
            qmr.FightTimer.instance.unRegisterTick(self.onPlayEnd, self);
            qmr.FightTimer.instance.registerTick(self.onPlayEnd, self, delay, 1);
        };
        SkillAction13Proxy.prototype.getFightMsg = function (id) {
            if (!this.targetFighterMsg)
                return null;
            for (var _i = 0, _a = this.targetFighterMsg; _i < _a.length; _i++) {
                var t = _a[_i];
                if (t.fighterId == id) {
                    return t;
                }
            }
            return null;
        };
        /**  本轮技能释放完毕 */
        SkillAction13Proxy.prototype.onPlayEnd = function () {
            qmr.LogUtil.logF("本轮技能释放完毕 " + this.flyCount);
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction13Proxy.prototype.recycleSkill = function () {
            var self = this;
            self.flyCount = 0;
            self.targetList.length = 0;
            self.tempTargetList.length = 0;
            self.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(self.removeCaseEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onReleaseSkillEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onShowHitEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onPlayEnd, self);
            _super.prototype.recycleSkill.call(this);
            SkillAction13Proxy.recovrySkillProxy(self);
        };
        return SkillAction13Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction13Proxy = SkillAction13Proxy;
    __reflect(SkillAction13Proxy.prototype, "qmr.SkillAction13Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction13Proxy.js.map