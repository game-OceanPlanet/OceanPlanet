var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (4)远程，天降技能，同时受击
     */
    var SkillAction4Proxy = (function (_super) {
        __extends(SkillAction4Proxy, _super);
        function SkillAction4Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.dropPos = {};
            return _this;
        }
        SkillAction4Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction4Proxy", SkillAction4Proxy);
            return proxy;
        };
        SkillAction4Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction4Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction4Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction4Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                //添加施法效果
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.owner.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction4Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                //群体同时播放特效
                for (var _i = 0, _a = this.targetList; _i < _a.length; _i++) {
                    var targetActor = _a[_i];
                    if (targetActor) {
                        var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, targetActor, -1, this.owner.timeScale, true);
                        this.addTempEffect(effect);
                    }
                }
            }
            //表现持续时间
            var showDurotion = this.skillEffectCfg.show_durotion / this.timeScale;
            if (showDurotion > 0) {
                qmr.FightTimer.instance.registerTick(this.removeAllTempEffect, this, showDurotion, 1);
            }
            //多段伤害
            if (this.skillEffectCfg.multistage) {
                var mulits = qmr.SkillModel.instance.getMultiDatas(this.skillEffectCfg.multistage);
                this.mulitCount = mulits.length;
                var element = void 0;
                for (var i = 0; i < this.mulitCount; i++) {
                    element = mulits[i];
                    if (element) {
                        qmr.FightTimer.instance.registerTick(this.mulitHuttFunc[i], this, element.time / this.timeScale, 1, element.rate);
                    }
                }
            }
            else {
                var show_time = this.skillEffectCfg.show_time / this.timeScale;
                if (show_time > 0) {
                    qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
                }
                else {
                    this.onShowHitEffect();
                }
            }
        };
        /** 表现特效播放完毕后 */
        SkillAction4Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            var count = this.targetList.length;
            if (this.skillEffectCfg.hit_effect > 0) {
                for (var i = 0; i < count; i++) {
                    var targetActor = this.targetList[i];
                    if (targetActor) {
                        qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.owner.timeScale, true);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, this.targetFighterMsg[i]);
                    }
                    else {
                        qmr.LogUtil.warn("技能4：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
            }
            if (isPlayEnd) {
                qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, 300 / this.timeScale, 1);
            }
        };
        /**  本轮技能释放完毕 */
        SkillAction4Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction4Proxy.prototype.recycleSkill = function () {
            this.targetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.removeAllTempEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction4Proxy.recovrySkillProxy(this);
        };
        return SkillAction4Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction4Proxy = SkillAction4Proxy;
    __reflect(SkillAction4Proxy.prototype, "qmr.SkillAction4Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction4Proxy.js.map