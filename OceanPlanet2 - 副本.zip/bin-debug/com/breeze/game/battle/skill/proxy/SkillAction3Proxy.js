var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (3)远程，子弹飞行攻击
     */
    var SkillAction3Proxy = (function (_super) {
        __extends(SkillAction3Proxy, _super);
        function SkillAction3Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.tempTargetList = [];
            _this.dropPos = {};
            _this.flyCount = 0;
            return _this;
        }
        SkillAction3Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction3Proxy", SkillAction3Proxy);
            return proxy;
        };
        SkillAction3Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction3Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction3Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction3Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction3Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                //群体同时播放特效
                this.flyCount = 0;
                for (var _i = 0, _a = this.targetList; _i < _a.length; _i++) {
                    var targetActor = _a[_i];
                    if (targetActor) {
                        // LogUtil.warn("施法了 " + this.flyCount)
                        var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, this.owner, -1, this.timeScale);
                        if (effect) {
                            this.flyCount++;
                            var dx = targetActor.x - this.owner.x;
                            var dy = targetActor.y - this.owner.y;
                            var effCfg = qmr.SkillModel.instance.getSkillEffectDataBySkillId(this.skillId);
                            var t = this.timeScale > 1 ? this.timeScale * 1.3 : 1;
                            effect.speed = effCfg ? effCfg.speed * t : 0;
                            effect.speed = Math.floor(effect.speed);
                            effect.rotation = Math.atan2(dy, dx) * 180 / Math.PI;
                            var onArrival = this.onArrival;
                            var target = targetActor;
                            effect.moveTo(targetActor.x, targetActor.y, onArrival, this, [target, effect]);
                            this.addTempEffect(effect);
                            //如果特效没返回到达目的地，去找一下特效表里面，特效配置的播放次数是否满足到达时间
                        }
                        else {
                            qmr.LogUtil.warn("表现特效不存在，需要策划在（特效_EffectData表格）里面配置一下 " + this.skillEffectCfg.show_effect);
                            this.onArrival([targetActor]);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能3：受击列表中目标不存在，技能id:" + this.skillId);
                        this.onArrival(null);
                    }
                }
                qmr.LogUtil.logF("群体同时播放特效 " + this.targetList.length);
            }
        };
        /** 到达目标地点 */
        SkillAction3Proxy.prototype.onArrival = function (args) {
            qmr.LogUtil.logF("群体同时播放特效");
            if (!args || args.length < 1) {
                this.onShowHitEffect();
                return;
            }
            var targetActor = args[0];
            var effect = args[1];
            if (effect) {
                effect.dispos();
            }
            if (targetActor instanceof qmr.BaseMoverActor) {
                this.tempTargetList.push(targetActor);
            }
            var show_time = this.skillEffectCfg.show_time / this.timeScale;
            if (show_time > 0) {
                qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
                qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
            }
            else {
                this.onShowHitEffect();
            }
        };
        /** 表现特效播放完毕后 */
        SkillAction3Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            while (this.tempTargetList.length > 0) {
                this.flyCount--;
                //群体同时受击
                var targetActor = this.tempTargetList.pop();
                if (this.skillEffectCfg.hit_effect > 0) {
                    if (targetActor) {
                        if (this.owner) {
                            qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                        }
                        else {
                            qmr.LogUtil.warn("技能3：施法者不存在，这个问题很严重，技能id:" + this.skillId);
                        }
                        var targetFighterMsg = this.getFightMsg(targetActor.id);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, targetFighterMsg);
                    }
                    else {
                        qmr.LogUtil.warn("技能3：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
                qmr.LogUtil.logF("群体同时受击 " + this.flyCount);
            }
            // 避免有点远程特效还没飞到目标位置就结束了，不飘受击特效了。。。
            var delay = this.flyCount > 0 ? 1000 : 300;
            delay /= this.timeScale;
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, delay, 1);
        };
        SkillAction3Proxy.prototype.getFightMsg = function (id) {
            if (!this.targetFighterMsg)
                return null;
            for (var _i = 0, _a = this.targetFighterMsg; _i < _a.length; _i++) {
                var t = _a[_i];
                if (t.fighterId == id) {
                    return t;
                }
            }
            return null;
        };
        /**  本轮技能释放完毕 */
        SkillAction3Proxy.prototype.onPlayEnd = function () {
            qmr.LogUtil.logF("本轮技能释放完毕 " + this.flyCount);
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction3Proxy.prototype.recycleSkill = function () {
            this.flyCount = 0;
            this.targetList.length = 0;
            this.tempTargetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction3Proxy.recovrySkillProxy(this);
        };
        return SkillAction3Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction3Proxy = SkillAction3Proxy;
    __reflect(SkillAction3Proxy.prototype, "qmr.SkillAction3Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction3Proxy.js.map