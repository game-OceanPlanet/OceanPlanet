var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     *
     * @description 基础的技能代理
     *
     */
    var BaseSkillProxy = (function () {
        function BaseSkillProxy() {
            this._t = 0;
            this.mulitHuttFunc = [this.showHit1, this.showHit2, this.showHit3, this.showHit4, this.showHit5];
        }
        /** 设置技能Id */
        BaseSkillProxy.prototype.setSkillId = function (skillId, skillCfg) {
            if (skillCfg === void 0) { skillCfg = null; }
            this.skillId = skillId;
            this.skillEffectCfg = skillCfg ? skillCfg : qmr.SkillModel.instance.getSkillEffectDataBySkillId(skillId);
            this.canShowEffect = (this.skillEffectCfg != null);
            this.isShake = (this.canShowEffect) ? this.skillEffectCfg.shake : 0;
        };
        /** 设置目标群体 */
        BaseSkillProxy.prototype.setTargetList = function (targetMsg) {
            this.targetList = [];
            this.targetFighterMsg = targetMsg.concat();
            var count = targetMsg.length;
            var target;
            for (var k = 0; k < count; k++) {
                target = targetMsg[k];
                this.targetList[k] = qmr.SceneManager.instance.getBaseObjectByid(target.fighterId);
            }
        };
        BaseSkillProxy.prototype.addTempEffect = function (effect) {
            if (this.tempEffectList == null) {
                this.tempEffectList = [];
            }
            this.tempEffectList.push(effect);
        };
        Object.defineProperty(BaseSkillProxy.prototype, "timeScale", {
            get: function () {
                if (this.owner) {
                    return this.owner.timeScale;
                }
                return 1;
            },
            enumerable: true,
            configurable: true
        });
        /** 设置技能拥有者 */
        BaseSkillProxy.prototype.setOwner = function (owner) {
            this.owner = owner;
        };
        /** 释放技能 */
        BaseSkillProxy.prototype.releaseSkill = function () { this.checkShowShake(); };
        //展示震屏
        BaseSkillProxy.prototype.checkShowShake = function () {
            var t = this;
            var eCfg = t.skillEffectCfg;
            if (eCfg && eCfg.shakeTimePoint) {
                var shakeShowTime = eCfg.shakeTimePoint / t.timeScale;
                if (shakeShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(t.showShake, t, shakeShowTime, 1, eCfg.shakeTime / t.timeScale);
                }
            }
        };
        BaseSkillProxy.prototype.showShake = function (shakeTime) {
            if (shakeTime === void 0) { shakeTime = 200; }
            qmr.SceneManager.instance.shake(shakeTime);
        };
        /** 表现特效 */
        BaseSkillProxy.prototype.onReleaseSkillEffect = function () { };
        /** 技能伤害第一段 */
        BaseSkillProxy.prototype.showHit1 = function (rate) {
            var isPlayEnd = this.getIsPlayEnd(1);
            this.onShowHitEffect(rate, isPlayEnd);
        };
        /** 技能伤害第二段 */
        BaseSkillProxy.prototype.showHit2 = function (rate) {
            var isPlayEnd = this.getIsPlayEnd(2);
            this.onShowHitEffect(rate, isPlayEnd);
        };
        /** 技能伤害第三段 */
        BaseSkillProxy.prototype.showHit3 = function (rate) {
            var isPlayEnd = this.getIsPlayEnd(3);
            this.onShowHitEffect(rate, isPlayEnd);
        };
        /** 技能伤害第四段 */
        BaseSkillProxy.prototype.showHit4 = function (rate) {
            var isPlayEnd = this.getIsPlayEnd(4);
            this.onShowHitEffect(rate, isPlayEnd);
        };
        /** 技能伤害第五段 */
        BaseSkillProxy.prototype.showHit5 = function (rate) {
            var isPlayEnd = this.getIsPlayEnd(5);
            this.onShowHitEffect(rate, isPlayEnd);
        };
        BaseSkillProxy.prototype.getIsPlayEnd = function (k) {
            return this.mulitCount == k;
        };
        /** 显示受击，需被子类继承 */
        BaseSkillProxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
        };
        /** 回收技能，需被子类继承 */
        BaseSkillProxy.prototype.recycleSkill = function () {
            var t = this;
            t.owner = null;
            t.canShowEffect = false;
            t.targetList.length = 0;
            t.targetFighterMsg.length = 0;
            t.removeCaseEffect();
            t.removeShowEffect();
            t.removeAllTempEffect();
            var count = t.mulitHuttFunc.length;
            for (var i = 0; i < count; i++) {
                qmr.FightTimer.instance.unRegisterTick(t.mulitHuttFunc[i], t);
            }
            qmr.FightTimer.instance.unRegisterTick(t.showShake, t);
            qmr.SceneManager.instance.removeShake();
        };
        BaseSkillProxy.prototype.removeCaseEffect = function () {
            if (this.caseEffect) {
                this.caseEffect.dispos();
                this.caseEffect = null;
            }
        };
        BaseSkillProxy.prototype.removeShowEffect = function () {
            if (this.showEffect) {
                this.showEffect.dispos();
                this.showEffect = null;
            }
        };
        BaseSkillProxy.prototype.removeAllTempEffect = function () {
            if (this.tempEffectList) {
                this.tempEffectList.forEach(function (element) {
                    if (element)
                        element.dispos();
                });
                this.tempEffectList.length = 0;
            }
        };
        return BaseSkillProxy;
    }());
    qmr.BaseSkillProxy = BaseSkillProxy;
    __reflect(BaseSkillProxy.prototype, "qmr.BaseSkillProxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseSkillProxy.js.map