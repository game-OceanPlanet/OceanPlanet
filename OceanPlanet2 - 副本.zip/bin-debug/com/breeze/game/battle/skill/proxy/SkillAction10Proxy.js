var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (10)远程，播放一个弹道效果之后在2和5、8和11之间释放一个效果,没有角度
     */
    var SkillAction10Proxy = (function (_super) {
        __extends(SkillAction10Proxy, _super);
        function SkillAction10Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.dropPos = {};
            return _this;
        }
        SkillAction10Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction10Proxy", SkillAction10Proxy);
            return proxy;
        };
        SkillAction10Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction10Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction10Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction10Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                //添加施法效果
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.owner.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction10Proxy.prototype.onReleaseSkillEffect = function () {
            var isEnd;
            if (this.skillEffectCfg.show_effect > 0) {
                //群体同时播放特效
                if (this.targetList.length > 0) {
                    var targetActor = this.targetList[0];
                    if (targetActor) {
                        var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, this.owner, -1, this.owner.timeScale);
                        if (effect) {
                            this.getCenterPos(targetActor.camp);
                            var effCfg = qmr.SkillModel.instance.getSkillEffectDataBySkillId(this.skillId);
                            effect.speed = effCfg ? effCfg.speed : 0;
                            effect.moveTo(this._centerPos.x, this._centerPos.y, this.onArrival, this, [effect]);
                            this.addTempEffect(effect);
                            //表现持续时间
                            var showDurotion = this.skillEffectCfg.show_durotion / this.timeScale;
                            ;
                            if (showDurotion > 0) {
                                qmr.FightTimer.instance.registerTick(this.removeAllTempEffect, this, showDurotion, 1);
                            }
                        }
                        else {
                            qmr.LogUtil.warn("表现特效不存在，需要策划在（特效_EffectData表格）里面配置一下 " + this.skillEffectCfg.show_effect);
                            this.onArrival([targetActor]);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能9：群体同时播放特效目标不存在，技能id:" + this.skillId);
                        isEnd = true;
                    }
                }
                else {
                    isEnd = true;
                    qmr.LogUtil.warn("技能9：群体同时播放特效目标不存在");
                }
            }
            else {
                isEnd = true;
            }
            if (isEnd) {
                this.onReleaseSkillEffect2();
            }
        };
        /** 到达目标地点 */
        SkillAction10Proxy.prototype.onArrival = function (args) {
            var effect = args[0];
            if (effect) {
                effect.dispos();
            }
            this.onReleaseSkillEffect2();
        };
        /** 表现特效 */
        SkillAction10Proxy.prototype.onReleaseSkillEffect2 = function () {
            var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.orderly_effect, this._centerPos, -1, this.owner.timeScale);
            this.addTempEffect(effect);
            //多段伤害
            if (this.skillEffectCfg.multistage) {
                var mulits = qmr.SkillModel.instance.getMultiDatas(this.skillEffectCfg.multistage);
                this.mulitCount = mulits.length;
                var element = void 0;
                for (var i = 0; i < this.mulitCount; i++) {
                    element = mulits[i];
                    if (element) {
                        qmr.FightTimer.instance.registerTick(this.mulitHuttFunc[i], this, element.time / this.timeScale, 1, element.rate);
                    }
                }
            }
            else {
                var show_time = this.skillEffectCfg.show_time / this.timeScale;
                if (show_time > 0) {
                    qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
                    qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
                }
                else {
                    this.onShowHitEffect();
                }
            }
        };
        // 找出上下阵营的中心点
        SkillAction10Proxy.prototype.getCenterPos = function (type) {
            // if (!this._centerPos) this._centerPos = new egret.Point();
            // var up = type == CampType.FOE ? 5 : 2;
            // var down = type == CampType.FOE ? 2 : 5;
            // var pos1 = BattlePosionManager.instance.getPosByType(type, up);
            // var pos2 = BattlePosionManager.instance.getPosByType(type, down);
            // this._centerPos.x = pos1.x;
            // this._centerPos.y = pos1.y + ((pos2.y - pos1.y) >> 1);
        };
        /** 表现特效播放完毕后 */
        SkillAction10Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            var count = this.targetList.length;
            if (this.skillEffectCfg.hit_effect > 0) {
                for (var i = 0; i < count; i++) {
                    var targetActor = this.targetList[i];
                    if (targetActor) {
                        qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.owner.timeScale, true);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, this.targetFighterMsg[i]);
                    }
                    else {
                        qmr.LogUtil.warn("技能8：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
            }
            if (isPlayEnd) {
                qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, 300 / this.timeScale, 1);
            }
        };
        /**  本轮技能释放完毕 */
        SkillAction10Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction10Proxy.prototype.recycleSkill = function () {
            this.targetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.removeAllTempEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction10Proxy.recovrySkillProxy(this);
        };
        return SkillAction10Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction10Proxy = SkillAction10Proxy;
    __reflect(SkillAction10Proxy.prototype, "qmr.SkillAction10Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction10Proxy.js.map