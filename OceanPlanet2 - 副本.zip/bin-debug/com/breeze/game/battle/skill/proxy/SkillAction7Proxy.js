var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (7)远程，治疗技能，只有施法和治疗受击效果
     */
    var SkillAction7Proxy = (function (_super) {
        __extends(SkillAction7Proxy, _super);
        function SkillAction7Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            _this.dropPos = {};
            return _this;
        }
        SkillAction7Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction7Proxy", SkillAction7Proxy);
            return proxy;
        };
        SkillAction7Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction7Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction7Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction7Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                //添加施法效果
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 没有表现效果，直接调用目标治疗特效 */
        SkillAction7Proxy.prototype.onReleaseSkillEffect = function () {
            this.onShowHitEffect();
        };
        /** 表现特效播放完毕后 */
        SkillAction7Proxy.prototype.onShowHitEffect = function () {
            if (this.skillEffectCfg.hit_effect > 0) {
                while (this.targetList.length > 0) {
                    var targetActor = this.targetList.pop();
                    var targetFighterMsg = this.targetFighterMsg.pop();
                    //群体同时治疗
                    if (targetActor) {
                        var effect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                        this.addTempEffect(effect);
                        //表现持续时间
                        var showDurotion = this.skillEffectCfg.show_durotion / this.timeScale;
                        if (showDurotion > 0) {
                            qmr.FightTimer.instance.registerTick(this.removeAllTempEffect, this, showDurotion, 1);
                        }
                        if (targetActor != this.owner) {
                            //如果治疗目标里面有自己就要移除，因为施法者状态已经在施法者状态里面变更了，不然会导致飘两次加血
                            qmr.SceneManager.instance.onAttackResultBack(targetActor, targetFighterMsg);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能7：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
            }
            if (this.canShowEffect) {
                qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
                var endTime = this.skillEffectCfg.node_duration - this.skillEffectCfg.cast_showTime - this.skillEffectCfg.hitDelay;
                qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, endTime / this.timeScale, 1);
            }
        };
        /**  本轮技能释放完毕 */
        SkillAction7Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承
         */
        SkillAction7Proxy.prototype.recycleSkill = function () {
            this.targetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.removeShowEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onShowHitEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction7Proxy.recovrySkillProxy(this);
        };
        return SkillAction7Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction7Proxy = SkillAction7Proxy;
    __reflect(SkillAction7Proxy.prototype, "qmr.SkillAction7Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction7Proxy.js.map