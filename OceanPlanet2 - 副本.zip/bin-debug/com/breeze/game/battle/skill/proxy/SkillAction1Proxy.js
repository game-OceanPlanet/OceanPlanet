var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (1)移动到目标位置攻击
     */
    var SkillAction1Proxy = (function (_super) {
        __extends(SkillAction1Proxy, _super);
        function SkillAction1Proxy() {
            var _this = _super.call(this) || this;
            _this.targetList = [];
            return _this;
        }
        SkillAction1Proxy.getSkillProxy = function () {
            var skill = qmr.Pool.getItemByClass("SkillAction1Proxy", SkillAction1Proxy);
            return skill;
        };
        SkillAction1Proxy.recovrySkillProxy = function (skill) {
            qmr.Pool.recover("SkillAction1Proxy", skill);
        };
        /** 释放技能 */
        SkillAction1Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction1Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                //移动到对面对象跟前攻击
                if (this.targetList.length > 0) {
                    var target = this.targetList[0];
                    if (target) {
                        qmr.SceneManager.instance.addObjectToTop(this.owner);
                        var offsetY = (target.camp == CampType.FOE) ? 90 : -90;
                        this.owner.isCanMove = true; //后面可扩展为判断是否被禁动
                        this.owner.moveScale = this.timeScale;
                        this.owner.speed = 90; //后面在扩展速度
                        this.owner.changeStatus(qmr.Status.FLY, true);
                        this.owner.moveTo(target.x - 20, target.y + offsetY, this.onArrival, this, 5);
                        //添加施法效果
                        if (this.skillEffectCfg.cast_effect > 0) {
                            this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale);
                        }
                        //施法展示时间
                        var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                        if (castShowTime > 0) {
                            qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能1：移动目的地目标不存在，技能id:" + this.skillId);
                        this.onArrival();
                    }
                }
            }
        };
        /** 到达目标地点 */
        SkillAction1Proxy.prototype.onArrival = function () {
            this.owner.changeStatus(qmr.Status.ATTACK2, true);
            this.owner.delayBackPos(500 / this.timeScale);
            if (this.skillEffectCfg.cast_effect > 0) {
                qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.timeScale, true);
            }
            var castTime = this.skillEffectCfg.cast_time / this.timeScale;
            if (castTime > 0) {
                qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
            }
            else {
                this.onReleaseSkillEffect();
            }
        };
        /** 表现特效 */
        SkillAction1Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                if (this.targetList.length > 0) {
                    var targetActor = this.targetList[0];
                    if (targetActor) {
                        //刀光需要反转一下
                        var dir = (this.owner.camp == CampType.OUR) ? 1 : -1;
                        this.showEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.show_effect, targetActor, -1, this.timeScale, true);
                        this.showEffect.scaleY *= dir;
                        //表现持续时间
                        var showDurotion = this.skillEffectCfg.show_durotion / this.timeScale;
                        if (showDurotion > 0) {
                            qmr.FightTimer.instance.registerTick(this.removeShowEffect, this, showDurotion, 1);
                        }
                    }
                    else {
                        qmr.LogUtil.warn("技能1：表现列表中目标不存在，技能id:" + this.skillId);
                    }
                }
            }
            //多段伤害
            if (this.skillEffectCfg.multistage) {
                var mulits = qmr.SkillModel.instance.getMultiDatas(this.skillEffectCfg.multistage);
                this.mulitCount = mulits.length;
                var element = void 0;
                for (var i = 0; i < this.mulitCount; i++) {
                    element = mulits[i];
                    if (element) {
                        qmr.FightTimer.instance.registerTick(this.mulitHuttFunc[i], this, element.time / this.timeScale, 1, element.rate);
                    }
                }
            }
            else {
                var show_time = this.skillEffectCfg.show_time / this.timeScale;
                if (show_time > 0) {
                    qmr.FightTimer.instance.registerTick(this.onShowHitEffect, this, show_time, 1);
                }
                else {
                    this.onShowHitEffect();
                }
            }
        };
        /** 表现特效播放完毕后 */
        SkillAction1Proxy.prototype.onShowHitEffect = function (rate, isPlayEnd) {
            if (rate === void 0) { rate = 1; }
            if (isPlayEnd === void 0) { isPlayEnd = true; }
            var count = this.targetList.length;
            if (this.skillEffectCfg.hit_effect > 0) {
                for (var i = 0; i < count; i++) {
                    var targetActor = this.targetList[i];
                    if (targetActor) {
                        qmr.EffectPlayer.playEffect(this.skillEffectCfg.hit_effect, targetActor, -1, this.timeScale, true);
                        qmr.SceneManager.instance.onAttackResultBack(targetActor, this.targetFighterMsg[i]);
                    }
                    else {
                        qmr.LogUtil.warn("技能1：受击列表中目标不存在，技能id:" + this.skillId);
                    }
                }
            }
            if (isPlayEnd) {
                qmr.FightTimer.instance.registerTick(this.onPlayEnd, this, 300 / this.timeScale, 1);
            }
        };
        /**  本轮技能释放完毕 */
        SkillAction1Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        /** 回收技能，需被子类继承  */
        SkillAction1Proxy.prototype.recycleSkill = function () {
            var self = this;
            self.targetList.length = 0;
            qmr.FightTimer.instance.unRegisterTick(self.removeCaseEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.removeShowEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onReleaseSkillEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onShowHitEffect, self);
            qmr.FightTimer.instance.unRegisterTick(self.onPlayEnd, self);
            _super.prototype.recycleSkill.call(this);
            SkillAction1Proxy.recovrySkillProxy(self);
        };
        return SkillAction1Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction1Proxy = SkillAction1Proxy;
    __reflect(SkillAction1Proxy.prototype, "qmr.SkillAction1Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction1Proxy.js.map