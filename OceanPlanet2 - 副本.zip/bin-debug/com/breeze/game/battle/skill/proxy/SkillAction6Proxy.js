var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @description (6)远程，闪攻击，目标依次受击
     */
    var SkillAction6Proxy = (function (_super) {
        __extends(SkillAction6Proxy, _super);
        function SkillAction6Proxy() {
            var _this = _super.call(this) || this;
            _this.delayTime = 500; //延迟之后，外围再受击
            _this.targetIndex = 0; //受击顺序
            _this.targetList = [];
            _this.chainEffects = [];
            _this.dropPos = {};
            return _this;
        }
        SkillAction6Proxy.getSkillProxy = function () {
            var proxy = qmr.Pool.getItemByClass("SkillAction6Proxy", SkillAction6Proxy);
            return proxy;
        };
        SkillAction6Proxy.recovrySkillProxy = function (proxy) {
            qmr.Pool.recover("SkillAction6Proxy", proxy);
        };
        /** 释放技能 */
        SkillAction6Proxy.prototype.releaseSkill = function () {
            _super.prototype.releaseSkill.call(this);
            //起手特效
            this.onCastSkill();
        };
        /** 起手特效 */
        SkillAction6Proxy.prototype.onCastSkill = function () {
            if (this.canShowEffect) {
                this.owner.changeStatus(qmr.Status.ATTACK, true);
                //添加施法效果
                if (this.skillEffectCfg.cast_effect > 0) {
                    this.caseEffect = qmr.EffectPlayer.playEffect(this.skillEffectCfg.cast_effect, this.owner, -1, this.owner.timeScale);
                }
                //施法展示时间
                var castShowTime = this.skillEffectCfg.cast_showTime / this.timeScale;
                if (castShowTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.removeCaseEffect, this, castShowTime, 1);
                }
                var castTime = this.skillEffectCfg.cast_time / this.timeScale;
                if (castTime > 0) {
                    qmr.FightTimer.instance.registerTick(this.onReleaseSkillEffect, this, castTime, 1);
                }
                else {
                    this.onReleaseSkillEffect();
                }
            }
        };
        /** 表现特效 */
        SkillAction6Proxy.prototype.onReleaseSkillEffect = function () {
            if (this.skillEffectCfg.show_effect > 0) {
                this.targetIndex = 0;
                qmr.LogUtil.logF("loopShowEffect : " + this.targetIndex + " " + this.targetList.length);
                this.loopShowEffect();
            }
            else {
                this.onPlayEnd();
            }
        };
        SkillAction6Proxy.prototype.loopShowEffect = function () {
            if (this.targetIndex >= this.targetList.length) {
                this.onPlayEnd();
                qmr.FightTimer.instance.unRegisterTick(this.loopShowEffect, this);
                return;
            }
            else {
                var targetActor = this.targetList[this.targetIndex];
                var targetState = this.targetFighterMsg[this.targetIndex];
                if (targetActor) {
                    var startActor = void 0;
                    var endActor_1;
                    var showEffect = void 0;
                    if (this.targetIndex == 0) {
                        startActor = this.owner;
                        endActor_1 = targetActor;
                        showEffect = this.skillEffectCfg.show_effect;
                    }
                    else {
                        startActor = this.targetList[this.targetIndex - 1];
                        endActor_1 = this.targetList[this.targetIndex];
                        showEffect = this.skillEffectCfg.orderly_effect;
                    }
                    var timeScale_1 = endActor_1.timeScale;
                    if (startActor) {
                        var dist = qmr.MathUtil.distance(startActor, endActor_1);
                        var dx = endActor_1.x - startActor.x;
                        var dy = endActor_1.y - startActor.y;
                        var effect = qmr.EffectPlayer.playEffect(showEffect, startActor, -1, timeScale_1, true);
                        effect.effectWidth = dist;
                        effect.rotation = Math.atan2(dy, dx) * 180 / Math.PI;
                        this.chainEffects.push(effect);
                    }
                    var isShow_1 = this.canShowEffect;
                    var hit_effect_1 = this.skillEffectCfg.hit_effect;
                    var fighterMsg_1 = this.targetFighterMsg[this.targetIndex];
                    //展示受击
                    var delayShowHitEffect = function () {
                        if (isShow_1) {
                            if (hit_effect_1 > 0) {
                                if (endActor_1) {
                                    qmr.EffectPlayer.playEffect(hit_effect_1, endActor_1, -1, timeScale_1, true);
                                    qmr.SceneManager.instance.onAttackResultBack(endActor_1, fighterMsg_1);
                                }
                            }
                        }
                    };
                    qmr.FightTimer.instance.registerTick(delayShowHitEffect, this, this.skillEffectCfg.show_time / this.timeScale, 1);
                }
                else {
                    qmr.LogUtil.warn("技能6：受击列表中目标不存在，技能id:" + this.skillId);
                }
            }
            //依次延迟
            this.targetIndex++;
            qmr.FightTimer.instance.unRegisterTick(this.loopShowEffect, this);
            qmr.FightTimer.instance.registerTick(this.loopShowEffect, this, this.delayTime / this.timeScale, 1);
            qmr.LogUtil.logF("this.targetIndex : " + this.targetIndex);
        };
        /**  本轮技能释放完毕 */
        SkillAction6Proxy.prototype.onPlayEnd = function () {
            if (this.owner)
                this.owner.onSkilReleaselOver();
            this.recycleSkill();
        };
        //移除闪电
        SkillAction6Proxy.prototype.removeChain = function () {
            qmr.LogUtil.logF("闪电之后结束");
            if (this.chainEffects.length > 0) {
                for (var _i = 0, _a = this.chainEffects; _i < _a.length; _i++) {
                    var e = _a[_i];
                    qmr.LogUtil.logF("闪电之后结束,销毁特效" + this.skillId);
                    e.dispos();
                }
                this.chainEffects.length = 0;
            }
        };
        /** 回收技能，需被子类继承
         */
        SkillAction6Proxy.prototype.recycleSkill = function () {
            this.removeChain();
            this.targetIndex = 0;
            this.targetList.length = 0;
            this.canShowEffect = false;
            qmr.FightTimer.instance.unRegisterTick(this.removeCaseEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.loopShowEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onReleaseSkillEffect, this);
            qmr.FightTimer.instance.unRegisterTick(this.onPlayEnd, this);
            _super.prototype.recycleSkill.call(this);
            SkillAction6Proxy.recovrySkillProxy(this);
        };
        return SkillAction6Proxy;
    }(qmr.BaseSkillProxy));
    qmr.SkillAction6Proxy = SkillAction6Proxy;
    __reflect(SkillAction6Proxy.prototype, "qmr.SkillAction6Proxy");
})(qmr || (qmr = {}));
//# sourceMappingURL=SkillAction6Proxy.js.map