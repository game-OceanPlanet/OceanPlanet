var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var EntryAfterLogin = (function () {
        function EntryAfterLogin() {
        }
        EntryAfterLogin.onEnterGame = function () {
            console.log("======================开始进入游戏场景======================");
            qmr.ModuleManagerAft.init(); //设置游戏模块类初始化
            qmr.MessageID.init();
            qmr.HeroController.instance.reqUserLoginInitFinish();
        };
        return EntryAfterLogin;
    }());
    qmr.EntryAfterLogin = EntryAfterLogin;
    __reflect(EntryAfterLogin.prototype, "qmr.EntryAfterLogin");
})(qmr || (qmr = {}));
//# sourceMappingURL=EntryAfterLogin.js.map