var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HangMap = (function (_super) {
        __extends(HangMap, _super);
        function HangMap() {
            var _this = _super.call(this) || this;
            _this.bgNames = ["_hang_top.jpg", "_hang_middle.png", "_hang_down.png"];
            _this._speed1 = 0.3;
            _this._speed2 = 1.2;
            _this._speed3 = 2.2;
            _this._imgToX1 = 1000;
            _this._imgToX2 = 1000;
            _this._imgToX3 = 1000;
            _this.moveStartx = 0;
            _this.initBase();
            return _this;
        }
        HangMap.prototype.initBase = function () {
            var t = this;
            // t.__mapThumb = new egret.Bitmap();
            // t.addChild(t.__mapThumb);
            t.mapPaths = [];
            t.bgBmpArr = [new egret.Bitmap(), new egret.Bitmap(), new egret.Bitmap()];
            var w = qmr.StageUtil.stageWidth;
            var h = qmr.StageUtil.stageHeight;
            t.moveRec1 = new egret.Rectangle(0, 0, w, h);
            t.moveRec2 = new egret.Rectangle(0, 0, w, h);
            t.moveRec3 = new egret.Rectangle(0, 0, w, h);
            t.mover1 = new egret.DisplayObjectContainer();
            t.mover1.addChild(new egret.Bitmap());
            var bitmap = new egret.Bitmap();
            //地图翻转拼接
            bitmap.scaleX = -1;
            t.mover1.addChild(bitmap);
            t.mover1.scrollRect = t.moveRec1;
            t.mover2 = new egret.DisplayObjectContainer();
            t.mover2.addChild(new egret.Bitmap());
            t.mover2.addChild(new egret.Bitmap());
            t.mover2.scrollRect = t.moveRec2;
            t.mover3 = new egret.DisplayObjectContainer();
            t.mover3.addChild(new egret.Bitmap());
            t.mover3.addChild(new egret.Bitmap());
            t.mover3.scrollRect = t.moveRec2;
            t.addChild(t.mover1);
            t.addChild(t.mover2);
            t.addChild(t.mover3);
            t.touchEnabled = t.touchChildren = false;
            t.addEventListener(egret.Event.ADDED_TO_STAGE, t.onAddToStage, t);
        };
        /**
        * instanceId 副本id
        */
        HangMap.prototype.loadMap = function (chapterId) {
            var mapCfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.XINHANGUP, chapterId);
            if (!mapCfg) {
                qmr.LogUtil.warn("挂机地图配置不存在:" + chapterId);
                return;
            }
            var mapResId = mapCfg.mapResId;
            var t = this;
            var fileName;
            var bgBmp;
            var len = this.bgNames.length;
            var stageHeight = qmr.StageUtil.stageHeight;
            var _loop_1 = function () {
                var key = i;
                var onTextureLoaded = function (texture, url) {
                    if (texture) {
                        bgBmp = t.bgBmpArr[key];
                        if (bgBmp) {
                            bgBmp.texture = texture;
                            var index = key + 1;
                            var mover = t["mover" + index];
                            var count = mover.numChildren;
                            var bmp = void 0;
                            var tox = 0;
                            var textureWidth = texture.textureWidth;
                            for (var i = 0; i < count; i++) {
                                bmp = mover.getChildAt(i);
                                if (bmp) {
                                    if (bmp.scaleX < 0) {
                                        bmp.x = tox + textureWidth;
                                    }
                                    else {
                                        bmp.x = tox;
                                    }
                                    bmp.texture = texture;
                                    tox += textureWidth;
                                }
                            }
                        }
                    }
                    t.reLayout();
                };
                fileName = mapResId + t.bgNames[i];
                mapPath = qmr.ResPathUtilAft.getMapUrl(fileName);
                qmr.ResManager.getRes(mapPath, onTextureLoaded, t, qmr.LoadPriority.IMMEDIATELY, RES.ResourceItem.TYPE_IMAGE);
                t.mapPaths.push(mapPath);
            };
            var mapPath;
            for (var i = 0; i < len; i++) {
                _loop_1();
            }
            t.addChild(t.mover1);
            t.addChild(t.mover2);
            t.addChild(t.mover3);
            t.__lastMoveTime = 0;
            t.setMoveX(0, 0, 0);
            t.startMove();
        };
        HangMap.prototype.reLayout = function () {
            var t = this;
            var offsetY = 80;
            var bgBmp;
            var count = this.bgBmpArr.length;
            var mover;
            var result;
            for (var k = 1; k <= count; k++) {
                mover = t["mover" + k];
                if (mover) {
                    mover.y = (k == 1) ? 0 : qmr.StageUtil.stageHeight - 120 - mover.height - 50;
                }
                result = t.bgBmpArr[k - 1];
                if (result) {
                    t["_imgToX" + k] = (k == 0) ? result.width - qmr.StageUtil.stageWidth : result.width * 2 - qmr.StageUtil.stageWidth;
                }
            }
            //地图高度有点不太够，特殊处理一下
            var h = qmr.StageUtil.stageHeight;
            if (h > 1400) {
                t.moveRec1.y = 0;
                t.mover2.y = qmr.StageUtil.stageHeight - 120 - t.mover2.height - 70 - offsetY;
            }
            else {
                t.moveRec1.y = 250;
                t.mover2.y = qmr.StageUtil.stageHeight - 120 - t.mover2.height - 50 - offsetY;
            }
        };
        /**初始化*/
        HangMap.prototype.onAddToStage = function (event) {
            this.reLayout();
            qmr.NotifyManager.registerNotify(qmr.StageUtil.STAGE_RESIZE, this.onStageResize, this);
        };
        HangMap.prototype.onStageResize = function (evt) {
            var t = this;
            var w = qmr.StageUtil.stageWidth;
            var h = qmr.StageUtil.stageHeight;
            t.moveRec1.width = t.moveRec2.width = t.moveRec3.width = w;
            t.moveRec1.height = t.moveRec2.height = t.moveRec3.height = h;
            t.reLayout();
        };
        /**开始滚动*/
        HangMap.prototype.startMove = function () {
            this.removeEventListener(egret.Event.ENTER_FRAME, this.enterFrameHandler, this);
            this.addEventListener(egret.Event.ENTER_FRAME, this.enterFrameHandler, this);
        };
        /**逐帧运动*/
        HangMap.prototype.enterFrameHandler = function (event) {
            var t = this;
            var curr = egret.getTimer();
            if (curr - t.__lastMoveTime < 30) {
                return;
            }
            t.__lastMoveTime = curr;
            var x1 = t.moveRec1.x + t._speed1;
            var x2 = t.moveRec2.x + t._speed2;
            var x3 = t.moveRec3.x + t._speed3;
            t.setMoveX(x1, x2, x3);
        };
        HangMap.prototype.setMoveX = function (x1, x2, x3) {
            var t = this;
            t.moveRec1.x = x1;
            t.moveRec2.x = x2;
            t.moveRec3.x = x3;
            //判断超出屏幕后，回到队首，这样来实现循环反复，虽然最上面美术没做循环，但是我们做了翻转拼接
            if (t.moveRec1.x < t._imgToX1) {
                t.mover1.scrollRect = t.moveRec1;
            }
            else {
                var result1 = t.bgBmpArr[1];
                if (result1) {
                    t.moveRec1.x = 0;
                    t.mover1.scrollRect = t.moveRec1;
                }
            }
            //判断超出屏幕后，回到队首，这样来实现循环反复
            if (t.moveRec2.x < t._imgToX2) {
                t.mover2.scrollRect = t.moveRec2;
            }
            else {
                var result2 = t.bgBmpArr[1];
                if (result2) {
                    t.moveRec2.x = t.moveRec2.x - result2.width;
                    if (t.moveRec2.x < 0)
                        t.moveRec2.x = 0;
                    t.mover2.scrollRect = t.moveRec2;
                }
            }
            if (t.moveRec3.x < t._imgToX3) {
                t.mover3.scrollRect = t.moveRec3;
            }
            else {
                var result3 = t.bgBmpArr[2];
                if (result3) {
                    t.moveRec3.x = t.moveRec3.x - result3.width;
                    if (t.moveRec3.x < 0)
                        t.moveRec3.x = 0;
                    t.mover3.scrollRect = t.moveRec3;
                }
            }
        };
        /**暂停滚动*/
        HangMap.prototype.pause = function () {
            this.removeEventListener(egret.Event.ENTER_FRAME, this.enterFrameHandler, this);
        };
        HangMap.prototype.dispose = function () {
            this.pause();
            // this.mapPaths.forEach(element =>
            // {
            //     LoaderManager.instance.destoryGroup(element);
            // });
            this.mapPaths.length = 0;
            qmr.DisplayUtils.removeDisplay(this);
            // HangMap.recovryMap(this);
        };
        return HangMap;
    }(egret.DisplayObjectContainer));
    qmr.HangMap = HangMap;
    __reflect(HangMap.prototype, "qmr.HangMap");
})(qmr || (qmr = {}));
//# sourceMappingURL=HangMap.js.map