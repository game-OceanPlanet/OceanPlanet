var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HeroActor = (function (_super) {
        __extends(HeroActor, _super);
        function HeroActor() {
            return _super.call(this) || this;
        }
        HeroActor.prototype.update = function () {
            var t = this;
            t.initBaseActor();
            t.updateBaseActor();
            t.updatePos();
            t.layout();
        };
        /** 初始化卡牌特效 */
        HeroActor.prototype.initBaseActor = function () {
            var t = this;
            t.resPath = qmr.SystemPath.rolePath; //方便怪物共用角色模型，放在一个路径下了
            var state = qmr.Status.IDLE;
            t.baseActor = new qmr.BaseActor(t.resPath, t.onBodyLoad, t, state);
            t.baseActor.touchChildren = false;
            t.addChild(t.baseActor);
        };
        /**  裸体加载完毕 */
        HeroActor.prototype.onBodyLoad = function () {
        };
        /** 更新形象 */
        HeroActor.prototype.updateBaseActor = function () {
            var t = this;
            t.removeActor();
            if (t.modelId > 0) {
                t.addPartAt(qmr.ActorPart.BODY, t.modelId);
            }
        };
        /** 放到指定位置 */
        HeroActor.prototype.updatePos = function () {
            var t = this;
        };
        /** 重新布局 */
        HeroActor.prototype.layout = function () {
            // this.baseActor.x = this._w >> 1;
            // this.baseActor.y = this._h - 10;
        };
        HeroActor.prototype.removeActor = function () {
            if (this.baseActor) {
                this.baseActor.dispos(false);
            }
        };
        return HeroActor;
    }(qmr.BaseMoverActor));
    qmr.HeroActor = HeroActor;
    __reflect(HeroActor.prototype, "qmr.HeroActor");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroActor.js.map