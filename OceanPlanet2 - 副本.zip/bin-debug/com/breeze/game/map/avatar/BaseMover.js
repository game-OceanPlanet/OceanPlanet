var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @description 可走动对象的基类
     *
     */
    var BaseMover = (function (_super) {
        __extends(BaseMover, _super);
        function BaseMover() {
            var _this = _super.call(this) || this;
            _this.moveScale = 1; //移动时动画的频率
            _this.speed = 15;
            _this.moveScale = 1;
            _this.dir = qmr.DirUtil.RIGHT;
            _this.isMoving = false;
            return _this;
        }
        /**
         * @description 玩家移动到某个点
         * @param destX 目标X
         * @param destY 目标Y
         * @param onArrival 到达目的地返回函数
         * @param target 目标
         * @param nearDiatance 代表离目标点多少距离就代表走到了，停止继续移动
         */
        BaseMover.prototype.moveTo = function (destX, destY, onArrival, thisObject, nearDiatance) {
            if (onArrival === void 0) { onArrival = null; }
            if (thisObject === void 0) { thisObject = null; }
            if (nearDiatance === void 0) { nearDiatance = 1; }
            var t = this;
            t.onGo();
            t.destX = Math.floor(destX);
            t.destY = Math.floor(destY);
            t.onArrival = onArrival;
            t.thisObject = thisObject;
            t.nearDiatance = nearDiatance;
            t.disx = t.destX - t.x;
            t.disy = t.destY - t.y;
            t.distance = Math.sqrt(t.disx * t.disx + t.disy * t.disy);
            t.vx = (t.disx / t.distance) * t.speed * t.moveScale;
            t.vx = Math.floor(t.vx);
            t.vy = (t.disy / t.distance) * t.speed * t.moveScale;
            t.vy = Math.floor(t.vy);
            qmr.Ticker.getInstance().unRegisterTick(t.enterFrameMove, t);
            qmr.Ticker.getInstance().registerTick(t.enterFrameMove, t, 33);
        };
        /**
         * @description 每帧移动
         */
        BaseMover.prototype.enterFrameMove = function () {
            var t = this;
            t.disx = t.destX - t.x;
            t.disy = t.destY - t.y;
            t.distance = Math.sqrt(t.disx * t.disx + t.disy * t.disy);
            if (t.distance < 5 || t.distance <= t.nearDiatance) {
                if (t.x != t.destX)
                    t.x = t.destX;
                if (t.y != t.destY)
                    t.y = t.destY;
                qmr.Ticker.getInstance().unRegisterTick(this.enterFrameMove, this);
                t.onStop();
                if (t.onArrival) {
                    t.onArrival.call(t.thisObject);
                }
                return;
            }
            if (Math.abs(t.x - t.destX) < Math.abs(t.vx)) {
                t.vx = t.destX - t.x;
            }
            if (Math.abs(t.y - t.destY) < Math.abs(t.vy)) {
                t.vy = t.destY - t.y;
            }
            if (t.vx != 0) {
                t.x += t.vx;
            }
            if (t.vy != 0) {
                t.y += t.vy;
            }
            t.onMoving();
        };
        /**
         * @description 停止走动
         */
        BaseMover.prototype.stop = function () {
            this.onStop();
            qmr.Ticker.getInstance().unRegisterTick(this.enterFrameMove, this);
        };
        /**
         * @description 当开始走的时候调用，需子类继承实现
         */
        BaseMover.prototype.onGo = function () {
        };
        /**
         * @description 当停止运动的时候调用,需子类继承实现
         */
        BaseMover.prototype.onStop = function () {
        };
        /**
         * @description 当正在走的时候调用,需子类继承实现
         */
        BaseMover.prototype.onMoving = function () {
        };
        /**
         * @description 获取当前方向
         */
        BaseMover.prototype.getDir = function () {
            return this.dir;
        };
        /**
         * @description 资源释放
         */
        BaseMover.prototype.dispos = function () {
            var t = this;
            t.isMoving = false;
            qmr.Ticker.getInstance().unRegisterTick(t.enterFrameMove, t);
            _super.prototype.dispos.call(this);
        };
        return BaseMover;
    }(qmr.BaseObject));
    qmr.BaseMover = BaseMover;
    __reflect(BaseMover.prototype, "qmr.BaseMover");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseMover.js.map