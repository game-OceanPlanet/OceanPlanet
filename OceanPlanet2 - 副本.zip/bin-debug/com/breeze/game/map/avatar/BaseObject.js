var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * @description 场景中基础的显示对象,所有场景中参与排序的物体都要继承此类
     */
    var BaseObject = (function () {
        function BaseObject() {
            this.dy = 0; //动态排序的增量值
            this._touchEnable = false;
            this._isFocus = false;
            this._isMaster = false;
            this.id = {};
            this.range = 0;
            this._isRobot = false;
            this._screenPoint = new egret.Point();
        }
        Object.defineProperty(BaseObject.prototype, "isFocus", {
            /**
             * @description 获取是否被摄像机跟随
             */
            get: function () {
                return this._isFocus;
            },
            /**
             * @description 设置是否被摄像机跟随
             */
            set: function (value) {
                this._isFocus = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "x", {
            /**
             * @description 获取x坐标
             */
            get: function () {
                return this._x;
            },
            /**
             * @description 设置X坐标
             */
            set: function (value) {
                this._x = value;
                if (this._ui != null) {
                    this._ui.x = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "y", {
            /**
             * @description 获取Y坐标
             */
            get: function () {
                return this._y;
            },
            /**
             * @description 设置y坐标
             */
            set: function (value) {
                this._y = value;
                if (this._ui != null) {
                    this._ui.y = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "rotation", {
            /**
             * @description 获取Y坐标
             */
            get: function () {
                if (this._ui) {
                    return this._ui.rotation;
                }
                return 1;
            },
            /**
             * @description 设置y坐标
             */
            set: function (value) {
                if (this._ui != null) {
                    this._ui.rotation = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "ui", {
            /**
             * @description 获取ui显示对象
             */
            get: function () {
                return this._ui;
            },
            /**
             * @description 设置ui显示对象
             */
            set: function (disPlay) {
                this._ui = disPlay;
                if (this._ui) {
                    this._ui.x = this.x;
                    this._ui.y = this.y;
                    this._ui.touchEnabled = this._touchEnable;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 是否精确点击，像素点级判断,方法逻辑应被子类继承实现
         */
        BaseObject.prototype.isPixelClick = function (stageX, stageY) {
            if (this.ui) {
                if (this.ui.hitTestPoint(stageX, stageY)) {
                    return true;
                }
            }
            return false;
        };
        Object.defineProperty(BaseObject.prototype, "sortY", {
            /**
             * @description 获取排序Y
             */
            get: function () {
                return this._y + this.dy;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "filters", {
            /**
             * @description 设置滤镜效果
             */
            set: function (filter) {
                if (this._ui) {
                    this._ui.filters = filter;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "alpha", {
            /**
             * @description 获取透明度
             */
            get: function () {
                if (this.ui) {
                    return this.ui.alpha;
                }
                return 1;
            },
            /**
             * @description 设置透明度
             */
            set: function (value) {
                if (this.ui) {
                    this.ui.alpha = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "touchEnabled", {
            /**
             * @description 设置触摸
             */
            set: function (value) {
                this._touchEnable = value;
                if (this._ui) {
                    this._ui.touchEnabled = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "visible", {
            /**
             * @description 获取当前的可见性
             */
            get: function () {
                if (this._ui) {
                    return this._ui.visible;
                }
                return false;
            },
            /**
             * @description 设置是否可见
             */
            set: function (value) {
                if (this._ui) {
                    this._ui.visible = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "screenPoint", {
            /**
             * @description 获取舞台坐标点
             */
            get: function () {
                if (this._ui && this._ui.parent) {
                    this._ui.parent.localToGlobal(this._x, this._y, this._screenPoint);
                }
                return this._screenPoint;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "isMaster", {
            /**
             * @description 获取master标识
             */
            get: function () {
                return this._isMaster;
            },
            /**
             * @description 设置master
             */
            set: function (value) {
                this._isMaster = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "isQiyue", {
            /**
             * @description 获取契约标识
             */
            get: function () {
                return this._isQiyue;
            },
            /**
             * @description 设置契约
             */
            set: function (value) {
                this._isQiyue = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "isRobot", {
            /**
             * @description 是否是机器人AI
             */
            get: function () {
                return this._isRobot;
            },
            /**
             * @description 是否是机器人AI
             */
            set: function (value) {
                this._isRobot = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseObject.prototype, "isRobotMonster", {
            /**
             * @description 获取是否是机器怪
             */
            get: function () {
                return this._isRobotMonster;
            },
            /**
             * @description 设置是否是机器怪
             */
            set: function (value) {
                this._isRobotMonster = value;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @description 是否在可视区域内,需要被子类继承
         */
        BaseObject.prototype.isInView = function (value) {
        };
        /**
         * @description 资源释放
         */
        BaseObject.prototype.dispos = function () {
            this._isFocus = false;
            this.id = 0;
            if (this._ui) {
                this._ui.filters = null;
                if (this._ui["dispos"]) {
                    this._ui["dispos"]();
                }
                else {
                    if (this._ui.parent) {
                        this._ui.parent.removeChild(this._ui);
                    }
                }
            }
        };
        return BaseObject;
    }());
    qmr.BaseObject = BaseObject;
    __reflect(BaseObject.prototype, "qmr.BaseObject");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseObject.js.map