var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var TombstoneDrop = (function (_super) {
        __extends(TombstoneDrop, _super);
        function TombstoneDrop() {
            return _super.call(this) || this;
            // this.initBase();
        }
        TombstoneDrop.getTombstoneDrop = function () {
            var drop = qmr.Pool.getItemByClass("TombstoneDrop", TombstoneDrop);
            return drop;
        };
        TombstoneDrop.recovryTombstoneDrop = function (drop) {
            qmr.Pool.recover("TombstoneDrop", drop);
        };
        TombstoneDrop.prototype.delayShowEffect = function () {
            qmr.Ticker.getInstance().registerTick(this.showEffect, this, 500, 1);
        };
        TombstoneDrop.prototype.showEffect = function () {
            this.dieffect = qmr.EffectPlayer.playUIEffect("card_die", false, { x: 0, y: 0 }, this);
        };
        TombstoneDrop.prototype.initBase = function () {
            this.img_icon = new eui.Image();
            this.addChild(this.img_icon);
            this.loadImg();
        };
        TombstoneDrop.prototype.loadImg = function () {
            qmr.ResManager.getRes(qmr.SystemPathAft.unpack_battle + "ui_zd_mubei.png", this.onIconLoaded, this, qmr.LoadPriority.HIGH, RES.ResourceItem.TYPE_IMAGE);
        };
        TombstoneDrop.prototype.onIconLoaded = function (texture) {
            this.img_icon.texture = texture;
            this.layout();
        };
        TombstoneDrop.prototype.layout = function () {
            this.img_icon.anchorOffsetX = this.img_icon.width >> 1;
            this.img_icon.anchorOffsetY = this.img_icon.height >> 1;
        };
        TombstoneDrop.prototype.dispose = function () {
            qmr.Ticker.getInstance().unRegisterTick(this.showEffect, this);
            if (this.dieffect) {
                this.dieffect.dispos();
                this.dieffect = null;
            }
            TombstoneDrop.recovryTombstoneDrop(this);
            qmr.DisplayUtils.removeDisplay(this);
        };
        return TombstoneDrop;
    }(egret.DisplayObjectContainer));
    qmr.TombstoneDrop = TombstoneDrop;
    __reflect(TombstoneDrop.prototype, "qmr.TombstoneDrop");
})(qmr || (qmr = {}));
//# sourceMappingURL=TombstoneDrop.js.map