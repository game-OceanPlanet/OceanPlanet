var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var SceneLayerEnum = (function () {
        function SceneLayerEnum() {
        }
        /**地图所在层级*/
        SceneLayerEnum.LAYER_MAP = 'LAYER_MAP';
        /**底部层，比如道具掉落，脚底特效等*/
        SceneLayerEnum.LAYER_BOTTOM = 'LAYER_BOTTOM';
        /**角色层*/
        SceneLayerEnum.LAYER_PLAYER = 'LAYER_PLAYER';
        /**黑色半透明遮罩层,用于释放大招时候盖着下面所有东西*/
        SceneLayerEnum.LAYER_MASK = 'LAYER_MASK';
        /**角色前层，比如飘血,前景特效*/
        SceneLayerEnum.LAYER_FRONT = 'LAYER_FRONT';
        /**最上层，用于大技能*/
        SceneLayerEnum.LAYER_TOP = 'LAYER_TOP';
        return SceneLayerEnum;
    }());
    qmr.SceneLayerEnum = SceneLayerEnum;
    __reflect(SceneLayerEnum.prototype, "qmr.SceneLayerEnum");
})(qmr || (qmr = {}));
//# sourceMappingURL=SceneLayerEnum.js.map