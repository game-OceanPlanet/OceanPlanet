var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var Map = (function (_super) {
        __extends(Map, _super);
        function Map() {
            var _this = _super.call(this) || this;
            // 0：战斗背景，1：主界面背景
            _this.bgType = 0;
            /** 战斗背景一张背景头，一张循环背景背景循环几次都可以 */
            _this.bgHeights = [1600, 1280]; //图片高度
            _this.bgRetimes = [1, 2]; //循环次数
            _this.bgNames = ["bg1_jpg", "bg2_jpg"];
            /**控制滚动速度*/
            _this._speed = 5;
            _this._currSpeed = 5;
            _this.bmpAllHeight = 0;
            _this.moveStarty = 0;
            _this.curWave = 0; //波数
            _this.initBase();
            return _this;
        }
        Map.prototype.initBase = function () {
            this.bgBmpArr = [];
            this.mapPaths = [];
            this.tilesKeys = [];
            this.maskWave = [];
            this.refPoints = [];
            this.moveRec = new egret.Rectangle(0, 0, qmr.StageUtil.stageWidth, qmr.StageUtil.stageHeight);
            this.mover = new egret.DisplayObjectContainer();
            this.mover.scrollRect = this.moveRec;
            this.addChild(this.mover);
            this.touchEnabled = this.touchChildren = false;
            this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
        };
        /**
         * instanceId 副本id
         */
        Map.prototype.loadMap = function (mapId) {
            var _this = this;
            var mapCfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.MAP, mapId);
            if (!mapCfg) {
                qmr.LogUtil.warn("地图配置不存在:" + mapId);
                return;
            }
            this.tilesKeys.length = 0;
            this.maskWave.length = 0;
            this.mapPaths.length = 0;
            this.refPoints.length = 0;
            this.curWave = 0;
            this.bgType = mapCfg.bgType;
            this.bgNames = mapCfg.bgNames.split("|");
            this.bgRetimes = (mapCfg.bgRetimes + "").split("|").map(Number);
            this.bgHeights = (mapCfg.bgHeight + "").split("|").map(Number);
            this.bgLabelEvents = (mapCfg.labelsEvent + "").split("|").map(Number);
            //倒叙加载，因为首先显示下面的图
            var fileName;
            var len = this.bgNames.length;
            var startPosy = 0;
            this.isOneMap = this.bgType == EnumBgType.TYPE_2;
            var stageHeight = qmr.StageUtil.stage.stageHeight;
            var rowCount = 0;
            var repeatCount = 0;
            var mapPath;
            for (var i = 0; i < len; i++) {
                fileName = this.bgNames[i];
                repeatCount = this.bgRetimes[i];
                for (var k = 0; k < repeatCount; k++) {
                    startPosy += this.bgHeights[i];
                    mapPath = qmr.ResPathUtilAft.getMapUrl(fileName);
                    this.tilesKeys[rowCount] = mapPath;
                    this.mapPaths.push(mapPath);
                    rowCount++;
                }
            }
            this.mapPaths.reverse();
            this.mapPaths.forEach(function (element) {
                qmr.ResManager.getRes(element, _this.onMapLoadComplete, _this, qmr.LoadPriority.IMMEDIATELY, RES.ResourceItem.TYPE_IMAGE);
            });
            this.bmpAllHeight = startPosy;
            len = this.bgLabelEvents.length;
            for (var j = 0; j < len; j++) {
                this.refPoints[j] = (this.bmpAllHeight - stageHeight) * this.bgLabelEvents[j] / 100;
            }
            this.addChild(this.mover);
        };
        Map.prototype.onMapLoadComplete = function (texture, url) {
            if (texture) {
                var index = this.tilesKeys.indexOf(url);
                if (index > -1) {
                    this.tilesKeys[index] = "";
                    this.bgBmpArr[index] = this.createBitmapByTexture(texture);
                    var bgIndex = -1;
                    for (var i = 0; i < this.bgNames.length; i++) {
                        if (url.indexOf(this.bgNames[i]) != -1) {
                            bgIndex = i;
                            break;
                        }
                    }
                    if (bgIndex != -1) {
                        if (this.isOneMap) {
                            this.bgHeights[bgIndex] = qmr.StageUtil.stage.stageHeight;
                        }
                        else {
                            this.bgHeights[bgIndex] = texture.textureHeight; //修正原始纹理的高度
                        }
                    }
                    this.reLayout();
                }
            }
        };
        Map.prototype.reLayout = function () {
            //创建这些图片，并设置y坐标，让它们连接起来
            var bgBmp;
            var startPosy = 0;
            var reLen = this.bgRetimes.length;
            var index = 0;
            for (var i = 0; i < reLen; i++) {
                var loop = this.bgRetimes[i];
                for (var k = 0; k < loop; k++) {
                    bgBmp = this.bgBmpArr[index];
                    if (bgBmp) {
                        bgBmp.y = startPosy;
                        //bgBmp.width = StageUtil.stageWidth > 750 ? 750 : StageUtil.stageWidth;
                        bgBmp.width = qmr.StageUtil.stageWidth;
                        if (this.isOneMap && qmr.StageUtil.stageHeight > 1400) {
                            bgBmp.height = qmr.StageUtil.stageHeight;
                        }
                        this.mover.addChild(bgBmp);
                    }
                    startPosy += this.bgHeights[i];
                    index++;
                }
            }
        };
        /**初始化*/
        Map.prototype.onAddToStage = function (event) {
            this.reLayout();
            qmr.NotifyManager.registerNotify(qmr.StageUtil.STAGE_RESIZE, this.onStageResize, this);
            if (this.moveRec) {
                this.moveRec.width = qmr.StageUtil.stageWidth;
                this.moveRec.height = qmr.StageUtil.stageHeight;
            }
        };
        Map.prototype.onStageResize = function (evt) {
            this.moveRec.width = qmr.StageUtil.stageWidth;
            this.moveRec.height = qmr.StageUtil.stageHeight;
            this.moveStarty = this.bmpAllHeight - qmr.StageUtil.stageHeight;
            var len = this.mover.numChildren;
            for (var i = 0; i < len; i++) {
                var bgBmp = this.mover.getChildAt(i);
                if (bgBmp) {
                    if (this.isOneMap && i == 0) {
                        bgBmp.height = qmr.StageUtil.stageHeight;
                    }
                    bgBmp.width = qmr.StageUtil.stageWidth;
                }
            }
        };
        Map.prototype.createBitmapByTexture = function (texture) {
            var result = new egret.Bitmap();
            result.texture = texture;
            return result;
        };
        Map.prototype.dispose = function () {
            // this.mapPath.forEach(element =>
            // {
            //     LoaderManager.instance.destoryGroup(element);
            // });
            // this.mapPath.length = 0;
            // DisplayUtils.removeAllChild(this.mover);
            // DisplayUtils.removeDisplay(this);
            // Map.recovryMap(this);
            qmr.NotifyManager.unRegisterNotify(qmr.StageUtil.STAGE_RESIZE, this.onStageResize, this);
            qmr.DisplayUtils.removeAllChild(this.mover);
            qmr.DisplayUtils.removeDisplay(this);
            // this.mapPaths.forEach(element =>
            // {
            //     LoaderManager.instance.destoryGroup(element);
            // });
            this.tilesKeys.length = 0;
            this.mapPaths.length = 0;
            this.bgBmpArr.length = 0;
            this.refPoints.length = 0;
        };
        return Map;
    }(egret.DisplayObjectContainer));
    qmr.Map = Map;
    __reflect(Map.prototype, "qmr.Map");
    var EnumBgType;
    (function (EnumBgType) {
        EnumBgType[EnumBgType["TYPE_0"] = 0] = "TYPE_0";
        EnumBgType[EnumBgType["TYPE_1"] = 1] = "TYPE_1";
        EnumBgType[EnumBgType["TYPE_2"] = 2] = "TYPE_2";
    })(EnumBgType || (EnumBgType = {}));
})(qmr || (qmr = {}));
//# sourceMappingURL=Map.js.map