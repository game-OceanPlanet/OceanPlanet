var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var Scene = (function (_super) {
        __extends(Scene, _super);
        function Scene() {
            var _this = _super.call(this) || this;
            var t = _this;
            t.mapLayer = new egret.DisplayObjectContainer();
            t.bottomLayer = new egret.DisplayObjectContainer();
            t.objLayer = new egret.DisplayObjectContainer();
            t.frontLayer = new egret.DisplayObjectContainer();
            t.maskLayer = new egret.DisplayObjectContainer();
            t.topLayer = new egret.DisplayObjectContainer();
            t.maskLayer.touchEnabled = t.maskLayer.touchChildren = false;
            t.mapLayer.touchEnabled = t.mapLayer.touchChildren = false;
            t.bottomLayer.touchEnabled = t.bottomLayer.touchChildren = false;
            t.topLayer.touchEnabled = t.topLayer.touchChildren = false;
            t.frontLayer.touchEnabled = t.frontLayer.touchChildren = false;
            t.addChild(t.mapLayer);
            t.addChild(t.bottomLayer);
            t.addChild(t.objLayer);
            t.addChild(t.frontLayer);
            t.addChild(t.maskLayer);
            t.addChild(t.topLayer);
            t.objList = new Array();
            t.camera = new qmr.Camera(qmr.StageUtil.stageWidth, qmr.StageUtil.stageHeight);
            t.camera.init(t);
            t.zeroPoint = new egret.Point(0, 0);
            return _this;
        }
        Scene.prototype.addMaskShape = function () {
            var t = this;
            if (!t.maskShape)
                t.maskShape = new egret.Shape();
            t.maskShape.graphics.beginFill(0, 1);
            t.maskShape.graphics.drawRect(0, 0, qmr.StageUtil.stageWidth, qmr.StageUtil.stageHeight);
            t.maskShape.graphics.endFill();
            t.maskLayer.addChild(t.maskShape);
        };
        Scene.prototype.tweenShowOrHideMask = function (isShow) {
            var t = this;
            if (isShow) {
                t.addMaskShape();
                t.maskShape.alpha = 0;
                t.maskShape.visible = true;
                egret.Tween.get(t.maskShape).to({ alpha: 0.7 }, 100);
            }
            else {
                if (t.maskShape && t.maskShape.visible) {
                    egret.Tween.get(t.maskShape)
                        .to({ alpha: 0 }, 100)
                        .call(function () {
                        t.maskShape.graphics.clear();
                        t.maskShape.visible = false;
                    });
                }
            }
        };
        /** 侦听 */
        Scene.prototype.addListener = function () {
            qmr.NotifyManager.registerNotify(qmr.StageUtil.STAGE_RESIZE, this.onStageResize, this);
        };
        /** 当舞台尺寸发生变化 */
        Scene.prototype.onStageResize = function () {
            var t = this;
            egret.setTimeout(function () {
                t.checkPosition();
            }, this, 500);
        };
        /**
         * @description 校验位置
         */
        Scene.prototype.checkPosition = function () {
            this.camera.updateSize(qmr.StageUtil.stageWidth, qmr.StageUtil.stageHeight);
        };
        /**
         * @description 调整摄像头，聚焦到某个坐标
         */
        Scene.prototype.lookAt = function (pos, time, waitTime) {
            if (time === void 0) { time = 700; }
            if (waitTime === void 0) { waitTime = 3000; }
            if (pos) {
                var t = this;
                this.camera.setAnchor(pos);
                egret.Tween.removeTweens(t);
                egret.Tween.get(this).
                    to({ scaleX: 1.6, scaleY: 1.6 }, time, egret.Ease.circOut).
                    wait(waitTime).
                    to({ scaleX: 1, scaleY: 1 }, time, egret.Ease.cubicOut);
            }
        };
        Scene.prototype.removeTween = function () {
            var t = this;
            egret.Tween.removeTweens(t);
            t.scaleX = t.scaleY = 1;
            this.camera.setAnchor(this.zeroPoint);
        };
        /** 根据id返回对应的BaseObject */
        Scene.prototype.findBaseObjectById = function (id) {
            for (var _i = 0, _a = this.objList; _i < _a.length; _i++) {
                var item = _a[_i];
                if (qmr.MathUtil.equal(item.id, id)) {
                    return item;
                }
            }
            return null;
        };
        /** 移除一个BaseObject通过id,单纯从显示列表移除 */
        Scene.prototype.removeBaseObjectById = function (id) {
            for (var _i = 0, _a = this.objList; _i < _a.length; _i++) {
                var item = _a[_i];
                if (qmr.MathUtil.equal(id, item.id)) {
                    var index = this.objList.indexOf(item);
                    if (index != -1) {
                        this.objList.splice(index, 1);
                        item.dispos();
                        item = null;
                        break;
                    }
                }
            }
        };
        /** 移除一个BaseObject,通过引用对象本身,单纯从显示列表移除 */
        Scene.prototype.removeBaseObject = function (item) {
            if (item) {
                var index = this.objList.indexOf(item);
                if (index != -1) {
                    this.objList.splice(index, 1);
                }
                if (item instanceof qmr.HeroActor) {
                    qmr.LogUtil.logF("移除对象数量:-----" + this.objList.length + " " + index + " " + item.fighterId);
                }
                item.dispos();
                item = null;
            }
        };
        /** 添加一个baseObject到场景中 */
        Scene.prototype.addObject = function (obj) {
            if (this.objList.indexOf(obj) == -1) {
                obj.scene = this;
                this.objList.push(obj);
                if (obj.ui) {
                    qmr.LogUtil.logF('添加一个baseObject到场景中' + obj.id);
                    this.addObjectLayer(obj.ui);
                }
            }
            else {
                qmr.LogUtil.logF('场景上已经存在了');
            }
        };
        /** 添加到最上层 */
        Scene.prototype.addObjectToTop = function (obj) {
            if (this.objList.indexOf(obj) == -1) {
                obj.scene = this;
                this.objList.push(obj);
            }
            if (obj && obj.ui) {
                this.addObjectLayer(obj.ui);
            }
        };
        /** 添加到地图层 */
        Scene.prototype.addToMap = function (disPlay) {
            this.mapLayer.addChild(disPlay);
        };
        /** 添加显示对象到底部层 */
        Scene.prototype.addToBottom = function (disPlay) {
            this.bottomLayer.addChild(disPlay);
        };
        /** 添加显示对象层 */
        Scene.prototype.addObjectLayer = function (disPlay) {
            this.objLayer.addChild(disPlay);
        };
        /** 添加显示对象到前景层 */
        Scene.prototype.addToFront = function (disPlay) {
            this.frontLayer.addChild(disPlay);
        };
        /** 添加到最上层  */
        Scene.prototype.addToTop = function (disPlay) {
            this.topLayer.addChild(disPlay);
        };
        /** 显示或隐藏排序最上层 */
        Scene.prototype.showOrHideTopLayer = function (value) {
            this.topLayer.visible = value;
        };
        /** 根据类型获取BaseObject列表 */
        Scene.prototype.getObjectListByType = function (type) {
            var list = [];
            for (var _i = 0, _a = this.objList; _i < _a.length; _i++) {
                var object = _a[_i];
                if (object.type == type) {
                    list.push(object);
                }
            }
            return list;
        };
        /** 获取obj的物体坐标 */
        Scene.prototype.getObjGlobalPoint = function (obj) {
            return this.objLayer.localToGlobal(obj.x, obj.y);
        };
        /**
         * @description 获取物体列表
         */
        Scene.prototype.getObjectList = function () {
            return this.objList;
        };
        /**
         * @description 停止渲染场景
         */
        Scene.prototype.pause = function () {
            if (this.mapLayer.parent) {
                this.mapLayer.parent.removeChild(this.mapLayer);
            }
            if (this.bottomLayer.parent) {
                this.bottomLayer.parent.removeChild(this.bottomLayer);
            }
            if (this.objLayer.parent) {
                this.objLayer.parent.removeChild(this.objLayer);
            }
            if (this.topLayer.parent) {
                this.topLayer.parent.removeChild(this.topLayer);
            }
            if (this.frontLayer.parent) {
                this.frontLayer.parent.removeChild(this.frontLayer);
            }
        };
        /**
         * @description 重新渲染场景
         */
        Scene.prototype.resume = function () {
            this.addChild(this.mapLayer);
            this.addChild(this.bottomLayer);
            this.addChild(this.objLayer);
            this.addChild(this.topLayer);
            this.addChild(this.frontLayer);
        };
        Scene.prototype.removeAllBottomObj = function () {
            var bottomLayer = this.bottomLayer;
            while (bottomLayer.numChildren > 0) {
                var item = bottomLayer.getChildAt(0);
                if (item instanceof qmr.TombstoneDrop) {
                    item.dispose();
                    item = null;
                }
                else if (item instanceof qmr.BaseEffect) {
                    item.dispos();
                    item = null;
                }
                else {
                    qmr.DisplayUtils.removeDisplay(item);
                }
            }
        };
        /**
         * @description 清除当前场景所有物体
         */
        Scene.prototype.clear = function () {
            var t = this;
            t.removeTween();
            t.removeAllBottomObj();
            t.frontLayer.removeChildren();
            var objList = t.objList;
            if (objList) {
                while (objList.length > 0) {
                    var item = objList.shift();
                    if (item) {
                        item.dispos();
                        item = null;
                    }
                }
            }
            if (t.maskShape && t.maskShape.visible) {
                t.maskShape.graphics.clear();
                t.maskShape.visible = false;
            }
        };
        return Scene;
    }(eui.UILayer));
    qmr.Scene = Scene;
    __reflect(Scene.prototype, "qmr.Scene");
})(qmr || (qmr = {}));
//# sourceMappingURL=Scene.js.map