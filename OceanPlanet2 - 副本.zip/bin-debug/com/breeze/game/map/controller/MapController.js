var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * 场景对象管理器
     * */
    var MapController = (function (_super) {
        __extends(MapController, _super);
        function MapController() {
            var _this = _super.call(this) || this;
            _this.playerInfos = new qmr.Dictionary();
            _this.playerUnits = new qmr.Dictionary();
            return _this;
        }
        Object.defineProperty(MapController, "instance", {
            /**  获取单例对象  */
            get: function () {
                if (this._instance == null) {
                    this._instance = new MapController();
                }
                return this._instance;
            },
            enumerable: true,
            configurable: true
        });
        MapController.prototype.initListeners = function () {
            var t = this;
        };
        MapController.prototype.addPlayer = function (info) {
            var t = this;
            t.playerInfos.set(info.id, info);
            var actor = t.playerUnits.get(info.id);
            if (!actor) {
                actor = qmr.PetActor.getPetActor();
            }
            actor.update(info);
            qmr.SceneManager.instance.addObject(actor);
            t.addShowActorTween(actor);
        };
        MapController.prototype.removePlayer = function (id) {
            var t = this;
            var actor = t.playerUnits.get(id);
            if (actor) {
                actor.dispos();
                qmr.PetActor.recovryPetActor(actor);
            }
            t.playerUnits.remove(id);
            t.playerInfos.remove(id);
            qmr.SceneManager.instance.removeBaseObjectById(id);
        };
        MapController.prototype.addShowActorTween = function (actor) {
            egret.Tween.get(actor).to({ alpha: 1 }, 1000).wait(50)
                .call(function () {
                egret.Tween.removeTweens(actor);
            });
        };
        MapController.prototype.getPetPosition = function (id) {
            var p = new egret.Point(500 * Math.random(), 1000 * Math.random());
            if (id > 7) {
                p.x = 0;
            }
            p.y = p.y < 300 ? 200 + Math.random() * 600 : p.y;
            if (id == 15) {
                p.x = 300;
                p.y = 400;
            }
            return p;
        };
        return MapController;
    }(qmr.BaseController));
    qmr.MapController = MapController;
    __reflect(MapController.prototype, "qmr.MapController");
})(qmr || (qmr = {}));
//# sourceMappingURL=MapController.js.map