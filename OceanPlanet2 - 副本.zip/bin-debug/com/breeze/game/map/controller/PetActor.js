var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PetActor = (function (_super) {
        __extends(PetActor, _super);
        function PetActor() {
            return _super.call(this) || this;
        }
        PetActor.getPetActor = function () {
            var actor = qmr.Pool.getItemByClass("PetActor", PetActor);
            return actor;
        };
        PetActor.recovryPetActor = function (actor) {
            qmr.Pool.recover("PetActor", actor);
        };
        PetActor.prototype.update = function (info) {
            var t = this;
            t.petInfo = info;
            t.id = info.id;
            t.modelId = info.modelId;
            t.initBaseActor();
            t.updateBaseActor();
            t.updatePos();
            t.layout();
        };
        /** 初始化角色模型 */
        PetActor.prototype.initBaseActor = function () {
            var t = this;
            if (!t.baseActor) {
                t.resPath = qmr.SystemPath.rolePath; //方便怪物共用角色模型，放在一个路径下了
                var action = Number(t.petInfo.modelId) == 115 ? qmr.Status.IDLE : qmr.Status.MOVE;
                t.baseActor = new qmr.BaseActor(t.resPath, t.onBodyLoad, t, action);
                t.baseActor.touchChildren = false;
                t.addChild(t.baseActor);
            }
        };
        /**  裸体加载完毕 */
        PetActor.prototype.onBodyLoad = function () {
        };
        /** 更新形象 */
        PetActor.prototype.updateBaseActor = function () {
            var t = this;
            t.removeActor();
            if (t.petInfo && t.petInfo.modelId > 0) {
                var modelId = t.petInfo.modelId;
                t.addPartAt(qmr.ActorPart.BODY, modelId);
            }
        };
        /** 放到指定位置 */
        PetActor.prototype.updatePos = function () {
            var t = this;
            if (t.petInfo) {
                var p = qmr.MapController.instance.getPetPosition(t.petInfo.fishId);
                t.x = p.x;
                t.y = p.y;
            }
        };
        /** 重新布局 */
        PetActor.prototype.layout = function () {
            // this.baseActor.x = this._w >> 1;
            // this.baseActor.y = this._h - 10;
        };
        PetActor.prototype.removeActor = function () {
            if (this.baseActor) {
                this.baseActor.dispos(false);
            }
        };
        PetActor.prototype.dispos = function () {
            _super.prototype.dispos.call(this);
        };
        return PetActor;
    }(qmr.BaseMoverActor));
    qmr.PetActor = PetActor;
    __reflect(PetActor.prototype, "qmr.PetActor");
})(qmr || (qmr = {}));
//# sourceMappingURL=PetActor.js.map