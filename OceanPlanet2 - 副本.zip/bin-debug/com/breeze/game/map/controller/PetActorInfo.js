var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var PetActorInfo = (function () {
        function PetActorInfo() {
        }
        PetActorInfo.prototype.setData = function (pro) {
            var t = this;
            t.id = qmr.Int64Util.getNumber(pro.id);
            t.level = pro.level;
            t.fishId = qmr.Int64Util.getNumber(pro.fishId);
            t.state = pro.state;
            t._allMoney = qmr.Int64Util.getNumber(pro.allMoney);
            t._extMoney = qmr.Int64Util.getNumber(pro.extMoney);
            t._leftMoney = qmr.Int64Util.getNumber(pro.leftMoney);
            t._todayGotMoney = qmr.Int64Util.getNumber(pro.todayGotMoney);
            t._todayCurMoney = qmr.Int64Util.getNumber(pro.todayCurMoney);
            t.allDay = pro.allDay;
        };
        Object.defineProperty(PetActorInfo.prototype, "allMoney", {
            get: function () {
                return this._allMoney / qmr.HeroModel.TIMES;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "extMoney", {
            get: function () {
                return this._extMoney / qmr.HeroModel.TIMES;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "leftMoney", {
            get: function () {
                return this._leftMoney / qmr.HeroModel.TIMES;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "todayGotMoney", {
            get: function () {
                return this._todayGotMoney / qmr.HeroModel.TIMES;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "todayCurMoney", {
            get: function () {
                return this._todayCurMoney / qmr.HeroModel.TIMES;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "config", {
            get: function () {
                var t = this;
                if (!t._cfg && t.fishId && t.fishId > 0) {
                    t._cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, t.fishId);
                }
                return t._cfg;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetActorInfo.prototype, "modelId", {
            get: function () {
                var t = this;
                var cfg = t.config;
                if (cfg) {
                    return parseInt(cfg.resId);
                }
                return 0;
            },
            enumerable: true,
            configurable: true
        });
        return PetActorInfo;
    }());
    qmr.PetActorInfo = PetActorInfo;
    __reflect(PetActorInfo.prototype, "qmr.PetActorInfo");
})(qmr || (qmr = {}));
//# sourceMappingURL=PetActorInfo.js.map