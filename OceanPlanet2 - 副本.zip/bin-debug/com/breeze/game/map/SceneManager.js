var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var SceneManager = (function () {
        function SceneManager() {
            this.__mapType = 0;
            this.count = 0;
            this._oldx = 0;
            this._oldy = 0;
            this._isShake = false;
            this.initScene();
        }
        Object.defineProperty(SceneManager, "instance", {
            get: function () {
                if (this._instance == null) {
                    this._instance = new SceneManager;
                }
                return this._instance;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SceneManager.prototype, "HangMap", {
            get: function () {
                if (!this._hangMap) {
                    this._hangMap = new qmr.HangMap();
                }
                return this._hangMap;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SceneManager.prototype, "Map", {
            get: function () {
                if (!this._map) {
                    this._map = new qmr.Map();
                }
                return this._map;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SceneManager.prototype, "mapType", {
            get: function () {
                return this.__mapType;
            },
            set: function (type) {
                this.__mapType = type;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SceneManager.prototype, "isInHangMap", {
            get: function () {
                return this.mapType == SceneManager.MAP_HANG;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SceneManager.prototype, "isInFightMap", {
            get: function () {
                return this.mapType == SceneManager.MAP_FIGHT;
            },
            enumerable: true,
            configurable: true
        });
        /**
       * @description 初始化场景数据模型
       */
        SceneManager.prototype.initScene = function () {
            this.scene = new qmr.Scene();
        };
        /** 进入挂机地图 */
        SceneManager.prototype.enterHangMap = function (chapterId) {
            if (chapterId === void 0) { chapterId = 0; }
            var t = this;
            if (t.mapType == SceneManager.MAP_HANG && chapterId == t._chapterId) {
                return;
            }
            t.mapType = SceneManager.MAP_HANG;
            // DisplayUtils.removeDisplay(this.scene);
            t._chapterId = chapterId;
            //战斗背景层
            var map = t.HangMap;
            map.x = 0;
            map.y = 52;
            map.loadMap(chapterId);
            var mapCfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.XINHANGUP, chapterId);
            if (mapCfg) {
                qmr.SoundManager.getInstance().loadAndPlayMusic(mapCfg.music);
            }
            if (!map.parent) {
                SceneManager.instance.addToMap(map);
            }
            if (!t.scene.parent) {
                qmr.LayerManager.instance.addDisplay(t.scene, qmr.LayerConst.MAP_LAYER);
            }
            t.leaveMap();
        };
        /** 进入地图instanceId 副本id/角色id */
        SceneManager.prototype.enterMap = function (instanceId, chapterMap) {
            if (chapterMap === void 0) { chapterMap = 0; }
            var t = this;
            // DisplayUtils.removeDisplay(this.scene);
            if (t.mapType == SceneManager.MAP_FIGHT && instanceId == t._instanceId && t._mapId == chapterMap) {
                return;
            }
            t.mapType = SceneManager.MAP_FIGHT;
            t._instanceId = instanceId;
            t._mapId = chapterMap;
            //战斗背景层
            var map = t.Map;
            map.x = map.y = 0;
            // map.alpha = 1;
            // let isBattlePlayer = BattleMainModel.instance.isBattlePlayer;
            // if (isBattlePlayer)
            // {
            // 	if(!BattleMainModel.instance.mapId)
            // 	{
            // 		BattleMainModel.instance.mapId = parseInt(ConfigManager.getCommonConfig(1096));
            // 	}
            // 	map.loadMap(BattleMainModel.instance.mapId);
            // }
            // else
            // {
            // 	let instanceCfg: InstanceCfg = CopyModel.instance.getCopyCfgData(instanceId);
            // 	if (instanceCfg)
            // 	{
            // 		var mid = chapterMap > 0 ? chapterMap : instanceCfg.mapId;
            // 		if(!mid) mid = parseInt(ConfigManager.getCommonConfig(1096));
            // 		map.loadMap(mid);
            // 		SoundManager.getInstance().loadAndPlayMusic(instanceCfg.music);
            // 	}
            // }
            if (!map.parent) {
                SceneManager.instance.addToMap(map);
            }
            if (!t.scene.parent) {
                qmr.LayerManager.instance.addDisplay(t.scene, qmr.LayerConst.MAP_LAYER);
            }
            qmr.LogUtil.log("战斗:加载战斗地图，准备退出挂机地图", t._mapId, instanceId);
            t.leaveHangMap();
        };
        SceneManager.prototype.removeHangMap = function () {
            var t = this;
            if (t._hangMap) {
                var alphaDisappear = function () {
                    if (t._hangMap) {
                        t._hangMap.dispose();
                    }
                };
                t._map.alpha = 0.5;
                egret.Tween.get(t._map).to({ alpha: 1 }, 200).call(alphaDisappear, t);
            }
        };
        SceneManager.prototype.removeFightMap = function () {
            var t = this;
            if (t._map) {
                var alphaDisappear = function () {
                    if (t._map) {
                        t._map.dispose();
                    }
                };
                var map = t.HangMap;
                map.alpha = 0.5;
                egret.Tween.get(map).to({ alpha: 1 }, 200).call(alphaDisappear, t);
            }
        };
        /** 离开地图 */
        SceneManager.prototype.leaveHangMap = function () {
            if (this.scene) {
                if (this._hangMap) {
                    this._hangMap.dispose();
                    qmr.LogUtil.log("战斗:leave hangMap");
                }
            }
        };
        /** 离开地图 */
        SceneManager.prototype.leaveMap = function () {
            if (this.scene) {
                if (this._map) {
                    this._map.dispose();
                }
            }
        };
        /** 设置观察者 */
        SceneManager.prototype.lookAt = function (pos, scaleTime, waitTime) {
            if (scaleTime === void 0) { scaleTime = 700; }
            if (waitTime === void 0) { waitTime = 1000; }
            if (this.scene && pos) {
                this.scene.lookAt(pos, scaleTime, waitTime);
            }
        };
        Object.defineProperty(SceneManager.prototype, "mapLayer", {
            get: function () {
                return qmr.LayerManager.instance.getLayer(qmr.LayerConst.MAP_LAYER);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @description 震屏
         */
        SceneManager.prototype.shake = function (shakeTime) {
            if (shakeTime === void 0) { shakeTime = 200; }
            var t = this;
            t.removeShake();
            t._isShake = true;
            var obj = t.scene;
            t._oldx = obj.x;
            t._oldy = obj.y;
            qmr.TweenEffectUtil.shake2(obj, shakeTime);
            qmr.Ticker.getInstance().registerTick(t.resetShakePos, t, shakeTime, 1);
        };
        SceneManager.prototype.resetShakePos = function () {
            if (this._isShake) {
                this._isShake = false;
                this.scene.x = this._oldx;
                this.scene.x = this._oldy;
            }
        };
        //特殊情况下需要触发移除震屏
        SceneManager.prototype.removeShake = function () {
            if (this._isShake) {
                egret.Tween.removeTweens(this.scene);
                qmr.Ticker.getInstance().unRegisterTick(this.resetShakePos, this);
                this.resetShakePos();
            }
        };
        /** 有的技能释放时候屏幕黑一会 */
        SceneManager.prototype.tweenShowOrHideMask = function (isShow) {
            if (this.scene) {
                this.scene.tweenShowOrHideMask(isShow);
            }
        };
        /** 攻击结果返回,飘数字用 */
        SceneManager.prototype.onAttackResultBack = function (actor, fighterMsg, rate) {
            if (rate === void 0) { rate = 1; }
            if (actor && fighterMsg) {
                var type = fighterMsg.beHurtMsg.type;
                var value = (fighterMsg.beHurtMsg.value * rate) | 0;
                if (actor instanceof qmr.HeroActor) {
                    actor.catcheState(fighterMsg.beginState, fighterMsg.endState);
                    // actor.updateHitOverProperty();
                    actor.onPlayHit();
                }
                qmr.FloatManager.createFloatHp(type, value, actor.x, actor.y, 1, 2);
            }
        };
        /** 添加到地图层 */
        SceneManager.prototype.addToMap = function (disPlay) {
            this.scene.addToMap(disPlay);
        };
        /** 添加到角色下层 */
        SceneManager.prototype.addToBottom = function (disPlay) {
            this.scene.addToBottom(disPlay);
        };
        /** 添加到角色层 */
        SceneManager.prototype.addObject = function (baseObject) {
            this.scene.addObject(baseObject);
        };
        /** 添加到角色层 */
        SceneManager.prototype.addObjectToTop = function (baseObject) {
            this.scene.addObjectToTop(baseObject);
        };
        /** 添加到角色层之上，比如飘血,前景特效 */
        SceneManager.prototype.addToFront = function (disPlay) {
            this.scene.addToFront(disPlay);
        };
        /** 添加显示到物体前层，用于大技能  */
        SceneManager.prototype.addToTop = function (disPlay) {
            this.scene.addToTop(disPlay);
        };
        /**
         * @description 根据Id获取一个BaseObject
         */
        SceneManager.prototype.getBaseObjectByid = function (id) {
            return this.scene.findBaseObjectById(id);
        };
        /**
         * @description 根据类型获取一个BaseObject数组
         */
        SceneManager.prototype.getObjectListByType = function (type) {
            return this.scene.getObjectListByType(type);
        };
        /**
         * @description 根据Id删除一个BaseObject
         */
        SceneManager.prototype.removeBaseObjectById = function (id) {
            this.scene.removeBaseObjectById(id);
        };
        /**
         * @description 清除怪
         */
        SceneManager.prototype.clearMonster = function () {
            var actorList = this.scene.getObjectListByType(ActorType.MONSTER);
            while (actorList.length > 0) {
                var item = actorList.shift();
                this.removeBaseObject(item);
            }
        };
        /** 移除掉落层物品 */
        SceneManager.prototype.removeAllBottomObj = function () {
            this.scene.removeAllBottomObj();
        };
        /**
         * @description 获取当前渲染的列表
         */
        SceneManager.prototype.getRenderList = function () {
            return this.scene.getObjectList();
        };
        /**
        * @description 停止渲染场景
        */
        SceneManager.prototype.pause = function () {
            this.scene.pause();
        };
        /**
         * @description 重新渲染场景
         */
        SceneManager.prototype.resume = function () {
            this.scene.resume();
        };
        /**
        * @description 根据对象本身移除一个BaseObject
        */
        SceneManager.prototype.removeBaseObject = function (baseObject) {
            this.scene.removeBaseObject(baseObject);
        };
        SceneManager.prototype.removeAll = function () {
            if (this.scene) {
                this.scene.clear();
            }
        };
        //地图类型   0 挂机  1 战斗
        SceneManager.MAP_HANG = 0;
        SceneManager.MAP_FIGHT = 1;
        return SceneManager;
    }());
    qmr.SceneManager = SceneManager;
    __reflect(SceneManager.prototype, "qmr.SceneManager");
})(qmr || (qmr = {}));
//# sourceMappingURL=SceneManager.js.map