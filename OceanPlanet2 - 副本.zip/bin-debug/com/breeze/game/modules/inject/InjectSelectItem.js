var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var InjectSelectItem = (function (_super) {
        __extends(InjectSelectItem, _super);
        function InjectSelectItem() {
            var _this = _super.call(this) || this;
            _this.skinName = "InjectListItemSkin";
            return _this;
        }
        InjectSelectItem.prototype.dataChanged = function () {
            var t = this;
            var cfg = t.data;
            if (cfg) {
                t.txt_cycle.text = cfg.des + "/权重" + cfg.weights;
            }
        };
        return InjectSelectItem;
    }(eui.ItemRenderer));
    qmr.InjectSelectItem = InjectSelectItem;
    __reflect(InjectSelectItem.prototype, "qmr.InjectSelectItem");
})(qmr || (qmr = {}));
//# sourceMappingURL=InjectSelectItem.js.map