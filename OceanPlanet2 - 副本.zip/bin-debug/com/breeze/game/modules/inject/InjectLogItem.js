var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var InjectLogItem = (function (_super) {
        __extends(InjectLogItem, _super);
        function InjectLogItem() {
            var _this = _super.call(this) || this;
            _this.skinName = "InjectLogItemSkin";
            return _this;
        }
        InjectLogItem.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
        };
        InjectLogItem.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.INJECTCYCLE, pro.cycleId);
                var dt = new Date();
                var endTime = qmr.Int64Util.getNumber(pro.endTime);
                t.txt_count.text = qmr.NumberUtil.getFloat4Number2String(pro.KADCount) + qmr.HeroModel.KAD;
                dt.setTime(qmr.Int64Util.getNumber(pro.createTime));
                t.txt_start.text = qmr.TimeUtil.formatColumnDate(dt);
                dt.setTime(endTime);
                // t.txt_end.text = TimeUtil.formatColumnDate(dt);
                t.txt_end.text = cfg.des + "/权重" + cfg.weights;
                t.txt_state.text = endTime > qmr.ServerTime.serverTime ? "进行中" : "已到期";
            }
        };
        return InjectLogItem;
    }(eui.ItemRenderer));
    qmr.InjectLogItem = InjectLogItem;
    __reflect(InjectLogItem.prototype, "qmr.InjectLogItem");
})(qmr || (qmr = {}));
//# sourceMappingURL=InjectLogItem.js.map