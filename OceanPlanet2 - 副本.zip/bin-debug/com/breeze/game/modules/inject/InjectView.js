var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var InjectView = (function (_super) {
        __extends(InjectView, _super);
        function InjectView() {
            var _this = _super.call(this) || this;
            _this._injectNum = 0;
            _this.selecteWightId = 0;
            _this.qmrSkinName = "InjectSkin";
            _this.isNeedMask = true;
            _this.helpId = qmr.HelpId.ID_2;
            return _this;
        }
        InjectView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.InjectLogItem;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
            t.text_input_price.restrict = "0-9";
        };
        InjectView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
            qmr.DividendController.instance.requestInjectInfoCMD();
        };
        InjectView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.addClickEvent(t.btn_exchange_group, t.onInjectClick, t);
            t.addClickEvent(t.btn_stepSelected, t.onStepClick, t);
            t.addEvent(t.text_input_price, egret.Event.FOCUS_OUT, t.onFocusOut, t);
            t.addEvent(t.text_input_price, egret.Event.CHANGE, t.onTextInputChange, t);
            t.registerNotify(qmr.NotifyConst.S_BUY_FISH, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_INJECT_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_INJECT_KAD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.SELECT_ITEM_SELECTED, t.onStepSelected, t);
        };
        InjectView.prototype.onStepSelected = function (cfg) {
            if (cfg) {
                this.txt_button_buy.text = cfg.des + "/权重" + cfg.weights;
                this.selecteWightId = cfg.id;
            }
        };
        InjectView.prototype.onTextInputChange = function (evt) {
            var str = evt.target.text;
            if (qmr.RegexpUtil.IsNull(str)) {
                return;
            }
            if (!qmr.RegexpUtil.IsInteger(str)) {
                return;
            }
            this._injectNum = Number(str.trim());
        };
        InjectView.prototype.onFocusOut = function () {
        };
        InjectView.prototype.onInjectClick = function () {
            if (this._injectNum <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonTip("输入KAD数量有误");
                return;
            }
            if (this._injectNum > qmr.HeroModel.instance.totalKAD) {
                qmr.TipManagerCommon.getInstance().createCommonTip("对不起您的KAD不足");
                return;
            }
            if (this.selecteWightId <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonTip("对不起您选择的权重有误");
                return;
            }
            qmr.DividendController.instance.requestInjectCMD(this._injectNum, this.selecteWightId);
        };
        InjectView.prototype.onStepClick = function () {
            this.selectView.show(true);
        };
        InjectView.prototype.updateView = function () {
            var t = this;
            var md = qmr.DividendModel.instance;
            t.txt_kda_total.text = qmr.NumberUtil.getFloat6Number2String(md.allInject);
            var myTotal = 0;
            var logs = md.injectLogs;
            if (logs && logs.length > 0) {
                for (var i = 0; i < logs.length; i++) {
                    myTotal += logs[i].KADCount;
                }
            }
            var total = md.allInject;
            if (total > 0 && myTotal > 0) {
                t.txt_MyPercent.text = qmr.NumberUtil.getFloat6Number2String(myTotal / total) + "%";
                t.txt_selfTotal.text = qmr.NumberUtil.getFloat6Number2String(myTotal) + qmr.HeroModel.KAD;
            }
            else {
                t.txt_MyPercent.text = "0%";
                t.txt_selfTotal.text = "0" + qmr.HeroModel.KAD;
            }
            t.txt_personnum.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalKAD) + qmr.HeroModel.KAD;
            if (logs) {
                logs.sort(function (a, b) {
                    return qmr.Int64Util.getNumber(b.createTime) - qmr.Int64Util.getNumber(a.createTime);
                });
            }
            t._arrCollection.replaceAll(logs);
        };
        InjectView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return InjectView;
    }(qmr.BaseModule));
    qmr.InjectView = InjectView;
    __reflect(InjectView.prototype, "qmr.InjectView");
})(qmr || (qmr = {}));
//# sourceMappingURL=InjectView.js.map