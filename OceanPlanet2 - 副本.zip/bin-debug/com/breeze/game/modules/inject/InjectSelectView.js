var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var InjectSelectView = (function (_super) {
        __extends(InjectSelectView, _super);
        function InjectSelectView() {
            var _this = _super.call(this) || this;
            _this.__selectIndex = 0;
            _this.__state = 0;
            _this.skinName = "InjectListSkin";
            return _this;
        }
        /** 初始化组件  */
        InjectSelectView.prototype.initComponent = function () {
            _super.prototype.initComponent.call(this);
            var t = this;
            t.rank_list.itemRenderer = qmr.InjectSelectItem;
            t._arrCollection = new eui.ArrayCollection();
            t.rank_list.dataProvider = t._arrCollection;
            t.stepTxt.text = "";
            t.dropListGroup.visible = false;
        };
        InjectSelectView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addEvent(t.rank_list, eui.ItemTapEvent.ITEM_TAP, t.onClickItem, t);
            t.selectBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, t.onClicSelectBtn, t);
            if (t.stage)
                t.stage.addEventListener(egret.TouchEvent.TOUCH_TAP, t.onTouch, t);
        };
        /** 初始化数据 */
        InjectSelectView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            var cfgs = qmr.ConfigManager.getBean(qmr.ConfigEnum.INJECTCYCLE).values;
            t._arrCollection.source = cfgs;
        };
        InjectSelectView.prototype.setSelectStep = function (step) {
            var t = this;
        };
        InjectSelectView.prototype.show = function (vis) {
            this.dropListGroup.visible = vis;
        };
        InjectSelectView.prototype.onClickItem = function (e) {
            var t = this;
            var info = e.item;
            var item = e.itemRenderer;
            if (!info || !item) {
                return;
            }
            var cfg = item.data;
            t.__selectIndex = t.rank_list.selectedIndex;
            t.stepTxt.text = info;
            t.dropListGroup.visible = false;
            t.setSelectStep(t.__selectIndex);
            t.dispatch(qmr.NotifyConst.SELECT_ITEM_SELECTED, cfg);
        };
        InjectSelectView.prototype.onClicSelectBtn = function (e) {
            var t = this;
            e.preventDefault();
            t.__state = t.__state == 0 ? 1 : 0;
            t.updatePanel();
        };
        InjectSelectView.prototype.onTouch = function (e) {
            var t = this;
            // if(t.__state == 0){
            // 	return;
            // }
            var target = e.target;
            if (target == t.selectBtn) {
                return;
            }
            if (target == t.dropListGroup) {
                return;
            }
            if (target == t.rank_list) {
                return;
            }
            if (target instanceof qmr.InjectSelectItem) {
                return;
            }
            var p = target.parent;
            if (p && p instanceof qmr.InjectSelectItem) {
                return;
            }
            t.__state = 0;
            t.updatePanel();
        };
        InjectSelectView.prototype.updatePanel = function () {
            var t = this;
            t.dropListGroup.visible = t.__state == 1;
        };
        InjectSelectView.prototype.dispose = function () {
            var t = this;
            _super.prototype.dispose.call(this);
            if (t.stage)
                t.stage.removeEventListener(egret.TouchEvent.TOUCH_TAP, t.onTouch, t);
        };
        return InjectSelectView;
    }(qmr.UIComponent));
    qmr.InjectSelectView = InjectSelectView;
    __reflect(InjectSelectView.prototype, "qmr.InjectSelectView");
})(qmr || (qmr = {}));
//# sourceMappingURL=InjectSelectView.js.map