var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var ShopItemRender = (function (_super) {
        __extends(ShopItemRender, _super);
        function ShopItemRender() {
            var _this = _super.call(this) || this;
            _this.skinName = "ShopItemSkin";
            return _this;
        }
        ShopItemRender.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
            qmr.DisplayUtils.addClick(t.btn_buy_group, t.onBuyClick, t);
            qmr.DisplayUtils.addClick(t.btn_buy_group2, t.onBuyClick2, t);
        };
        ShopItemRender.prototype.onBuyClick = function () {
            var cfg = this.data;
            if (!cfg) {
                return;
            }
            if (cfg.price > qmr.HeroModel.instance.totalMoney) {
                qmr.TipManagerCommon.getInstance().createCommonTip("货币不足");
                return;
            }
            qmr.PetController.instance.getBuyFish(cfg.id);
        };
        ShopItemRender.prototype.onBuyClick2 = function () {
            var cfg = this.data;
            if (!cfg) {
                return;
            }
            if (cfg.UBuyPrice > qmr.HeroModel.instance.totalUSDT) {
                qmr.TipManagerCommon.getInstance().createCommonTip("货币不足");
                return;
            }
            qmr.PetController.instance.getBuyFishByUSDT(cfg.id);
        };
        ShopItemRender.prototype.dataChanged = function () {
            var t = this;
            var cfg = t.data;
            if (cfg) {
                t.txt_name.text = cfg.name + "(Lv." + cfg.level + ")";
                t.txt_1.text = cfg.produce + "";
                t.txt_2.text = cfg.limitTime + "";
                t.txt_3.text = cfg.monthly + "%";
                t.txt_price_gold.text = qmr.NumberUtil.getFloat4Number2String(cfg.price) + qmr.HeroModel.KH;
                t.txt_price_USDT.text = qmr.NumberUtil.getFloat4Number2String(cfg.UBuyPrice) + qmr.HeroModel.USDT;
                var itemRes = qmr.ResPathUtilAft.getHeadUrl(cfg.id + "");
                t.img_head.source = itemRes;
            }
        };
        return ShopItemRender;
    }(eui.ItemRenderer));
    qmr.ShopItemRender = ShopItemRender;
    __reflect(ShopItemRender.prototype, "qmr.ShopItemRender");
})(qmr || (qmr = {}));
//# sourceMappingURL=ShopItemRender.js.map