var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var GoldLogItemRender = (function (_super) {
        __extends(GoldLogItemRender, _super);
        function GoldLogItemRender() {
            var _this = _super.call(this) || this;
            _this.skinName = "MoneyLogItemSkin";
            return _this;
        }
        GoldLogItemRender.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
        };
        GoldLogItemRender.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                var cfgId = qmr.Int64Util.getNumber(pro.fishConfigId);
                // let cfg:PetCfg = ConfigManager.getConf(ConfigEnum.PET, cfgId);
                t.txt_count.text = qmr.NumberUtil.getFloat4Number2String(pro.changeMoney) + qmr.HeroModel.KH;
                t.txt_name.text = qmr.TradeModule.instance.getType(pro.type);
                t.txt_time.text = qmr.TimeUtil.getDateByTimerSecond(qmr.Int64Util.getNumber(pro.logTime));
            }
        };
        return GoldLogItemRender;
    }(eui.ItemRenderer));
    qmr.GoldLogItemRender = GoldLogItemRender;
    __reflect(GoldLogItemRender.prototype, "qmr.GoldLogItemRender");
})(qmr || (qmr = {}));
//# sourceMappingURL=GoldLogItemRender.js.map