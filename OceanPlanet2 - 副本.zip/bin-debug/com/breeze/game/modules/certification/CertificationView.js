var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var CertificationView = (function (_super) {
        __extends(CertificationView, _super);
        function CertificationView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "CertificationSkin";
            _this.isNeedMask = true;
            return _this;
        }
        CertificationView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
        };
        CertificationView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
        };
        CertificationView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.addClickEvent(t.btn_Identify, t.onIdentifyClick, t);
        };
        CertificationView.prototype.updateView = function () {
            var t = this;
            var playerPro = qmr.HeroModel.instance.IdentityPro;
            var isIdentify = playerPro.state == 1; //实名验证状态0未实名，1已经实名 
            t.identifyView.visible = !isIdentify;
            t.identifyedView.visible = isIdentify;
            // t.identifyView.visible = true;
            // t.identifyedView.visible = false;
            if (isIdentify) {
                t.txt_name_show.text = qmr.NumberUtil.getPersonNameShow(playerPro.name);
                t.txt_id_show.text = qmr.NumberUtil.getIdentifyNumberShow(playerPro.idNum);
                t.txt_tel_show.text = qmr.NumberUtil.getTelNumberShow(qmr.Int64Util.getNumber(playerPro.playerId));
            }
            else {
            }
        };
        CertificationView.prototype.onIdentifyClick = function () {
            var t = this;
            var name = t.text_name.text;
            var id = t.text_id.text;
            var tel = t.text_tel.text;
            if (qmr.RegexpUtil.IsNull(name)) {
                return;
            }
            if (!qmr.RegexpUtil.isPhoneNumber(tel)) {
                qmr.TipManagerCommon.getInstance().createCommonTip("请输入正确的手机号");
                return;
            }
            if (!qmr.RegexpUtil.isIdentifyId(id)) {
                qmr.TipManagerCommon.getInstance().createCommonTip("请输入正确的身份证");
                return;
            }
            qmr.DividendController.instance.requestIdVerifCMD(tel, name, id);
        };
        CertificationView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return CertificationView;
    }(qmr.BaseModule));
    qmr.CertificationView = CertificationView;
    __reflect(CertificationView.prototype, "qmr.CertificationView");
})(qmr || (qmr = {}));
//# sourceMappingURL=CertificationView.js.map