var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HeroController = (function (_super) {
        __extends(HeroController, _super);
        function HeroController() {
            return _super.call(this) || this;
        }
        Object.defineProperty(HeroController, "instance", {
            get: function () {
                return this._instance || (this._instance = new HeroController());
            },
            enumerable: true,
            configurable: true
        });
        HeroController.prototype.initListeners = function () {
            this.addSocketListener(qmr.MessageID.S_USER_LOGIN_INIT_FINISH, this.onRecUseLoginInitFinish, this, true);
            this.addSocketListener(qmr.MessageID.S_SYN_PROPERTY, this.resSynProp, this, false);
        };
        HeroController.prototype.reqUserLoginInitFinish = function () {
            var c = new com.message.C_USER_LOGIN_INIT_FINISH();
            this.sendCmd(c, qmr.MessageID.C_USER_LOGIN_INIT_FINISH, true);
        };
        /**
         *  ---向服务器发送资源初始化完毕，可以推送其它消息了---
         */
        HeroController.prototype.reqLoadResFinishToServer = function () {
            // var c: com.message.C_SYNC_LOAD_FINISH = new com.message.C_SYNC_LOAD_FINISH();
            // this.sendCmd(c, MessageID.C_SYNC_LOAD_FINISH, true);
        };
        /**
         *  ===返回角色信息===
         */
        HeroController.prototype.onRecUseLoginInitFinish = function (s) {
            qmr.GlobalConfig.userId = qmr.Int64Util.getNumber(s.playerId);
            qmr.HeroModel.instance.playerPro = s.property;
            qmr.HeroModel.instance.IdentityPro = s.basePlayerMsg;
            qmr.HeroModel.instance.updateData(s.fishMsg);
            qmr.HeroModel.instance.teamPro = s.teamMsg;
            qmr.HeroModel.instance.pendingMoney = qmr.HeroModel.instance.getPetPendingMoney();
            qmr.HeroModel.instance.totalMoney = qmr.Int64Util.getNumber(s.property.money);
            qmr.HeroModel.instance.totalUSDT = qmr.Int64Util.getNumber(s.property.diamond);
            qmr.HeroModel.instance.totalKAD = qmr.Int64Util.getNumber(s.property.KAD);
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.MAINUI_VIEW, null, qmr.LayerConst.TOOLBAR);
            qmr.SceneManager.instance.enterHangMap(3004);
            // let isOpen = qmr.SoundManager.getInstance().isMusicSoundOpen;
            // qmr.SoundManager.getInstance().isMusicSoundOpen = false;
            // qmr.SoundManager.getInstance().isMusicSoundOpen = true;
            // qmr.SoundManager.getInstance().isMusicSoundOpen = isOpen;
            // isOpen = qmr.SoundManager.getInstance().isEffectSoundOpen;
            // qmr.SoundManager.getInstance().isEffectSoundOpen = false;
            // qmr.SoundManager.getInstance().isEffectSoundOpen = true;
            // qmr.SoundManager.getInstance().isEffectSoundOpen = isOpen;
            this.reqLoadResFinishToServer(); //通知服务器资源已加载完毕，服务端开始广播游戏协议
            //延迟小段时间进入场景，提升视觉体验
            var timer = new egret.Timer(300, 1);
            timer.addEventListener(egret.TimerEvent.TIMER, function () {
                qmr.GameLoadingView.getInstance().hideSelf();
            }, this);
            timer.start();
        };
        HeroController.prototype.resSynProp = function (s) {
            var t = this;
            s.mapMsg.forEach(function (element) {
                var value = qmr.Int64Util.getNumber(element.value);
                switch (element.key) {
                    case com.message.PropertyID.LEVEL:
                        break;
                    case com.message.PropertyID.MONEY:
                        qmr.HeroModel.instance.totalMoney = value;
                        break;
                    case com.message.PropertyID.DIAMOND:
                        qmr.HeroModel.instance.totalUSDT = value;
                        break;
                    case com.message.PropertyID.KAD:
                        qmr.HeroModel.instance.totalKAD = value;
                        break;
                }
            });
            this.dispatch(qmr.NotifyConst.S_SYN_PROPERTY);
        };
        return HeroController;
    }(qmr.BaseController));
    qmr.HeroController = HeroController;
    __reflect(HeroController.prototype, "qmr.HeroController");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroController.js.map