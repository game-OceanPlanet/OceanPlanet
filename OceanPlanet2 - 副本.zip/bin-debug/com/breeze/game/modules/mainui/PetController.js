var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PetController = (function (_super) {
        __extends(PetController, _super);
        function PetController() {
            return _super.call(this) || this;
        }
        Object.defineProperty(PetController, "instance", {
            get: function () {
                return this._instance || (this._instance = new PetController());
            },
            enumerable: true,
            configurable: true
        });
        PetController.prototype.initListeners = function () {
            this.addSocketListener(qmr.MessageID.S_GET_FISH_INFO, this.getFishInfoResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_COMBINE_FISH, this.getCombineResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_BUY_FISH, this.getBuyFishResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_MONEY_REWARD, this.getMoneyResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_MONEY_INFO, this.getMoneyInfoResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_MONEY_LOG_LIST, this.getMoneyLogResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_DIAMOND_LOG_LIST, this.getUSDTLogResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_DIAMOND_BUY_FISH, this.getBuyFishByUSDTResponse, this, false);
        };
        PetController.prototype.reqUserLoginInitFinish = function () {
            var c = new com.message.C_USER_LOGIN_INIT_FINISH();
            this.sendCmd(c, qmr.MessageID.C_USER_LOGIN_INIT_FINISH, true);
        };
        // 获取我的鱼儿
        PetController.prototype.getMyFishInfo = function () {
            var c = new com.message.C_GET_FISH_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_FISH_INFO, true);
        };
        // 获取我的鱼儿
        PetController.prototype.getFishInfoResponse = function (s) {
            qmr.HeroModel.instance.updateData(s.fishMsg);
            qmr.HeroModel.instance.pendingMoney = qmr.HeroModel.instance.getPetPendingMoney();
            this.dispatch(qmr.NotifyConst.S_GET_FINSH_INFO);
        };
        // 合并鱼儿
        PetController.prototype.getCombineFish = function (id1, id2) {
            var c = new com.message.C_COMBINE_FISH();
            c.fish1Id = id1;
            c.fish2Id = id2;
            this.sendCmd(c, qmr.MessageID.C_COMBINE_FISH, true);
        };
        // 合并鱼儿
        PetController.prototype.getCombineResponse = function (s) {
            qmr.HeroModel.instance.addPet(s.fishMsg);
            qmr.HeroModel.instance.removePet(qmr.Int64Util.getNumber(s.fish1Id));
            qmr.HeroModel.instance.removePet(qmr.Int64Util.getNumber(s.fish2Id));
            this.dispatch(qmr.NotifyConst.S_COMBINE_FINSH);
        };
        // 购买鱼儿
        PetController.prototype.getBuyFish = function (configId) {
            var c = new com.message.C_BUY_FISH();
            c.fishConfigId = configId;
            this.sendCmd(c, qmr.MessageID.C_BUY_FISH, true);
        };
        // 购买鱼儿
        PetController.prototype.getBuyFishResponse = function (s) {
            qmr.TipManagerCommon.getInstance().createCommonColorTip("购买成功");
            qmr.HeroModel.instance.addPet(s.fishMsg);
            this.dispatch(qmr.NotifyConst.S_BUY_FISH);
        };
        // U购买鱼
        PetController.prototype.getBuyFishByUSDT = function (configId) {
            var c = new com.message.C_DIAMOND_BUY_FISH();
            c.fishConfigId = configId;
            this.sendCmd(c, qmr.MessageID.C_DIAMOND_BUY_FISH, true);
        };
        // U购买鱼
        PetController.prototype.getBuyFishByUSDTResponse = function (s) {
            qmr.TipManagerCommon.getInstance().createCommonColorTip("购买成功");
            qmr.HeroModel.instance.addPet(s.fishMsg);
            this.dispatch(qmr.NotifyConst.S_DIAMOND_BUY_FISH);
        };
        // 领取金币奖励
        PetController.prototype.getMoneyCmd = function () {
            var c = new com.message.C_GET_MONEY_REWARD();
            this.sendCmd(c, qmr.MessageID.C_GET_MONEY_REWARD, true);
        };
        // 领取金币奖励
        PetController.prototype.getMoneyResponse = function (s) {
            qmr.HeroModel.instance.totalMoney = qmr.Int64Util.getNumber(s.money);
            qmr.HeroModel.instance.pendingMoney = 0;
            this.dispatch(qmr.NotifyConst.S_GET_MONEY_REWARD);
        };
        // 领取金币奖励
        PetController.prototype.getMoneyInfoCmd = function () {
            var c = new com.message.C_GET_MONEY_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_MONEY_INFO, true);
        };
        // 领取金币奖励
        PetController.prototype.getMoneyInfoResponse = function (s) {
            qmr.HeroModel.instance.totalMoney = qmr.Int64Util.getNumber(s.money);
            qmr.HeroModel.instance.totalUSDT = qmr.Int64Util.getNumber(s.money);
            this.dispatch(qmr.NotifyConst.S_GET_MONEY_INFO);
        };
        // 获取金币日志信息
        PetController.prototype.getMoneyLogCmd = function () {
            var c = new com.message.C_GET_MONEY_LOG_LIST();
            this.sendCmd(c, qmr.MessageID.C_GET_MONEY_LOG_LIST, true);
        };
        // 获取金币日志信息
        PetController.prototype.getMoneyLogResponse = function (s) {
            qmr.HeroModel.instance.moneyLogs = s.moneyLogMsg;
            this.dispatch(qmr.NotifyConst.S_GET_MONEY_LOG_LIST);
        };
        // 获取U日志信息
        PetController.prototype.getUSDTLogCmd = function () {
            var c = new com.message.C_GET_DIAMOND_LOG_LIST();
            this.sendCmd(c, qmr.MessageID.C_GET_DIAMOND_LOG_LIST, true);
        };
        // 获取U日志信息
        PetController.prototype.getUSDTLogResponse = function (s) {
            qmr.HeroModel.instance.usdtLogs = s.moneyLogMsg;
            this.dispatch(qmr.NotifyConst.S_GET_DIAMOND_LOG_LIST);
        };
        return PetController;
    }(qmr.BaseController));
    qmr.PetController = PetController;
    __reflect(PetController.prototype, "qmr.PetController");
})(qmr || (qmr = {}));
//# sourceMappingURL=PetController.js.map