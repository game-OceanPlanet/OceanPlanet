var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HeroModel = (function (_super) {
        __extends(HeroModel, _super);
        function HeroModel() {
            var _this = _super.call(this) || this;
            _this.pendingMoney = 0; //待领取的金币
            _this.totalMoney = 0; //总共持有金币的数量
            _this.totalUSDT = 0; //当前玩家USDT的数量
            _this.totalKAD = 0; //当前玩家KAD的数量
            var t = _this;
            _this.fishInfos = [];
            _this.fishIds = [];
            return _this;
        }
        Object.defineProperty(HeroModel, "instance", {
            get: function () {
                return this._instance || (this._instance = new HeroModel());
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(HeroModel.prototype, "playerId", {
            get: function () {
                if (this.playerPro) {
                    return qmr.Int64Util.getNumber(this.playerPro.playerId);
                }
                return 0;
            },
            enumerable: true,
            configurable: true
        });
        HeroModel.prototype.testMerge = function () {
            var t = this;
            var len = t.fishInfos.length;
            var p1;
            var p2;
            for (var i = 0; i < len - 1; i++) {
                p1 = t.fishInfos[i];
                for (var j = i + 1; j < len; j++) {
                    p2 = t.fishInfos[j];
                    if (p1.fishId == p2.fishId) {
                        if (p1 && p2) {
                            qmr.PetController.instance.getCombineFish(p1.id, p2.id);
                        }
                        return;
                    }
                }
            }
        };
        HeroModel.prototype.getPets = function () {
            return this.fishInfos;
        };
        HeroModel.prototype.updateData = function (pros) {
            var t = this;
            if (!pros) {
                return;
            }
            var addIds = [];
            var removeIds = [];
            var newIds = [];
            var pro;
            var len = pros.length;
            var id;
            for (var i = 0; i < len; i++) {
                pro = pros[i];
                id = qmr.Int64Util.getNumber(pro.id);
                if (t.fishIds.indexOf(id) == -1) {
                    addIds.push(id);
                }
                newIds.push(id);
            }
            len = t.fishIds.length;
            for (var j = 0; j < len; j++) {
                id = t.fishIds[j];
                if (newIds.indexOf(id) == -1) {
                    removeIds.push(id);
                }
            }
            len = pros.length;
            if (len > 0) {
                for (var i = 0; i < len; i++) {
                    pro = pros[i];
                    t.addPet(pro);
                }
            }
            len = removeIds.length;
            if (len > 0) {
                for (var i = 0; i < len; i++) {
                    t.removePet(removeIds[i]);
                }
            }
        };
        HeroModel.prototype.getPet = function (id) {
            var t = this;
            var info;
            for (var i = 0; i < t.fishInfos.length; i++) {
                if (id == t.fishInfos[i].id) {
                    info = t.fishInfos[i];
                    return info;
                }
            }
            return null;
        };
        HeroModel.prototype.addPet = function (pro) {
            var t = this;
            if (!pro) {
                return;
            }
            var isAdd = false;
            var id = qmr.Int64Util.getNumber(pro.id);
            var info;
            for (var i = 0; i < t.fishInfos.length; i++) {
                if (id == t.fishInfos[i].id) {
                    info = t.fishInfos[i];
                    break;
                }
            }
            if (!info) {
                info = new qmr.PetActorInfo();
                t.fishInfos.push(info);
                isAdd = true;
            }
            info.setData(pro);
            if (-1 == t.fishIds.indexOf(id)) {
                t.fishIds.push(id);
            }
            if (isAdd) {
                qmr.MapController.instance.addPlayer(info);
            }
        };
        HeroModel.prototype.removePet = function (id) {
            var t = this;
            var index = t.fishIds.indexOf(id);
            if (-1 != index) {
                t.fishIds.splice(index, 1);
            }
            var info;
            var removeIndex = -1;
            for (var i = 0; i < t.fishInfos.length; i++) {
                if (id == t.fishInfos[i].id) {
                    info = t.fishInfos[i];
                    removeIndex = i;
                    break;
                }
            }
            if (info) {
                qmr.MapController.instance.removePlayer(id);
                t.fishInfos.splice(removeIndex, 1);
            }
        };
        /**
         * 获取每秒产生金币的数量
         */
        HeroModel.prototype.getProduceMoneySpeed = function () {
            var t = this;
            if (!t.fishInfos || t.fishInfos.length == 0) {
                return 0;
            }
            var total = 0;
            var len = t.fishInfos.length;
            var cfg;
            var id;
            var pro;
            for (var i = 0; i < len; i++) {
                pro = t.fishInfos[i];
                id = qmr.Int64Util.getNumber(pro.fishId);
                cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, id);
                var dayNum = cfg.produce / cfg.limitTime;
                var hadProduce = Math.ceil(pro.todayCurMoney + pro.todayGotMoney); //今日总共产生的金币 = 今日已领取 + 今日当前可领取
                if (pro.state == 0 && hadProduce < dayNum) {
                    total += dayNum / 7200;
                }
            }
            return total;
        };
        /**
         * 每天总共可以产出多少金币
         */
        HeroModel.prototype.getEveryDayProduceMoney = function () {
            var t = this;
            if (!t.fishInfos || t.fishInfos.length == 0) {
                return 0;
            }
            var total = 0;
            var len = t.fishInfos.length;
            var cfg;
            var id;
            var pro;
            for (var i = 0; i < len; i++) {
                pro = t.fishInfos[i];
                id = qmr.Int64Util.getNumber(pro.fishId);
                if (pro.state == 0) {
                    cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, id);
                    var dayNum = cfg.produce / cfg.limitTime;
                    total += dayNum;
                }
            }
            return total;
        };
        /**
         * 今日产出可以领取的金币总数量
         */
        HeroModel.prototype.getPetPendingMoney = function () {
            var t = this;
            if (!t.fishInfos || t.fishInfos.length == 0) {
                return 0;
            }
            var len = t.fishInfos.length;
            var pro;
            var total = 0;
            for (var i = 0; i < len; i++) {
                pro = t.fishInfos[i];
                var pendingMoney = qmr.Int64Util.getNumber(pro.todayCurMoney); //今日产出的待领取的金币数量
                var gainedMoney = qmr.Int64Util.getNumber(pro.extMoney); //宠物总共产出的金币数量，pro.todayMoney领完之后直接加在pro.extMoney上
                total += pendingMoney;
            }
            return total;
        };
        HeroModel.KH = " KH"; //金币
        HeroModel.USDT = " USDT"; //U币，相当于RMB
        HeroModel.KAD = " KAD"; //平台币，也就是证通
        HeroModel.TIMES = 1;
        return HeroModel;
    }(qmr.BaseModel));
    qmr.HeroModel = HeroModel;
    __reflect(HeroModel.prototype, "qmr.HeroModel");
})(qmr || (qmr = {}));
//# sourceMappingURL=HeroModel.js.map