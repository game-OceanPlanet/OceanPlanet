var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var MainView = (function (_super) {
        __extends(MainView, _super);
        function MainView() {
            var _this = _super.call(this) || this;
            _this.__lastGetMoneyTime = 0; //上次零钱的时间点
            _this.qmrSkinName = "Mainui";
            return _this;
        }
        /**
         * @description 初始化事件
         */
        MainView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btn_get_group, t.onGetClick, t);
            t.addClickEvent(t.btn_price_group, t.onPriceClick, t);
            t.addClickEvent(t.btn_exchange, t.onExchangeClick, t);
            t.addClickEvent(t.btn_injection, t.onInjectClick, t);
            t.addClickEvent(t.btn_shop, t.onShopClick, t);
            t.addClickEvent(t.btn_dividend, t.onDividendClick, t);
            t.addClickEvent(t.btn_promote, t.onPromoteClick, t);
            t.addClickEvent(t.btn_bottom_pet, t.onPetViewClick, t);
            t.addClickEvent(t.btn_bottom_property, t.onPropertyViewClick, t);
            t.addClickEvent(t.btn_bottom_gold, t.onGoldViewClick, t);
            t.addClickEvent(t.btn_realname, t.onRealNameClick, t);
            t.addClickEvent(t.btn_person, t.onPersonClick, t);
            t.addClickEvent(t.btn_permit, t.onPermitClick, t);
            t.addClickEvent(t.btn_download, t.onDowonClick, t);
            t.addClickEvent(t.btn_help, t.onHelpClick, t);
            t.registerNotify(qmr.NotifyConst.S_GET_FINSH_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_COMBINE_FINSH, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_BUY_FISH, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
        };
        MainView.prototype.addedToStage = function (evt) {
            _super.prototype.addedToStage.call(this, evt);
        };
        //资产面板
        MainView.prototype.onPropertyViewClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.USDT_LOG_VIEW);
            qmr.PetController.instance.getUSDTLogCmd();
        };
        //金币面板
        MainView.prototype.onGoldViewClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.GOLD_LOG_VIEW);
            qmr.PetController.instance.getMoneyLogCmd();
        };
        //实名认证
        MainView.prototype.onRealNameClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.CERTIFICATION_VIEW);
        };
        //通行证
        MainView.prototype.onPermitClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.MINE_PASSIED_VIEW);
        };
        //个人中心
        MainView.prototype.onPersonClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.MINEID_VIEW);
        };
        //下载
        MainView.prototype.onDowonClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.APP_DOWN_VIEW);
        };
        //领钱
        MainView.prototype.onGetClick = function () {
            var t = this;
            if (t.__lastGetMoneyTime - egret.getTimer() > 0) {
                var pendingMoney = t.__currMoney;
                qmr.HeroModel.instance.pendingMoney = 0;
                qmr.HeroModel.instance.totalMoney += pendingMoney;
                t.updateView();
                return;
            }
            t.__lastGetMoneyTime = egret.getTimer() + 10000;
            qmr.PetController.instance.getMoneyCmd();
        };
        //查看价钱
        MainView.prototype.onPriceClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.TRADE_VIEW);
            qmr.TradeController.instance.requestOTCInfo();
        };
        //查看宠物面板
        MainView.prototype.onPetViewClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.PET_VIEW);
            qmr.PetController.instance.getMyFishInfo();
        };
        //查看帮助
        MainView.prototype.onHelpClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.HELP_MAIN_VIEW);
        };
        //兑换
        MainView.prototype.onExchangeClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.EXCHANGE_VIEW);
        };
        //注入
        MainView.prototype.onInjectClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.INJECT_VIEW);
        };
        //商城
        MainView.prototype.onShopClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.SHOP_VIEW);
        };
        //分红
        MainView.prototype.onDividendClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.DIVIDEND_VIEW);
        };
        //推广
        MainView.prototype.onPromoteClick = function () {
            qmr.ModuleManager.showModule(qmr.ModuleNameConst.INVITE_CODE_VIEW);
        };
        /**
        * @description 初始化数据,需被子类继承
        */
        MainView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
            if (!t.baseEffect) {
                t.baseEffect = new qmr.BaseEffect();
                t.baseEffect.scaleX = t.baseEffect.scaleY = 1.5;
                t.effect_group_1.addChild(t.baseEffect);
                t.baseEffect.playUIEffect("uieffect_act", -1, -1, 1);
            }
            if (!t.baseEffect2) {
                t.baseEffect2 = new qmr.BaseEffect();
                t.baseEffect2.scaleX = t.baseEffect2.scaleY = 1.5;
                t.effect_group_2.addChild(t.baseEffect2);
                t.baseEffect2.playUIEffect("uieffect_act", -1, -1, 1);
            }
            if (!t.baseEffect3) {
                t.baseEffect3 = new qmr.BaseEffect();
                t.baseEffect3.scaleX = t.baseEffect3.scaleY = 1.5;
                t.effect_group_3.addChild(t.baseEffect3);
                t.baseEffect3.playUIEffect("uieffect_act", -1, -1, 1);
            }
            if (!t.baseEffect4) {
                t.baseEffect4 = new qmr.BaseEffect();
                t.baseEffect4.scaleX = t.baseEffect4.scaleY = 1.5;
                t.effect_group_4.addChild(t.baseEffect4);
                t.baseEffect4.playUIEffect("uieffect_act", -1, -1, 1);
            }
            if (!t.baseEffect5) {
                t.baseEffect5 = new qmr.BaseEffect();
                t.baseEffect5.scaleX = t.baseEffect5.scaleY = 1.5;
                t.effect_group_5.addChild(t.baseEffect5);
                t.baseEffect5.playUIEffect("uieffect_act", -1, -1, 1);
            }
            if (!t.baseEffectPet) {
                t.baseEffectPet = new qmr.BaseEffect();
                t.baseEffectPet.scaleX = t.baseEffectPet.scaleY = 1.5;
                t.effect_group_pet.addChild(t.baseEffectPet);
                t.baseEffectPet.playUIEffect("ui_jinjie_zhe", -1, -1, 1);
            }
            t.baseEffectPet.touchChildren = t.baseEffectPet.touchEnabled = false;
            t.effect_group_pet.touchEnabled = false;
        };
        MainView.prototype.updateView = function () {
            var t = this;
            var md = qmr.HeroModel.instance;
            t.__currMoney = md.pendingMoney;
            t.__totalMoney = md.totalMoney;
            t.__secondSpeed = md.getProduceMoneySpeed();
            t.__dayTotal = md.getEveryDayProduceMoney();
            t.txt_curr.text = qmr.NumberUtil.getFloat4Number2String(t.__currMoney) + qmr.HeroModel.KH;
            t.txt_totalGold.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalMoney) + qmr.HeroModel.KH;
            t.txt_totalUsdt.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalUSDT) + qmr.HeroModel.USDT;
            if (t.__timekey != -1) {
                egret.clearInterval(t.__timekey);
            }
            if (t.__secondSpeed > 0) {
                t.__timekey = egret.setInterval(t.onTimeRun, t, 1000);
            }
            else {
                t.stopTime();
            }
        };
        MainView.prototype.onTimeRun = function () {
            var t = this;
            if (t.__currMoney >= t.__dayTotal) {
                t.txt_curr.text = qmr.NumberUtil.getFloat4Number2String(t.__dayTotal) + qmr.HeroModel.KH;
                t.stopTime();
                return;
            }
            t.__currMoney += t.__secondSpeed;
            qmr.HeroModel.instance.pendingMoney = t.__currMoney;
            t.txt_curr.text = qmr.NumberUtil.getFloat4Number2String(t.__currMoney) + qmr.HeroModel.KH;
        };
        MainView.prototype.stopTime = function () {
            var t = this;
            if (t.__timekey != -1) {
                egret.clearInterval(t.__timekey);
            }
            t.__timekey = -1;
            t.txt_curr.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.getPetPendingMoney()) + qmr.HeroModel.KH;
        };
        return MainView;
    }(qmr.BaseModule));
    qmr.MainView = MainView;
    __reflect(MainView.prototype, "qmr.MainView");
})(qmr || (qmr = {}));
//# sourceMappingURL=MainView.js.map