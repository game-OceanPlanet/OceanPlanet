var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var TradeTypeEnum = (function () {
        function TradeTypeEnum() {
        }
        /** 领取鱼日产金币*/
        TradeTypeEnum.MONEY_REWARD = 1;
        /** 金币买鱼*/
        TradeTypeEnum.MONEY_BUY_FISH = 2;
        /** OTC-卖给Ta，消耗金币*/
        TradeTypeEnum.OCT_SELL_MONEY = 3;
        /** OTC-有玩家卖金币给我了，得金币*/
        TradeTypeEnum.OCT_SOMEONE_SELL_ME = 4;
        /** KAD-用金币兑换KAD，消耗金币*/
        TradeTypeEnum.MONEY_EXCHANGE_KAD = 5;
        /** U买鱼*/
        TradeTypeEnum.DIAMOND_BUY_FISH = 101;
        /** OTC-买入金币（挂单），消耗u*/
        TradeTypeEnum.OCT_BUY_MONEY_COST_U = 102;
        /** OTC-卖给Ta，获得U*/
        TradeTypeEnum.OCT_SELL_MONEY_GOT_U = 103;
        /** OTC-撤单，获得U*/
        TradeTypeEnum.OCT_CANCEL_GOT_U = 104;
        /** KAD-注入每日分红，获得U*/
        TradeTypeEnum.KAD_BONUS_GOT_U = 105;
        /** KAD-用金币兑换KAD，得到KAD*/
        TradeTypeEnum.EXCHANGE_GOT_KAD = 201;
        /** KAD-注入，消耗KAD*/
        TradeTypeEnum.INJECT_COST_KAD = 202;
        /** KAD-注入到期，返还KAD*/
        TradeTypeEnum.INJECT_EXPIRE_GOT_KAD = 203;
        return TradeTypeEnum;
    }());
    qmr.TradeTypeEnum = TradeTypeEnum;
    __reflect(TradeTypeEnum.prototype, "qmr.TradeTypeEnum");
})(qmr || (qmr = {}));
//# sourceMappingURL=TradeTypeEnum.js.map