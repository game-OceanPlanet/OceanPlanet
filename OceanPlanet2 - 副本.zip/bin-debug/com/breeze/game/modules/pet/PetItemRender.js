var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PetItemRender = (function (_super) {
        __extends(PetItemRender, _super);
        function PetItemRender() {
            var _this = _super.call(this) || this;
            _this._endTime = 0;
            _this._timekey = -1;
            _this.skinName = "PetItemSkin";
            return _this;
        }
        PetItemRender.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
            t.checkbox.addEventListener(eui.UIEvent.CHANGE, t.onCheckBoxChange, t);
        };
        PetItemRender.prototype.onCheckBoxChange = function (e) {
            var t = this;
            var info = t.data;
            if (info) {
                qmr.NotifyManager.sendNotification(qmr.NotifyConst.ON_PET_SELECTED, { id: info.id, selected: t.checkbox.selected });
            }
        };
        PetItemRender.prototype.getSelectedState = function () {
            return this.checkbox.selected;
        };
        PetItemRender.prototype.setSelectedState = function (isSelected) {
            this.checkbox.selected = isSelected;
        };
        PetItemRender.prototype.dataChanged = function () {
            var t = this;
            var info = t.data;
            if (info) {
                t.checkbox.selected = info.id == qmr.HeroModel.instance.selectedMergePetId1 || info.id == qmr.HeroModel.instance.selectedMergePetId2;
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, info.fishId);
                t.txt_name.text = cfg.name + "(Lv." + cfg.level + ")";
                t.txt_gain.text = qmr.NumberUtil.getFloat4Number2String(info.extMoney) + qmr.HeroModel.KH; //鱼生累计已经产出金币,包括遗漏的
                var left = cfg.produce - info.extMoney;
                t.txt_left.text = qmr.NumberUtil.getFloat4Number2String(left) + qmr.HeroModel.KH;
                t.txt_total.text = qmr.NumberUtil.getFloat4Number2String(cfg.produce) + qmr.HeroModel.KH;
                // t.txt_totalLeft.text =NumberUtil.getFloat4Number2String(info.leftMoney)+ HeroModel.KH;//鱼生累计遗漏未领取金币
                t.txt_todayGained.text = qmr.NumberUtil.getFloat4Number2String(info.todayGotMoney) + qmr.HeroModel.KH; //今日已经领取金币
                t.txt_todayCanGain.text = qmr.NumberUtil.getFloat4Number2String(info.todayCurMoney) + qmr.HeroModel.KH; //今日当前可领取金币
                var itemRes = qmr.ResPathUtilAft.getHeadUrl(cfg.id + "");
                t.img_head.source = itemRes;
                t.txt_state.text = t.getState(info.state);
                var totalSeconds = cfg.limitTime * 3600 * 2; //一条鱼总共生产的周期
                var dayProduce = cfg.produce / cfg.limitTime; //每天的产量
                var secondProduce = dayProduce / 2 / 3600; //每秒的产量
                var produceedSeconds = info.extMoney / secondProduce; //这条鱼已经生产了多少秒
                var leftSeconds = totalSeconds - produceedSeconds; //这条鱼还剩余的生产时间 秒
                var produceedHours = Math.floor(leftSeconds / 3600); //已经还剩余多少小时
                var dayCount = Math.ceil(produceedHours / 2); //两个小时为一天，这条鱼还剩下多少天,向上取整，比如剩余3.5天取4天
                var totalLeftSeconds = dayCount * 24 * 3600 - produceedSeconds % 7200;
                if (totalLeftSeconds > 0) {
                    t._endTime = qmr.ServerTime.serverTime + totalLeftSeconds * 1000;
                }
            }
            if (t._timekey != -1) {
                egret.clearInterval(t._timekey);
            }
            if (t._endTime < qmr.ServerTime.serverTime) {
                t._endTime = 0;
            }
            if (t._endTime > qmr.ServerTime.serverTime) {
                t.txt_leftTime.text = qmr.TimeUtil.formatRemain4((t._endTime - qmr.ServerTime.serverTime) / 1000);
                t._timekey = egret.setInterval(t.updateTime, t, 1000);
            }
            else {
                t.stopTime();
            }
        };
        PetItemRender.prototype.updateTime = function () {
            var t = this;
            if (this._endTime < qmr.ServerTime.serverTime) {
                t.txt_leftTime.text = "00：00";
                return;
            }
            t.txt_leftTime.text = qmr.TimeUtil.formatRemain4((t._endTime - qmr.ServerTime.serverTime) / 1000);
        };
        PetItemRender.prototype.stopTime = function () {
            var t = this;
            if (t._timekey != -1) {
                egret.clearInterval(t._timekey);
            }
            t._timekey = -1;
            t.txt_leftTime.text = "00：00";
        };
        PetItemRender.prototype.getState = function (s) {
            //状态，0生产中，1停产中,2已过期
            var msg;
            switch (s) {
                case 0:
                    msg = "生产中";
                    break;
                case 1:
                    msg = "停产中";
                    break;
                case 2:
                    msg = "已过期";
                    break;
            }
            return msg;
        };
        return PetItemRender;
    }(eui.ItemRenderer));
    qmr.PetItemRender = PetItemRender;
    __reflect(PetItemRender.prototype, "qmr.PetItemRender");
})(qmr || (qmr = {}));
//# sourceMappingURL=PetItemRender.js.map