var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PetView = (function (_super) {
        __extends(PetView, _super);
        function PetView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "PetViewSkin";
            _this.isNeedMask = true;
            return _this;
        }
        PetView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.PetItemRender;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
        };
        PetView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
            t.clearMerge();
            // if(!t.baseEffect2){
            //     t.baseEffect2 = new BaseEffect();
            //     t.baseEffect2.scaleX = t.baseEffect2.scaleY = 1.5;
            // }
            // t.effect_group_merge.addChild(t.baseEffect2);
            // t.baseEffect2.touchChildren = t.baseEffect2.touchEnabled = false;
            // t.baseEffect2.playUIEffect("uieffect_hang_yuanbao3", -1, -1, 1);
        };
        PetView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnClose, t.closeView, t);
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.addClickEvent(t.btn_merge, t.onMergeClick, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_FINSH_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_COMBINE_FINSH, t.onMerger, t);
            t.registerNotify(qmr.NotifyConst.ON_PET_SELECTED, t.onPetSelected, t);
        };
        PetView.prototype.onMerger = function () {
            var t = this;
            t.clearMerge();
            t.updateMergeView();
            t.updateView();
            if (!t.baseEffect) {
                t.baseEffect = new qmr.BaseEffect();
                t.baseEffect.scaleX = t.baseEffect.scaleY = 1.5;
            }
            t.effect_group_pet.addChild(t.baseEffect);
            t.baseEffect.touchChildren = t.baseEffect.touchEnabled = false;
            t.baseEffect.playUIEffect("uieffect_enter_zr", -1, 1, 1);
        };
        PetView.prototype.clearMerge = function () {
            var t = this;
            qmr.HeroModel.instance.selectedMergePetId1 = 0;
            qmr.HeroModel.instance.selectedMergePetId2 = 0;
        };
        PetView.prototype.onMergeClick = function () {
            var t = this;
            var id1 = qmr.HeroModel.instance.selectedMergePetId1;
            var id2 = qmr.HeroModel.instance.selectedMergePetId2;
            var pro1 = qmr.HeroModel.instance.getPet(id1);
            var pro2 = qmr.HeroModel.instance.getPet(id2);
            if (!pro1 || !pro2) {
                qmr.TipManagerCommon.getInstance().createCommonTip("请选择需要合成的宠物");
                return;
            }
            if (pro1.fishId != pro2.fishId) {
                qmr.TipManagerCommon.getInstance().createCommonTip("请选择两条相同的宠物进行合成");
                return;
            }
            if (pro1.fishId == 15) {
                qmr.TipManagerCommon.getInstance().createCommonTip("当前宠物已经是最高等级");
                return;
            }
            qmr.PetController.instance.getCombineFish(id1, id2);
        };
        PetView.prototype.onPetSelected = function (params) {
            var t = this;
            if (!params) {
                return;
            }
            var id = params.id;
            var selected = params.selected;
            var currItem;
            var selectedItem1;
            var selectedItem2;
            var md = qmr.HeroModel.instance;
            var id1 = md.selectedMergePetId1;
            var id2 = md.selectedMergePetId2;
            var len = t.item_list.numElements;
            for (var i = 0; i < len; i++) {
                var item = t.item_list.getVirtualElementAt(i);
                if (item && item.data && item.data.id == id) {
                    currItem = item;
                }
                if (item && item.data && item.data.id == id1) {
                    selectedItem1 = item;
                }
                if (item && item.data && item.data.id == id2) {
                    selectedItem2 = item;
                }
            }
            if (id && selected) {
                if (id1 && id2) {
                    if (selectedItem1) {
                        selectedItem1.setSelectedState(false);
                    }
                    md.selectedMergePetId1 = md.selectedMergePetId2;
                    md.selectedMergePetId2 = id;
                }
                else if (id1 && !id2) {
                    md.selectedMergePetId2 = id;
                }
                else {
                    md.selectedMergePetId1 = id;
                }
            }
            if (id && !selected) {
                if (id == md.selectedMergePetId1) {
                    md.selectedMergePetId1 = 0;
                }
                else if (id == md.selectedMergePetId2) {
                    md.selectedMergePetId2 = 0;
                }
            }
            t.updateMergeView();
        };
        PetView.prototype.updateMergeView = function () {
            var t = this;
            var info1;
            var info2;
            var itemRes;
            var cfg1;
            var cfg2;
            var md = qmr.HeroModel.instance;
            var id1 = md.selectedMergePetId1;
            var id2 = md.selectedMergePetId2;
            if (id1) {
                info1 = md.getPet(id1);
                cfg1 = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, info1.fishId);
            }
            if (id2) {
                info2 = md.getPet(id2);
                cfg2 = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, info2.fishId);
            }
            if (info1) {
                itemRes = qmr.ResPathUtilAft.getHeadUrl(cfg1.id + "");
                t.img_head.source = itemRes;
            }
            else {
                t.img_head.source = null;
            }
            if (info2) {
                itemRes = qmr.ResPathUtilAft.getHeadUrl(cfg2.id + "");
                t.img_head2.source = itemRes;
            }
            else {
                t.img_head2.source = null;
            }
            if (cfg1 && cfg2 && cfg1.id == cfg2.id && cfg1.id != 15) {
                var nextId = cfg1.id + 1;
                var nextCfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, nextId);
                if (nextCfg) {
                    itemRes = qmr.ResPathUtilAft.getHeadUrl(nextCfg.id + "");
                    t.img_head3.source = itemRes;
                }
            }
            else {
                t.img_head3.source = null;
            }
        };
        PetView.prototype.updateView = function () {
            var t = this;
            var pets = qmr.HeroModel.instance.getPets();
            pets.sort(function (a, b) {
                return b.level - a.level;
            });
            t._arrCollection.replaceAll(pets);
        };
        PetView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return PetView;
    }(qmr.BaseModule));
    qmr.PetView = PetView;
    __reflect(PetView.prototype, "qmr.PetView");
})(qmr || (qmr = {}));
//# sourceMappingURL=PetView.js.map