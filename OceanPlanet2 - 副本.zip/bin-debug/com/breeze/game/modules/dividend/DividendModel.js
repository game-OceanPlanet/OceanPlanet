var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var DividendModel = (function (_super) {
        __extends(DividendModel, _super);
        function DividendModel() {
            var _this = _super.call(this) || this;
            _this.sysAllKAD = 0; //平台KAD通证总量
            _this.exAllKAD = 0; //已经兑换总量
            _this.exRatio = 0; //当前兑换比例
            _this.sysAllBonus = 0; //分红池总量
            _this.todayAllBonus = 0; //今日分红池总量
            _this.bonusRatio = 0; //今日分红比例，默认10%
            _this.allInject = 0; //全体加权注入总量
            var t = _this;
            return _this;
        }
        Object.defineProperty(DividendModel, "instance", {
            get: function () {
                return this._instance || (this._instance = new DividendModel());
            },
            enumerable: true,
            configurable: true
        });
        DividendModel.prototype.addInjectLog = function (pro) {
            var t = this;
            if (!t.injectLogs) {
                t.injectLogs = [];
            }
            t.injectLogs.push(pro);
        };
        DividendModel.prototype.addExchangeLog = function (pro) {
            var t = this;
            if (!t.exchangeLogs) {
                t.exchangeLogs = [];
            }
            t.exchangeLogs.push(pro);
        };
        return DividendModel;
    }(qmr.BaseModel));
    qmr.DividendModel = DividendModel;
    __reflect(DividendModel.prototype, "qmr.DividendModel");
})(qmr || (qmr = {}));
//# sourceMappingURL=DividendModel.js.map