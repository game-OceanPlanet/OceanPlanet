var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var DividendView = (function (_super) {
        __extends(DividendView, _super);
        function DividendView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "DividendSkin";
            _this.isNeedMask = true;
            _this.helpId = qmr.HelpId.ID_4;
            return _this;
        }
        DividendView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.DividendLogItem;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
        };
        DividendView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
            qmr.DividendController.instance.requestDividendCMD();
        };
        DividendView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.registerNotify(qmr.NotifyConst.S_BUY_FISH, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_BONUS_INFO, t.updateView, t);
        };
        DividendView.prototype.updateView = function () {
            var t = this;
            var md = qmr.DividendModel.instance;
            t.txt_total.text = qmr.NumberUtil.getFloat4Number2String(md.sysAllBonus);
            t.txt_dividend_total.text = qmr.NumberUtil.getFloat4Number2String(md.todayAllBonus);
            var myTotal = 0;
            var logs = md.dividenLogs;
            if (logs && logs.length > 0) {
                var len = logs.length;
                for (var i = 0; i < len; i++) {
                    myTotal += logs[i].diamondCount;
                }
            }
            var total = md.sysAllBonus;
            if (total > 0 && myTotal > 0) {
                t.txt_self_pre.text = qmr.NumberUtil.getFloat6Number2String(myTotal / total) + "%";
                t.txt_self_get.text = qmr.NumberUtil.getFloat6Number2String(myTotal) + qmr.HeroModel.USDT;
            }
            else {
                t.txt_self_pre.text = "0%";
                t.txt_self_get.text = "0" + qmr.HeroModel.USDT;
            }
            t._arrCollection.replaceAll(logs);
        };
        DividendView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return DividendView;
    }(qmr.BaseModule));
    qmr.DividendView = DividendView;
    __reflect(DividendView.prototype, "qmr.DividendView");
})(qmr || (qmr = {}));
//# sourceMappingURL=DividendView.js.map