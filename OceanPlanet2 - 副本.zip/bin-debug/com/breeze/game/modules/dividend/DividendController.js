var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var DividendController = (function (_super) {
        __extends(DividendController, _super);
        function DividendController() {
            return _super.call(this) || this;
        }
        Object.defineProperty(DividendController, "instance", {
            get: function () {
                return this._instance || (this._instance = new DividendController());
            },
            enumerable: true,
            configurable: true
        });
        DividendController.prototype.initListeners = function () {
            this.addSocketListener(qmr.MessageID.S_GET_MONEY_EXCHANGE_INFO, this.getExchangeResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_MONEY_EXCHANGE_KAD, this.getExchangeKADResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_BONUS_INFO, this.getDividendResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_INJECT_KAD, this.getInjectResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_GET_INJECT_INFO, this.getInjectInfoResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_REAL_NAME_VERIFICATION, this.getIdentifyVerificationResponse, this, false);
        };
        //获取兑换信息
        DividendController.prototype.requestExchangeCMD = function () {
            var c = new com.message.C_GET_MONEY_EXCHANGE_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_MONEY_EXCHANGE_INFO, true);
        };
        // 获取兑换信息
        DividendController.prototype.getExchangeResponse = function (s) {
            qmr.DividendModel.instance.sysAllKAD = qmr.Int64Util.getNumber(s.moneyExchangeMsg.sysAllKAD);
            qmr.DividendModel.instance.exAllKAD = qmr.Int64Util.getNumber(s.moneyExchangeMsg.exAllKAD);
            qmr.DividendModel.instance.exRatio = qmr.Int64Util.getNumber(s.moneyExchangeMsg.exRatio);
            qmr.DividendModel.instance.exchangeLogs = s.playerExcInfoMsg;
            this.dispatch(qmr.NotifyConst.S_GET_MONEY_EXCHANGE_INFO);
        };
        //金币兑换平台币KAD
        DividendController.prototype.requestExchangeKADCMD = function (count) {
            var c = new com.message.C_MONEY_EXCHANGE_KAD();
            c.moneyCount = count;
            this.sendCmd(c, qmr.MessageID.C_MONEY_EXCHANGE_KAD, true);
        };
        // 金币兑换平台币KAD
        DividendController.prototype.getExchangeKADResponse = function (s) {
            qmr.DividendModel.instance.addExchangeLog(s.playerExcInfoMsg);
            this.dispatch(qmr.NotifyConst.S_MONEY_EXCHANGE_KAD);
        };
        //获取分红信息
        DividendController.prototype.requestDividendCMD = function () {
            var c = new com.message.C_GET_BONUS_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_BONUS_INFO, true);
        };
        // 获取分红信息
        DividendController.prototype.getDividendResponse = function (s) {
            qmr.DividendModel.instance.sysAllBonus = s.sysBonusMsg.sysAllBonus;
            qmr.DividendModel.instance.todayAllBonus = s.sysBonusMsg.todayAllBonus;
            qmr.DividendModel.instance.bonusRatio = s.sysBonusMsg.bonusRatio;
            qmr.DividendModel.instance.dividenLogs = s.personBonusMsg;
            this.dispatch(qmr.NotifyConst.S_GET_BONUS_INFO);
        };
        //获取注入信息
        DividendController.prototype.requestInjectInfoCMD = function () {
            var c = new com.message.C_GET_INJECT_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_INJECT_INFO, true);
        };
        // 获取注入信息
        DividendController.prototype.getInjectInfoResponse = function (s) {
            qmr.DividendModel.instance.allInject = s.allInject;
            qmr.DividendModel.instance.injectLogs = s.personInjectMsg;
            this.dispatch(qmr.NotifyConst.S_GET_INJECT_INFO);
        };
        //注入
        DividendController.prototype.requestInjectCMD = function (count, step) {
            var c = new com.message.C_INJECT_KAD();
            c.KADCount = count;
            c.cycleId = step;
            this.sendCmd(c, qmr.MessageID.C_INJECT_KAD, true);
        };
        // 注入
        DividendController.prototype.getInjectResponse = function (s) {
            qmr.DividendModel.instance.allInject = s.allInject;
            qmr.DividendModel.instance.addInjectLog(s.personInjectMsg);
            this.dispatch(qmr.NotifyConst.S_INJECT_KAD);
        };
        //实名验证
        DividendController.prototype.requestIdVerifCMD = function (tel, name, id) {
            var c = new com.message.C_REAL_NAME_VERIFICATION();
            c.mobile = tel;
            c.name = name;
            c.idNum = id;
            this.sendCmd(c, qmr.MessageID.C_REAL_NAME_VERIFICATION, true);
        };
        //实名验证
        DividendController.prototype.getIdentifyVerificationResponse = function (s) {
            var res = s.result;
            var des = s.remark;
        };
        return DividendController;
    }(qmr.BaseController));
    qmr.DividendController = DividendController;
    __reflect(DividendController.prototype, "qmr.DividendController");
})(qmr || (qmr = {}));
//# sourceMappingURL=DividendController.js.map