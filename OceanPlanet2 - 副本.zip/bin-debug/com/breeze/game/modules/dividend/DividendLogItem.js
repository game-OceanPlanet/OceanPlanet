var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var DividendLogItem = (function (_super) {
        __extends(DividendLogItem, _super);
        function DividendLogItem() {
            var _this = _super.call(this) || this;
            _this.skinName = "DividendItemSkin";
            return _this;
        }
        DividendLogItem.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
        };
        DividendLogItem.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                if (pro.info) {
                    var id = Number(pro.info);
                    var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.INJECTCYCLE, id);
                    t.txt_des.text = cfg.des;
                }
                t.txt_count.text = qmr.NumberUtil.getFloat6Number2String(pro.diamondCount) + qmr.HeroModel.USDT;
                var dt = new Date();
                dt.setTime(qmr.Int64Util.getNumber(pro.logTime));
                t.txt_time.text = qmr.TimeUtil.formatColumnDate(dt);
            }
        };
        return DividendLogItem;
    }(eui.ItemRenderer));
    qmr.DividendLogItem = DividendLogItem;
    __reflect(DividendLogItem.prototype, "qmr.DividendLogItem");
})(qmr || (qmr = {}));
//# sourceMappingURL=DividendLogItem.js.map