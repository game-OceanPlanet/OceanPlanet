var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var MinePassIdView = (function (_super) {
        __extends(MinePassIdView, _super);
        function MinePassIdView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "MinePassSkin";
            _this.isNeedMask = true;
            return _this;
        }
        MinePassIdView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.MineKADLogItem;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
        };
        MinePassIdView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
        };
        MinePassIdView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_DIAMOND_LOG_LIST, t.updateView, t);
        };
        MinePassIdView.prototype.updateView = function () {
            var t = this;
            t.txt_kda_total.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalKAD) + qmr.HeroModel.KAD;
        };
        MinePassIdView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return MinePassIdView;
    }(qmr.BaseModule));
    qmr.MinePassIdView = MinePassIdView;
    __reflect(MinePassIdView.prototype, "qmr.MinePassIdView");
})(qmr || (qmr = {}));
//# sourceMappingURL=MinePassIdView.js.map