var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var ExchangeView = (function (_super) {
        __extends(ExchangeView, _super);
        function ExchangeView() {
            var _this = _super.call(this) || this;
            _this._KHNum = 0;
            _this.qmrSkinName = "ExchangeSkin";
            _this.isNeedMask = true;
            _this.helpId = qmr.HelpId.ID_3;
            return _this;
        }
        ExchangeView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.ExchangeLogtem;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
            t.text_input_price.restrict = "0-9";
        };
        ExchangeView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
            qmr.DividendController.instance.requestExchangeCMD();
        };
        ExchangeView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.addClickEvent(t.btn_exchange_group, t.onExchangeClick, t);
            t.addEvent(t.text_input_price, egret.Event.FOCUS_OUT, t.onFocusOut, t);
            t.addEvent(t.text_input_price, egret.Event.CHANGE, t.onTextInputChange, t);
            t.registerNotify(qmr.NotifyConst.S_BUY_FISH, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_EXCHANGE_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_MONEY_EXCHANGE_KAD, t.updateView, t);
        };
        ExchangeView.prototype.onTextInputChange = function (evt) {
            var str = evt.target.text;
            if (qmr.RegexpUtil.IsNull(str)) {
                return;
            }
            if (!qmr.RegexpUtil.IsInteger(str)) {
                return;
            }
            this._KHNum = parseInt(str.trim());
            this.updateKADNum();
        };
        ExchangeView.prototype.onExchangeClick = function () {
            if (this._KHNum <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonTip("输入金币数量有误");
                return;
            }
            if (this._KHNum > qmr.HeroModel.instance.totalMoney) {
                qmr.TipManagerCommon.getInstance().createCommonTip("对不起您的金币不足");
                return;
            }
            qmr.DividendController.instance.requestExchangeKADCMD(this._KHNum);
        };
        ExchangeView.prototype.onFocusOut = function () {
            this._KHNum = parseInt(this.text_input_price.text.trim());
            this.updateKADNum();
        };
        ExchangeView.prototype.updateKADNum = function () {
            var rate = qmr.DividendModel.instance.exRatio;
            if (!this._KHNum && rate > 0) {
                this.txt_exchangeDes.text = "可兑换" + qmr.NumberUtil.getFloat4Number2String(this._KHNum / rate) + qmr.HeroModel.KAD;
            }
        };
        ExchangeView.prototype.updateView = function () {
            var t = this;
            var md = qmr.DividendModel.instance;
            t.txt_kda_total.text = qmr.NumberUtil.getFloat4Number2String(md.sysAllKAD) + qmr.HeroModel.KAD;
            t.txt_exchanged_total.text = qmr.NumberUtil.getFloat4Number2String(md.exAllKAD) + qmr.HeroModel.KAD;
            t.txt_rate.text = md.exRatio + qmr.HeroModel.KH + "：1" + qmr.HeroModel.KAD;
            t.txt_kh_totalSelf.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalMoney) + qmr.HeroModel.KH;
            t.txt_kadTotalSelf.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalKAD) + qmr.HeroModel.KAD;
            var logs = md.exchangeLogs;
            if (logs) {
                logs.sort(function (a, b) {
                    return qmr.Int64Util.getNumber(b.logTime) - qmr.Int64Util.getNumber(a.logTime);
                });
            }
            t._arrCollection.replaceAll(logs);
        };
        ExchangeView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return ExchangeView;
    }(qmr.BaseModule));
    qmr.ExchangeView = ExchangeView;
    __reflect(ExchangeView.prototype, "qmr.ExchangeView");
})(qmr || (qmr = {}));
//# sourceMappingURL=ExchangeView.js.map