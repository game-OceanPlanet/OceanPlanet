var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var ExchangeLogtem = (function (_super) {
        __extends(ExchangeLogtem, _super);
        function ExchangeLogtem() {
            var _this = _super.call(this) || this;
            _this.skinName = "ExchangeItemSkin";
            return _this;
        }
        ExchangeLogtem.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
        };
        ExchangeLogtem.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                var dt = new Date();
                t.txt_countKAD.text = qmr.NumberUtil.getFloat6Number2String(pro.KADCount) + qmr.HeroModel.KAD;
                t.txt_KH.text = qmr.NumberUtil.getFloat6Number2String(pro.moneyCount) + qmr.HeroModel.KH;
                dt.setTime(qmr.Int64Util.getNumber(pro.logTime) * 1000);
                t.txt_time.text = qmr.TimeUtil.formatColumnDate(dt);
            }
        };
        return ExchangeLogtem;
    }(eui.ItemRenderer));
    qmr.ExchangeLogtem = ExchangeLogtem;
    __reflect(ExchangeLogtem.prototype, "qmr.ExchangeLogtem");
})(qmr || (qmr = {}));
//# sourceMappingURL=ExchangeLogtem.js.map