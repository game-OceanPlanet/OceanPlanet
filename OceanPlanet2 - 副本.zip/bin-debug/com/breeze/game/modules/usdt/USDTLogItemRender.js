var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var USDTLogItemRender = (function (_super) {
        __extends(USDTLogItemRender, _super);
        function USDTLogItemRender() {
            var _this = _super.call(this) || this;
            _this.skinName = "USDTLogItemSkin";
            return _this;
        }
        USDTLogItemRender.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
        };
        USDTLogItemRender.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                var cfgId = qmr.Int64Util.getNumber(pro.fishConfigId);
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.PET, cfgId);
                t.txt_count.text = qmr.NumberUtil.getFloat6Number2String(pro.changeMoney) + qmr.HeroModel.USDT;
                t.txt_name.text = qmr.TradeModule.instance.getType(pro.type);
                t.txt_time.text = qmr.TimeUtil.getDateByTimerSecond(qmr.Int64Util.getNumber(pro.logTime));
            }
        };
        return USDTLogItemRender;
    }(eui.ItemRenderer));
    qmr.USDTLogItemRender = USDTLogItemRender;
    __reflect(USDTLogItemRender.prototype, "qmr.USDTLogItemRender");
})(qmr || (qmr = {}));
//# sourceMappingURL=USDTLogItemRender.js.map