var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var USDTLogView = (function (_super) {
        __extends(USDTLogView, _super);
        function USDTLogView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "USDTLogVSkin";
            _this.isNeedMask = true;
            return _this;
        }
        USDTLogView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.USDTLogItemRender;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
        };
        USDTLogView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
        };
        USDTLogView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnClose, t.closeView, t);
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_DIAMOND_LOG_LIST, t.updateView, t);
        };
        USDTLogView.prototype.updateView = function () {
            var t = this;
            var logs = qmr.HeroModel.instance.usdtLogs;
            if (logs) {
                logs.sort(function (a, b) {
                    return qmr.Int64Util.getNumber(b.logTime) - qmr.Int64Util.getNumber(a.logTime);
                });
            }
            t._arrCollection.replaceAll(logs);
            t.txt_totalGold.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalMoney) + qmr.HeroModel.KH;
            t.txt_totalUSDT.text = qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalUSDT) + qmr.HeroModel.USDT;
        };
        USDTLogView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return USDTLogView;
    }(qmr.BaseModule));
    qmr.USDTLogView = USDTLogView;
    __reflect(USDTLogView.prototype, "qmr.USDTLogView");
})(qmr || (qmr = {}));
//# sourceMappingURL=USDTLogView.js.map