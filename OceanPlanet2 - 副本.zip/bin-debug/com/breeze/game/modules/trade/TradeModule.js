var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var TradeModule = (function (_super) {
        __extends(TradeModule, _super);
        function TradeModule() {
            var _this = _super.call(this) || this;
            _this.sysDiamonPrice = 0; //今日系统U的指导价
            var t = _this;
            return _this;
        }
        Object.defineProperty(TradeModule, "instance", {
            get: function () {
                return this._instance || (this._instance = new TradeModule());
            },
            enumerable: true,
            configurable: true
        });
        /**
         *
         * @param pro 添加一个挂单数据
         */
        TradeModule.prototype.addBuyOrder = function (pro) {
            var t = this;
            if (!t.buyGoodsList) {
                t.buyGoodsList = [];
            }
            if (pro) {
                t.buyGoodsList.push(pro);
            }
        };
        /**
         *
         * @param pro 更新一个挂单数据
         */
        TradeModule.prototype.updateBuyOrder = function (id, count) {
            var t = this;
            if (!t.buyGoodsList) {
                t.buyGoodsList = [];
            }
            var len = t.buyGoodsList.length;
            for (var i = 0; i < len; i++) {
                if (id == qmr.Int64Util.getNumber(t.buyGoodsList[i].buyGoodMsgId)) {
                    if (count > 0) {
                        t.buyGoodsList[i].moneyCount -= count;
                    }
                    else {
                        t.buyGoodsList.splice(i, 1);
                    }
                    break;
                }
            }
        };
        TradeModule.prototype.getType = function (s) {
            //类型,1=领取鱼日产金币,2=金币买鱼,101=U买鱼
            var msg;
            switch (s) {
                case qmr.TradeTypeEnum.MONEY_REWARD:
                    msg = "领取HK";
                    break;
                case qmr.TradeTypeEnum.MONEY_BUY_FISH:
                    msg = "KAD买鱼";
                    break;
                case qmr.TradeTypeEnum.OCT_SELL_MONEY:
                    msg = "交易卖出"; //"OTC-卖给Ta"
                    break;
                case qmr.TradeTypeEnum.OCT_SOMEONE_SELL_ME:
                    msg = "交易购买"; //"OTC-卖给我"
                    break;
                case qmr.TradeTypeEnum.MONEY_EXCHANGE_KAD:
                    msg = "兑换消耗HK"; //"KAD-用金币兑换KAD，消耗金币"
                    break;
                case qmr.TradeTypeEnum.DIAMOND_BUY_FISH:
                    msg = "USDT买鱼"; //"U买鱼"
                    break;
                case qmr.TradeTypeEnum.OCT_BUY_MONEY_COST_U:
                    msg = "买入金币"; //"OTC-买入金币（挂单）"
                    break;
                case qmr.TradeTypeEnum.OCT_SELL_MONEY_GOT_U:
                    msg = "卖出金币"; //"OTC-卖给Ta，获得U"
                    break;
                case qmr.TradeTypeEnum.OCT_CANCEL_GOT_U:
                    msg = "撤单"; //"OTC-撤单，获得U"
                    break;
                case qmr.TradeTypeEnum.KAD_BONUS_GOT_U:
                    msg = "分红"; //"KAD-注入每日分红，获得U"
                    break;
                case qmr.TradeTypeEnum.EXCHANGE_GOT_KAD:
                    msg = "兑换获得KAD"; //"KAD-用金币兑换KAD，得到KAD"
                    break;
                case qmr.TradeTypeEnum.INJECT_COST_KAD:
                    msg = "注入KAD"; //"KAD-注入，消耗KAD"
                    break;
                case qmr.TradeTypeEnum.INJECT_EXPIRE_GOT_KAD:
                    msg = "注入返还"; //"KAD-注入到期，返还KAD"
                    break;
            }
            return msg;
        };
        return TradeModule;
    }(qmr.BaseModel));
    qmr.TradeModule = TradeModule;
    __reflect(TradeModule.prototype, "qmr.TradeModule");
})(qmr || (qmr = {}));
//# sourceMappingURL=TradeModule.js.map