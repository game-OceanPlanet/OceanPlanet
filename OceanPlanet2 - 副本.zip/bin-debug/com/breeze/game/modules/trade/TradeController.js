var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var TradeController = (function (_super) {
        __extends(TradeController, _super);
        function TradeController() {
            return _super.call(this) || this;
        }
        Object.defineProperty(TradeController, "instance", {
            get: function () {
                return this._instance || (this._instance = new TradeController());
            },
            enumerable: true,
            configurable: true
        });
        TradeController.prototype.initListeners = function () {
            this.addSocketListener(qmr.MessageID.S_GET_OCT_MARKET_INFO, this.getOTCResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_MARKET_BUY, this.getBuyOrderResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_MARKET_SELL, this.getSellOrderResponse, this, false);
            this.addSocketListener(qmr.MessageID.S_MARKET_CANCEL, this.getBuyOrderRevokeResponse, this, false);
        };
        //获取otc信息
        TradeController.prototype.requestOTCInfo = function () {
            var c = new com.message.C_GET_OCT_MARKET_INFO();
            this.sendCmd(c, qmr.MessageID.C_GET_OCT_MARKET_INFO, true);
        };
        // 获取otc信息
        TradeController.prototype.getOTCResponse = function (s) {
            qmr.TradeModule.instance.sysDiamonPrice = qmr.Int64Util.getNumber(s.sysDiamondPrice);
            qmr.TradeModule.instance.buyGoodsList = s.buyGoodMsgList;
            qmr.TradeModule.instance.historyPrices = s.historyPriceMsgList;
            this.dispatch(qmr.NotifyConst.S_GET_OCT_MARKET_INFO);
        };
        //请求: 买入金币（挂单）
        TradeController.prototype.getBuyOrderRequest = function (count, price) {
            var c = new com.message.C_MARKET_BUY();
            c.diamondPrice = price;
            c.moneyCount = count;
            this.sendCmd(c, qmr.MessageID.C_MARKET_BUY, true);
        };
        // 响应:买入金币（挂单）
        TradeController.prototype.getBuyOrderResponse = function (s) {
            qmr.TradeModule.instance.addBuyOrder(s.buyGoodMsg);
            this.dispatch(qmr.NotifyConst.S_MARKET_BUY);
        };
        //请求: 卖给Ta，获得U
        TradeController.prototype.getSellOrderRequest = function (id, count) {
            var c = new com.message.C_MARKET_SELL();
            c.buyGoodMsgId = id;
            c.sellMoneyCount = count;
            this.sendCmd(c, qmr.MessageID.C_MARKET_SELL, true);
        };
        // 响应: 卖给Ta，获得U
        TradeController.prototype.getSellOrderResponse = function (s) {
            qmr.TradeModule.instance.updateBuyOrder(qmr.Int64Util.getNumber(s.buyGoodMsgId), s.sellMoneyCount);
            this.dispatch(qmr.NotifyConst.S_MARKET_SELL);
        };
        //请求: 撤单
        TradeController.prototype.getBuyOrderRevokeRequest = function (id) {
            var c = new com.message.C_MARKET_CANCEL();
            c.buyGoodMsgId = id;
            this.sendCmd(c, qmr.MessageID.C_MARKET_CANCEL, true);
        };
        // 响应: 撤单
        TradeController.prototype.getBuyOrderRevokeResponse = function (s) {
            qmr.TradeModule.instance.updateBuyOrder(qmr.Int64Util.getNumber(s.buyGoodMsgId), 0);
            this.dispatch(qmr.NotifyConst.S_MARKET_CANCEL);
        };
        return TradeController;
    }(qmr.BaseController));
    qmr.TradeController = TradeController;
    __reflect(TradeController.prototype, "qmr.TradeController");
})(qmr || (qmr = {}));
//# sourceMappingURL=TradeController.js.map