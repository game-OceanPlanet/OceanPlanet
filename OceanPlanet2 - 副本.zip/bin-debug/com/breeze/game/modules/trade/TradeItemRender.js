var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var TradeItemRender = (function (_super) {
        __extends(TradeItemRender, _super);
        function TradeItemRender() {
            var _this = _super.call(this) || this;
            _this.skinName = "BuyGoodItemSkin";
            return _this;
        }
        TradeItemRender.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            var t = this;
            qmr.DisplayUtils.addClick(t.btn_sell_group, t.onSellClick, t);
            qmr.DisplayUtils.addClick(t.btn_revoke, t.onRevekeClick, t);
        };
        TradeItemRender.prototype.onSellClick = function () {
            var t = this;
            var pro = t.data;
            if (!pro) {
                return;
            }
            var myCount = qmr.HeroModel.instance.totalMoney;
            if (myCount <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("持有货币不足");
                return;
            }
            var msg = "本次价格：" + pro.diamondPrice + qmr.HeroModel.USDT + "/个" + "\r"
                + "最大出售数量：" + pro.moneyCount + qmr.HeroModel.KH + "\r"
                + "账户可用余额：" + qmr.NumberUtil.getFloat4Number2String(qmr.HeroModel.instance.totalMoney) + qmr.HeroModel.KH;
            qmr.PromptController.instance.showPromptInput(msg, function (count) {
                var pro = t.data;
                if (!pro) {
                    return;
                }
                qmr.TradeController.instance.getSellOrderRequest(qmr.Int64Util.getNumber(pro.buyGoodMsgId), count);
            }, t, null, null, "卖出提示", "卖出", pro.moneyCount, 0, pro.diamondPrice, qmr.HeroModel.instance.totalMoney);
        };
        TradeItemRender.prototype.onRevekeClick = function () {
            var t = this;
            var pro = t.data;
            if (!pro) {
                return;
            }
            qmr.TradeController.instance.getBuyOrderRevokeRequest(qmr.Int64Util.getNumber(pro.buyGoodMsgId));
        };
        TradeItemRender.prototype.dataChanged = function () {
            var t = this;
            var pro = t.data;
            if (pro) {
                t.txt_id.text = pro.playerId.toString();
                t.txt_price.text = pro.diamondPrice + qmr.HeroModel.USDT;
                t.txt_count.text = pro.moneyCount + qmr.HeroModel.KH;
                t.txt_time.text = qmr.TimeUtil.getDateByTimer(qmr.Int64Util.getNumber(pro.createTime));
                t.btn_revoke.visible = qmr.Int64Util.getNumber(pro.playerId) == qmr.HeroModel.instance.playerId;
                t.btn_sell_group.visible = qmr.Int64Util.getNumber(pro.playerId) != qmr.HeroModel.instance.playerId;
            }
        };
        return TradeItemRender;
    }(eui.ItemRenderer));
    qmr.TradeItemRender = TradeItemRender;
    __reflect(TradeItemRender.prototype, "qmr.TradeItemRender");
})(qmr || (qmr = {}));
//# sourceMappingURL=TradeItemRender.js.map