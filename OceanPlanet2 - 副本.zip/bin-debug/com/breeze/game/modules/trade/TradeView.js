var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var TradeView = (function (_super) {
        __extends(TradeView, _super);
        function TradeView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "PriceSkin";
            _this.isNeedMask = true;
            _this.helpId = qmr.HelpId.ID_5;
            return _this;
        }
        TradeView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
            t.item_list.itemRenderer = qmr.TradeItemRender;
            t._arrCollection = new eui.ArrayCollection();
            t.item_list.dataProvider = t._arrCollection;
            // t.text_input_price.restrict = new RegExp(reg);
            // t.text_input_price.restrict = reg;
            t._stepLabels = [t.txt_price0, t.txt_price1, t.txt_price2, t.txt_price3, t.txt_price4, t.txt_price5];
            t._dateLabels = [t.txt_date0, t.txt_date1, t.txt_date2, t.txt_date3, t.txt_date4, t.txt_date5, t.txt_date6];
            t._columns = [t.column_0, t.column_1, t.column_2, t.column_3, t.column_4, t.column_5, t.column_6];
            t._positions = [];
            for (var i = 0; i < t._columns.length; i++) {
                t._positions[i] = new egret.Point(t._columns[i].x, t._columns[i].y);
            }
        };
        TradeView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
        };
        TradeView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnReturn, t.closeView, t);
            t.addClickEvent(t.btn_buy_group, t.buyClick, t);
            t.addEvent(t.text_input_price, egret.Event.FOCUS_OUT, t.onFocusOut, t);
            t.addEvent(t.text_input_count, egret.Event.FOCUS_OUT, t.onFocusOut2, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_REWARD, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_MONEY_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_SYN_PROPERTY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_GET_OCT_MARKET_INFO, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_MARKET_BUY, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_MARKET_SELL, t.updateView, t);
            t.registerNotify(qmr.NotifyConst.S_MARKET_CANCEL, t.updateView, t);
        };
        TradeView.prototype.onFocusOut = function () {
            var price = this.text_input_price.text;
            if (!qmr.RegexpUtil.IsDouble(price)) {
                return;
            }
            if (!qmr.RegexpUtil.IsInteger(price)) {
                return;
            }
        };
        TradeView.prototype.onFocusOut2 = function () {
            var price = this.text_input_count.text;
            if (!qmr.RegexpUtil.IsInteger(price)) {
                return;
            }
        };
        TradeView.prototype.buyClick = function () {
            var t = this;
            var str = t.text_input_price.text.trim();
            if (str.length == 0) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("请输入购买价格");
                return;
            }
            var price = Number(str);
            if (price <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("输入价格有误");
                return;
            }
            if (!price) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("输入价格有误");
                return;
            }
            str = t.text_input_count.text.trim();
            if (str.length == 0) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("请输入购买数量");
                return;
            }
            var count = Number(str);
            if (count <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("输入数量有误");
                return;
            }
            if (price > qmr.TradeModule.instance.sysDiamonPrice) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("购买的价格不能大于系统指导价格");
                return;
            }
            var money = count * price;
            if (money > qmr.HeroModel.instance.totalUSDT) {
                qmr.TipManagerCommon.getInstance().createCommonColorTip("对不起购买货币不足");
                return;
            }
            qmr.TradeController.instance.getBuyOrderRequest(count, price);
        };
        TradeView.prototype.updateView = function () {
            var t = this;
            var pros = qmr.TradeModule.instance.buyGoodsList;
            var totalBuyCount = 0;
            var len;
            if (pros && pros.length > 0) {
                len = pros.length;
                for (var i = 0; i < len; i++) {
                    totalBuyCount += qmr.Int64Util.getNumber(pros[i].moneyCount);
                }
            }
            t._arrCollection.replaceAll(pros);
            t.txt_todayPrice.text = qmr.TradeModule.instance.sysDiamonPrice + qmr.HeroModel.USDT;
            t.txt_totalCount.text = totalBuyCount + qmr.HeroModel.USDT;
            var yestodayPrice;
            var todayPrice;
            var firstPrice = 0.01;
            var historyPros = qmr.TradeModule.instance.historyPrices;
            var prices = []; //最近7天的价格，不足用0补上
            var days = []; //最近7天的日期
            var startTime = qmr.ServerTime.serverTime;
            if (historyPros && historyPros.length > 0) {
                historyPros.sort(function (a, b) {
                    return qmr.Int64Util.getNumber(a.historyTime) - qmr.Int64Util.getNumber(b.historyTime);
                });
                len = historyPros.length;
                for (var i = 0; i < len; i++) {
                    prices.push(qmr.Int64Util.getNumber(historyPros[i].historyPrice));
                    days.push(qmr.Int64Util.getNumber(historyPros[i].historyTime));
                }
                todayPrice = historyPros[len - 1].historyPrice;
                if (len >= 2) {
                    yestodayPrice = historyPros[len - 2].historyPrice;
                }
            }
            if (!yestodayPrice) {
                yestodayPrice = 0.01;
            }
            if (!yestodayPrice) {
                yestodayPrice = firstPrice;
            }
            t.txt_changeValue.text = Math.ceil((todayPrice - yestodayPrice) * 100 / yestodayPrice) + "%";
            t.txt_totalChangeValue.text = Math.ceil((todayPrice - firstPrice) * 100 / firstPrice) + "%";
            if (prices.length > 7) {
                prices = prices.slice(0, 7);
                days = days.slice(0, 7);
            }
            var dayMiniSeconds = 24 * 3600 * 1000;
            var index = 1;
            startTime = days[days.length - 1];
            while (prices.length < 7) {
                prices.push(0);
                days.push(startTime + dayMiniSeconds * index);
                index++;
            }
            var maxPrice = 0;
            var minPrice = 0;
            for (var i = 0; i < prices.length; i++) {
                maxPrice = maxPrice < prices[i] ? prices[i] : maxPrice;
                // minPrice = minPrice > prices[i] ? prices[i] : minPrice;
            }
            maxPrice = maxPrice * 1.5;
            var add = (maxPrice - minPrice) / 5;
            var steps = [];
            for (var i = 0; i < 6; i++) {
                steps[i] = minPrice + add * i;
            }
            len = steps.length;
            for (var i = 0; i < len; i++) {
                t._stepLabels[i].text = qmr.NumberUtil.getFloat4Number(steps[i]) + "";
            }
            len = prices.length;
            var dt = new Date();
            for (var i = 0; i < days.length; i++) {
                dt.setTime(days[i]);
                t._dateLabels[i].text = qmr.TimeUtil.formatMD(dt);
            }
            var price;
            var maxHeight = 217;
            for (var i = 0; i < len; i++) {
                price = prices[i];
                if (maxPrice > 0) {
                    t._columns[i].height = Math.ceil(price / maxPrice * maxHeight);
                }
                else {
                    t._columns[i].height = 0;
                }
                //steps[i] / maxPrice * maxHeight;
                // t._columns[i].y = 230 - t._columns[i].height;
            }
        };
        TradeView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return TradeView;
    }(qmr.BaseModule));
    qmr.TradeView = TradeView;
    __reflect(TradeView.prototype, "qmr.TradeView");
})(qmr || (qmr = {}));
//# sourceMappingURL=TradeView.js.map