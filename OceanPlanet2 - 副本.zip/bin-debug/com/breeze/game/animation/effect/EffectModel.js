var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     *
     * @author coler
     * @description 特效数据模型
     *
     */
    var EffectModel = (function () {
        function EffectModel() {
            this._effectDic = new qmr.Dictionary();
        }
        Object.defineProperty(EffectModel, "instance", {
            get: function () {
                if (this._instance == null) {
                    this._instance = new EffectModel;
                }
                return this._instance;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *  获取特效的配置数据
         */
        EffectModel.prototype.getEffectData = function (id) {
            if (!isNaN(id) && id > 0) {
                if (this._effectDic.has(id)) {
                    return this._effectDic.get(id);
                }
                var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.EFFECTDATA, id);
                if (cfg != null)
                    this._effectDic.set(id, cfg);
                return cfg;
            }
            return null;
        };
        return EffectModel;
    }());
    qmr.EffectModel = EffectModel;
    __reflect(EffectModel.prototype, "qmr.EffectModel");
})(qmr || (qmr = {}));
//# sourceMappingURL=EffectModel.js.map