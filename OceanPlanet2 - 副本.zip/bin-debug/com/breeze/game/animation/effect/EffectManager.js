var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * coler
     * 特效管理器...后面在整理这个里。。
     *
     */
    var EffectManager = (function () {
        function EffectManager() {
        }
        Object.defineProperty(EffectManager, "instance", {
            /**  获取单例对象  */
            get: function () {
                if (this._instance == null) {
                    this._instance = new EffectManager();
                }
                return this._instance;
            },
            enumerable: true,
            configurable: true
        });
        return EffectManager;
    }());
    qmr.EffectManager = EffectManager;
    __reflect(EffectManager.prototype, "qmr.EffectManager");
})(qmr || (qmr = {}));
//# sourceMappingURL=EffectManager.js.map