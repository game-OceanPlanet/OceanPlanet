var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     *
     * @author hh
     * @date 2016.12.10
     * @description 特效工厂
     *
     */
    var EffectFactory = (function () {
        function EffectFactory() {
            this.effectPool = [];
            this.initPool();
        }
        /**
         * @description 初始化10个特效类
         */
        EffectFactory.prototype.initPool = function () {
            for (var i = 0; i < 10; i++) {
                this.effectPool.push(new qmr.BaseEffect());
            }
        };
        /**
         * @description 获取单例对象
         */
        EffectFactory.getInstance = function () {
            if (EffectFactory.instance == null) {
                EffectFactory.instance = new EffectFactory();
            }
            return EffectFactory.instance;
        };
        /**
         * @description 获取一个特效
         */
        EffectFactory.prototype.getEffect = function () {
            if (this.effectPool.length > 0) {
                return this.effectPool.shift();
            }
            return new qmr.BaseEffect();
        };
        /**
         * @description 释放一个特效
         */
        EffectFactory.prototype.releaseEffect = function (baseEffect) {
            if (this.effectPool.indexOf(baseEffect) == -1) {
                baseEffect.blendMode = egret.BlendMode.NORMAL;
                baseEffect.scaleX = baseEffect.scaleY = 1;
                baseEffect.x = 0;
                baseEffect.y = 0;
                baseEffect.rotation = 0;
                baseEffect.visible = true;
                baseEffect.timeScale = 1;
                this.effectPool.push(baseEffect);
            }
        };
        return EffectFactory;
    }());
    qmr.EffectFactory = EffectFactory;
    __reflect(EffectFactory.prototype, "qmr.EffectFactory");
})(qmr || (qmr = {}));
//# sourceMappingURL=EffectFactory.js.map