var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @description 特效基类,如果有多方向特效，全部采用分方向加载
     *
     */
    var BaseEffect = (function (_super) {
        __extends(BaseEffect, _super);
        function BaseEffect() {
            var _this = _super.call(this) || this;
            _this.cfgScale = 1; //配置的缩放比
            var t = _this;
            t.currentFrame = 1;
            t.totalFrame = 0;
            t.isStopped = true;
            t._pauseFramed = false;
            t.passedTime = 0;
            t.lastTime = 0;
            t.playTimes = 1;
            t._timeScale = 1;
            t.frameRate = 30;
            t.eventDic = {};
            t.mainClip = new qmr.AnimateClip(t.onLoaded, t);
            t.touchEnabled = t.touchChildren = false;
            return _this;
        }
        BaseEffect.prototype.getCurrentFrame = function () {
            return this.currentFrame;
        };
        Object.defineProperty(BaseEffect.prototype, "isRandomPlay", {
            get: function () {
                return this._isRandomPlay;
            },
            set: function (value) {
                this._isRandomPlay = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseEffect.prototype, "pauseFramed", {
            get: function () {
                return this._pauseFramed;
            },
            set: function (value) {
                this._pauseFramed = value;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @description 设置是否是分方向加载的特效
         */
        BaseEffect.prototype.setIsDirLoad = function (value) {
            if (this.mainClip) {
                this.mainClip.setIsDirLoad(value);
            }
        };
        /**
         * @description 资源加载完毕,需被子类继承        */
        BaseEffect.prototype.onLoaded = function () {
            this.totalFrame = this.mainClip.totalFrames;
            this.frameRate = this.mainClip.frameRate;
            this.currentFrame = this.isRandomPlay ? Math.floor(Math.random() * this.totalFrame + 1) : 1;
        };
        /**
         * @description 播放特效,先判断是否支持分方向
         * @param effectRes 特效资源
         * @param dir 特效方向,主要是用在多方向分块加载的时候
         * @param playTimes -1代表无限次
         */
        BaseEffect.prototype.play = function (effectRes, dir, playTimes, timeScale, callBack, thisObject) {
            if (dir === void 0) { dir = -1; }
            if (playTimes === void 0) { playTimes = -1; }
            if (timeScale === void 0) { timeScale = 1; }
            if (callBack === void 0) { callBack = null; }
            if (thisObject === void 0) { thisObject = null; }
            var t = this;
            t.currentFrame = 1;
            t.totalFrame = 0;
            t.playTimes = playTimes;
            t.loopCallBack = callBack;
            t.thisObject = thisObject;
            t._timeScale = timeScale;
            t._pauseFramed = false;
            t.mainClip.load(qmr.SystemPathAft.effectPath, effectRes, qmr.DirUtil.getDir(dir));
            t.addChild(t.mainClip);
            t.setIsStopped(false);
        };
        /**
         * @description 播放特效,先判断是否支持分方向
         * @param effectName 特效资源
         * @param dir 特效方向,主要是用在多方向分块加载的时候
         * @param playTimes -1代表无限次
         */
        BaseEffect.prototype.playUIEffect = function (effectName, dir, playTimes, timeScale, callBack, thisObject) {
            if (dir === void 0) { dir = -1; }
            if (playTimes === void 0) { playTimes = -1; }
            if (timeScale === void 0) { timeScale = 1; }
            if (callBack === void 0) { callBack = null; }
            if (thisObject === void 0) { thisObject = null; }
            var t = this;
            t.currentFrame = 1;
            t.totalFrame = 0;
            t.playTimes = playTimes;
            t.loopCallBack = callBack;
            t.thisObject = thisObject;
            t._timeScale = timeScale;
            t._pauseFramed = false;
            t.mainClip.load(qmr.SystemPathAft.uieffect, effectName, qmr.DirUtil.getDir(dir));
            t.addChild(t.mainClip);
            t.setIsStopped(false);
        };
        /**
        * @description 注册一个帧事件         */
        BaseEffect.prototype.registerFrameEvent = function (frame, callBack, thisObject) {
            this.eventDic[frame] = { callBack: callBack, thisObject: thisObject };
        };
        /**
        * @description 取消一个帧事件         */
        BaseEffect.prototype.unRegisterFrameEvent = function (frame) {
            if (this.eventDic[frame]) {
                this.eventDic[frame] = null;
                delete this.eventDic[frame];
            }
        };
        /**
         * @description 帧频调用         */
        BaseEffect.prototype.advanceTime = function (time) {
            var t = this;
            var advancedTime = time - t.lastTime;
            t.lastTime = time;
            var ft = t.frameIntervalTime;
            var currentTime = t.passedTime + advancedTime;
            t.passedTime = currentTime % ft;
            var num = currentTime / ft;
            if (num < 1) {
                return false;
            }
            t.render();
            while (!t._pauseFramed && num >= 1) {
                num--;
                t.currentFrame++;
                t.checkFrameEvent();
            }
            return false;
        };
        Object.defineProperty(BaseEffect.prototype, "clipBlendMode", {
            /**
             * @description 设置位图填充模式
             */
            set: function (value) {
                if (this.mainClip) {
                    this.mainClip.blendMode = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @description 检测帧事件         */
        BaseEffect.prototype.checkFrameEvent = function () {
            if (this.eventDic[this.currentFrame]) {
                var obj = this.eventDic[this.currentFrame];
                if (obj.callBack) {
                    obj.callBack.call(obj.thisObject);
                }
            }
        };
        /**
        * @description 渲染 需被子类继承*/
        BaseEffect.prototype.render = function () {
            var t = this;
            if (t.totalFrame > 0) {
                if (t.currentFrame > t.totalFrame) {
                    t.currentFrame = 1;
                    if (t.playTimes == -1) {
                        if (t.loopCallBack) {
                            t.loopCallBack.call(t.thisObject);
                        }
                    }
                    else {
                        t.playTimes--;
                        if (t.playTimes <= 0) {
                            if (t.loopCallBack) {
                                t.loopCallBack.call(t.thisObject);
                            }
                            t.dispos();
                            return;
                        }
                    }
                }
                if (t.stage) {
                    t.mainClip.render(t.currentFrame);
                }
            }
        };
        Object.defineProperty(BaseEffect.prototype, "effectWidth", {
            get: function () {
                if (this.mainClip) {
                    return this.mainClip.effectWidth;
                }
                return 0;
            },
            set: function (value) {
                if (this.mainClip) {
                    this.mainClip.effectWidth = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseEffect.prototype, "scaleXY", {
            set: function (value) {
                this.scaleX = this.scaleY = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseEffect.prototype, "frameRate", {
            /**
             * @description 设置帧频         */
            set: function (value) {
                if (value > 60) {
                    value = 60;
                }
                this._frameRate = value;
                this.frameIntervalTime = 1000 / (value * this._timeScale);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseEffect.prototype, "timeScale", {
            /**
             * @description 设置timescale
             */
            set: function (value) {
                if (value <= 0) {
                    value = 1;
                }
                var t = this;
                t._timeScale = value;
                if (!isNaN(t.frameRate)) {
                    t.frameIntervalTime = 1000 / (t._frameRate * value);
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
            * @param value
            */
        BaseEffect.prototype.setIsStopped = function (value) {
            if (this.isStopped == value) {
                return;
            }
            this.isStopped = value;
            if (value) {
                egret.stopTick(this.advanceTime, this);
            }
            else {
                this.lastTime = egret.getTimer();
                egret.startTick(this.advanceTime, this);
            }
        };
        /**
         * @description 清除
         */
        BaseEffect.prototype.clear = function () {
            if (this.mainClip) {
                this.mainClip.blendMode = egret.BlendMode.NORMAL;
                this.mainClip.dispos();
            }
            this.setIsStopped(true);
            for (var key in this.eventDic) {
                this.eventDic[key] = null;
                delete this.eventDic[key];
            }
        };
        /** 资源释放 千万不要直接调用        */
        BaseEffect.prototype.dispos = function () {
            var t = this;
            t.rotation = 0;
            t.effectWidth = 0;
            _super.prototype.dispos.call(this);
            if (t.mainClip) {
                t.mainClip.blendMode = egret.BlendMode.NORMAL;
                t.mainClip.dispos();
            }
            t.setIsStopped(true);
            for (var key in t.eventDic) {
                t.eventDic[key] = null;
                delete t.eventDic[key];
            }
            t.scaleXY = 1;
            // EffectFactory.getInstance().releaseEffect(t);
            if (t.parent) {
                t.parent.removeChild(t);
            }
        };
        return BaseEffect;
    }(qmr.BaseEffectMover));
    qmr.BaseEffect = BaseEffect;
    __reflect(BaseEffect.prototype, "qmr.BaseEffect");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseEffect.js.map