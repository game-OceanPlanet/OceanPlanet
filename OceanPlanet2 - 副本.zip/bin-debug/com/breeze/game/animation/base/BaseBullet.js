var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author hh
     * @date 2016.12.12
     * @description 子弹基类,默认所有子弹都是向上的，然后方向基于这个朝向来旋转
     *
     */
    var BaseBullet = (function (_super) {
        __extends(BaseBullet, _super);
        function BaseBullet() {
            var _this = _super.call(this) || this;
            _this.currentFrame = 1;
            _this.totalFrame = 0;
            _this.isStopped = true;
            _this.passedTime = 0;
            _this.lastTime = 0;
            _this.frameRate = 30;
            _this.mainClip = new qmr.AnimateClip(_this.onLoaded, _this);
            return _this;
        }
        /**
         * @description 播放特效
         * @param bulletRes 子弹资源
         */
        BaseBullet.prototype.play = function (bulletId, bulletRes) {
            this.currentFrame = 1;
            this.totalFrame = 0;
            this.mainClip.load(qmr.SystemPathAft.effectPath + bulletId + "/", bulletRes);
            this.addChild(this.mainClip);
        };
        /**
         * @description 资源加载完毕,需被子类继承        */
        BaseBullet.prototype.onLoaded = function () {
            this.totalFrame = this.mainClip.totalFrames;
            this.frameRate = this.mainClip.frameRate;
            this.currentFrame = 1;
            if (this.totalFrame == 1) {
                this.mainClip.render(1);
                this.setIsStopped(true);
            }
            else {
                this.setIsStopped(false);
            }
        };
        /**
         * @description 帧频调用         */
        BaseBullet.prototype.advanceTime = function (timeStamp) {
            var t = this;
            var advancedTime = timeStamp - t.lastTime;
            t.lastTime = timeStamp;
            var frameIntervalTime = t.frameIntervalTime;
            var currentTime = t.passedTime + advancedTime;
            t.passedTime = currentTime % frameIntervalTime;
            var num = currentTime / frameIntervalTime;
            if (num < 1) {
                return false;
            }
            this.render();
            while (num >= 1) {
                num--;
                this.currentFrame++;
            }
            return false;
        };
        /**
        * @description 渲染 需被子类继承*/
        BaseBullet.prototype.render = function () {
            if (this.totalFrame > 0) {
                if (this.currentFrame > this.totalFrame) {
                    this.currentFrame = 1;
                }
                this.mainClip.render(this.currentFrame);
            }
        };
        Object.defineProperty(BaseBullet.prototype, "frameRate", {
            /**
            * @description 设置帧频         */
            set: function (value) {
                if (value > 60) {
                    value = 60;
                }
                this._frameRate = value;
                this.frameIntervalTime = 1000 / value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseBullet.prototype, "timeScale", {
            /**
             * @description 设置timescale
             */
            set: function (value) {
                if (!isNaN(this.frameRate)) {
                    this.frameIntervalTime = 1000 / this._frameRate * value;
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
            * @private
            *
            * @param value
            */
        BaseBullet.prototype.setIsStopped = function (value) {
            if (this.isStopped == value) {
                return;
            }
            this.isStopped = value;
            if (value) {
                egret.stopTick(this.advanceTime, this);
            }
            else {
                this.lastTime = egret.getTimer();
                egret.startTick(this.advanceTime, this);
            }
        };
        /**
         * @description 资源释放 千万不要直接调用        */
        BaseBullet.prototype.dispos = function () {
            if (this.mainClip) {
                this.mainClip.dispos();
            }
            this.setIsStopped(true);
            if (this.parent) {
                this.parent.removeChild(this);
            }
        };
        return BaseBullet;
    }(egret.DisplayObjectContainer));
    qmr.BaseBullet = BaseBullet;
    __reflect(BaseBullet.prototype, "qmr.BaseBullet");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseBullet.js.map