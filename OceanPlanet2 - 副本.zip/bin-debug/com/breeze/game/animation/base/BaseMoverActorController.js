var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     *
     * @author hh
     * @date 2016.12.08
     * @description 基础的动画控制器
     *
     */
    var BaseMoverActorController = (function () {
        function BaseMoverActorController(moverActor) {
            this.moverActor = moverActor;
        }
        /**
         * @description 执行此控制器，需被子类继承
         */
        BaseMoverActorController.prototype.excute = function () {
        };
        /**
         * @description 取消执行此控制器,需被子类继承
         */
        BaseMoverActorController.prototype.cancelExcute = function () {
        };
        /**
         * @description 检测,需被子类继承
         */
        BaseMoverActorController.prototype.check = function () {
        };
        /**
         * @description 清除controller,需要被子类继承
         */
        BaseMoverActorController.prototype.clearController = function () {
        };
        return BaseMoverActorController;
    }());
    qmr.BaseMoverActorController = BaseMoverActorController;
    __reflect(BaseMoverActorController.prototype, "qmr.BaseMoverActorController");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseMoverActorController.js.map