var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * 基于时间的移动特效，用于战斗扩展，具有时间缩放
     */
    var BaseEffectMover = (function (_super) {
        __extends(BaseEffectMover, _super);
        function BaseEffectMover() {
            var _this = _super.call(this) || this;
            _this.speed = 30;
            _this.isMoving = false;
            return _this;
        }
        /**
         * @description 玩家移动到某个点
         * @param destX 目标X
         * @param destY 目标Y
         * @param onArrival 到达目的地返回函数
         * @param target 回调函数作用目标
         * @param nearDiatance 代表离目标点多少距离就代表走到了，停止继续移动
         */
        BaseEffectMover.prototype.moveTo = function (destX, destY, onArrival, target, argArray, nearDiatance) {
            if (onArrival === void 0) { onArrival = null; }
            if (target === void 0) { target = null; }
            if (nearDiatance === void 0) { nearDiatance = 0; }
            this.destX = destX;
            this.destY = destY;
            this.onArrival = onArrival;
            this.thisObject = target;
            this.argArray = argArray;
            this.nearDiatance = nearDiatance;
            qmr.FightTimer.instance.unRegisterTick(this.enterFrameMove, this);
            qmr.FightTimer.instance.registerTick(this.enterFrameMove, this, 33);
        };
        /**
         * @description 每帧移动
         */
        BaseEffectMover.prototype.enterFrameMove = function () {
            var t = this;
            t.disx = t.destX - t.x;
            t.disy = t.destY - t.y;
            t.distance = Math.sqrt(t.disx * t.disx + t.disy * t.disy);
            if (t.distance < 5 || t.distance < t.nearDiatance) {
                if (t.x != t.destX)
                    t.x = t.destX;
                if (t.y != t.destY)
                    t.y = t.destY;
                qmr.FightTimer.instance.unRegisterTick(this.enterFrameMove, this);
                t.onStop();
                if (t.onArrival) {
                    t.onArrival.call(t.thisObject, this.argArray);
                }
                return;
            }
            t.disx = (t.disx / t.distance) * t.speed;
            t.disy = (t.disy / t.distance) * t.speed;
            t.vx = t.disx;
            t.vy = t.disy;
            if (Math.abs(t.x - t.destX) < Math.abs(t.vx)) {
                t.vx = t.destX - t.x;
            }
            if (Math.abs(t.y - t.destY) < Math.abs(t.vy)) {
                t.vy = t.destY - t.y;
            }
            t.x += t.vx;
            t.y += t.vy;
        };
        /** 停止走动 */
        BaseEffectMover.prototype.stop = function () {
            this.onStop();
            qmr.FightTimer.instance.unRegisterTick(this.enterFrameMove, this);
        };
        /** 当停止运动的时候调用,需子类继承实现 */
        BaseEffectMover.prototype.onStop = function () {
        };
        BaseEffectMover.prototype.dispos = function () {
            this.stop();
            this.isMoving = false;
            this.onArrival = null;
            this.argArray = null;
            this.thisObject = null;
        };
        return BaseEffectMover;
    }(egret.DisplayObjectContainer));
    qmr.BaseEffectMover = BaseEffectMover;
    __reflect(BaseEffectMover.prototype, "qmr.BaseEffectMover");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseEffectMover.js.map