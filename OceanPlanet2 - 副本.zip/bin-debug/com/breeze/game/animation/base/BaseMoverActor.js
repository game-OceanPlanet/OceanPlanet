var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @description 基础的场景中怪物和人物的动画的基类
     *
     */
    var BaseMoverActor = (function (_super) {
        __extends(BaseMoverActor, _super);
        function BaseMoverActor() {
            var _this = _super.call(this) || this;
            _this.maxHp = 0; //最大血量
            _this.curHp = 0; //当前血量
            _this.controllerDic = {};
            _this.isCanMove = true;
            _this.actorContainer = new egret.DisplayObjectContainer();
            _this.actorContainer.touchChildren = false;
            _this.container = new egret.DisplayObjectContainer();
            _this.ui = _this.actorContainer;
            _this.ui.touchEnabled = true;
            _this.actorContainer.addChild(_this.container);
            _this.initController();
            return _this;
        }
        /** 初始化控制器,需被子类继承 */
        BaseMoverActor.prototype.initController = function () {
            var t = this;
            t.controllerDic[qmr.Status.IDLE] = new qmr.HeroIdleController(t);
            t.controllerDic[qmr.Status.MOVE] = new qmr.HeroMoveController(t);
            t.controllerDic[qmr.Status.SKILL] = new qmr.HeroSkillController(t);
            t.controllerDic[qmr.Status.SKILL2] = new qmr.HeroSkillController(t);
            t.controllerDic[qmr.Status.ATTACK] = new qmr.HeroAttackController(t);
            t.controllerDic[qmr.Status.ATTACK2] = new qmr.HeroAttack2Controller(t);
            t.controllerDic[qmr.Status.DEAD] = new qmr.HeroDeadController(t);
            t.controllerDic[qmr.Status.FLY] = new qmr.HeroFlyController(t);
            t.currentController = t.controllerDic[qmr.Status.IDLE];
        };
        Object.defineProperty(BaseMoverActor.prototype, "anchorOffsetX", {
            get: function () {
                return this.container.anchorOffsetX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseMoverActor.prototype, "anchorOffsetY", {
            get: function () {
                return this.container.anchorOffsetY;
            },
            enumerable: true,
            configurable: true
        });
        BaseMoverActor.prototype.getContainer = function () {
            return this.actorContainer;
        };
        /**  添加卡牌和人物之间  */
        BaseMoverActor.prototype.addToCardAndActor = function (disPlay) {
            var index = this.container.getChildIndex(this.baseActor);
            this.addChildAt(disPlay, index);
        };
        /**  添加显示对象  */
        BaseMoverActor.prototype.addChild = function (disPlay) {
            this.container.addChild(disPlay);
        };
        /** 添加显示对象到指定层级 */
        BaseMoverActor.prototype.addChildAt = function (disPlay, index) {
            this.container.addChildAt(disPlay, index);
        };
        /** 使用技能 */
        BaseMoverActor.prototype.useSkill = function (skillId, effectId, targetList) {
            this.stop();
            var currentProxy = qmr.SkillFactory.getSkillProxy(this, skillId, effectId, targetList);
            if (currentProxy)
                currentProxy.releaseSkill();
            this.changeStatus(qmr.Status.SKILL, true);
        };
        /** 保持技能施法前后状态，施法结束后，更新效果, 子类重写 */
        BaseMoverActor.prototype.catcheState = function (startState, endState) {
        };
        /** 播放跑步 */
        BaseMoverActor.prototype.onPlayMove = function () {
            this.pause();
            this.container.x = this.container.y = 0;
            var timeScale = 1;
            qmr.TweenEffectUtil.walk(this.container, true, 15, 40 + 60 / timeScale);
        };
        /** 停止跑步 */
        BaseMoverActor.prototype.onMoveStop = function () {
            this.stop();
            this.updatePos();
            this.resume();
            qmr.TweenEffectUtil.stopWalk(this.container, 40);
        };
        /** 子类重写 */
        BaseMoverActor.prototype.updatePos = function () { };
        /** 播放死亡 */
        BaseMoverActor.prototype.onPlayDead = function () {
            egret.Tween.get(this).to({ alpha: 0.1, x: this.x - 15 }, 100).call(this.onRemove, this);
            qmr.EffectPlayer.playEffect(EffectConst.ACTOR_DIE_EFFECT, this, -1, this.timeScale, true);
        };
        BaseMoverActor.prototype.onRemove = function () {
            qmr.LogUtil.logF("角色死亡。。移除");
            qmr.SceneManager.instance.removeBaseObject(this);
        };
        /** 播放待机 */
        BaseMoverActor.prototype.onPlayIdle = function () {
            this.container.rotation = 0;
            if (this.baseActor) {
                this.baseActor.gotoAndPlay(qmr.Status.IDLE, -1);
            }
            this.resume();
        };
        /** 播放施法效果 */
        BaseMoverActor.prototype.onPlayCast = function () {
            //如果有施法动作，就要施法之后，在移动目标，否则物体会抖动
            // this.pause();
        };
        /** 播放原地攻击效果 */
        BaseMoverActor.prototype.onPlayAtk = function () {
            // this.pause();
            this.container.x = this.container.y = 0;
            var timeScale = 1;
            qmr.TweenEffectUtil.attack(this.container, 40, 50 + 100 / timeScale);
        };
        /** 播放目标位置攻击效果 */
        BaseMoverActor.prototype.onPlayAtk2 = function () {
            // this.pause();
            this.container.x = this.container.y = 0;
            var timeScale = 1;
            qmr.TweenEffectUtil.attack2(this.container, 50 + 150 / timeScale);
        };
        /** 播放受击效果 */
        BaseMoverActor.prototype.onPlayHit = function () {
            // this.pause();
            this.container.x = this.container.y = 0;
            qmr.TweenEffectUtil.playHit(this.container, 70, 20);
        };
        /** 更新品质特效播放速度 */
        BaseMoverActor.prototype.updateEffectTimeScale = function () {
        };
        /** 当停止运动的时候调用 */
        BaseMoverActor.prototype.onStop = function () {
            this.isMoving = false;
            this.resume();
            this.changeStatus(qmr.Status.IDLE, true);
        };
        /** 当开始走的时候调用 */
        BaseMoverActor.prototype.onGo = function () {
            this.isMoving = true;
            this.pause();
        };
        /**  暂停  */
        BaseMoverActor.prototype.pause = function () {
            if (this.baseActor) {
                this.baseActor.setIsStopped(true);
            }
            this.setBuffIsStopped(true);
            // this.setCardEffectIsStopped(true);
        };
        /** 恢复  */
        BaseMoverActor.prototype.resume = function () {
            if (this.baseActor) {
                this.baseActor.setIsStopped(false);
            }
            this.setBuffIsStopped(false);
            // this.setCardEffectIsStopped(false);
        };
        /** 设置释放buff是否停止播放 */
        BaseMoverActor.prototype.setBuffIsStopped = function (flag) {
        };
        /** 延迟返回原来位置 */
        BaseMoverActor.prototype.delayBackPos = function (time) {
            qmr.FightTimer.instance.unRegisterTick(this.onBackPos, this);
            qmr.FightTimer.instance.registerTick(this.onBackPos, this, time, 1);
        };
        /** 突袭之后回到自己的位置，子类重写 */
        BaseMoverActor.prototype.onBackPos = function () {
            this.container.rotation = 0;
            qmr.LogUtil.logF('延迟返回原来位置');
            this.resume();
        };
        /** 一个技能释放完毕后执行 */
        BaseMoverActor.prototype.onSkilReleaselOver = function () {
            this.changeStatus(qmr.Status.IDLE, true);
        };
        /**  设置Actor的缩放 */
        BaseMoverActor.prototype.setActorScale = function (scale) {
            if (this.baseActor) {
                this.baseActor.scaleX = this.baseActor.scaleY = scale;
            }
        };
        /**  切换状态 */
        BaseMoverActor.prototype.changeStatus = function (status, force) {
            if (force === void 0) { force = false; }
            this.baseActor.gotoAndPlay(status, this.dir);
        };
        /**
         * @description 添加部件
         * @param part部件位置，参考ActorPart
         * @param partId 部件的Id
         * @param partIndex 部件层级位置,数字越大层级越高
         */
        BaseMoverActor.prototype.addPartAt = function (part, partId, partIndex, dir) {
            if (partIndex === void 0) { partIndex = -1; }
            if (dir === void 0) { dir = -1; }
            if (this.baseActor) {
                this.baseActor.addPartAt(part, partId, partIndex, dir);
            }
        };
        /** 缩放角色 */
        BaseMoverActor.prototype.addScaleYoyo = function () {
            if (this.baseActor) {
                qmr.TweenEffectUtil.breathe(this.baseActor, 0, 5000, null, true);
            }
        };
        BaseMoverActor.prototype.removeScaleYoyo = function () {
            egret.Tween.removeTweens(this.baseActor);
        };
        /**
         * @description 移除部件
         * @param part部件位置，参考ActorPart
         */
        BaseMoverActor.prototype.removePart = function (part) {
            if (this.baseActor) {
                this.baseActor.removePart(part);
            }
        };
        BaseMoverActor.prototype.getPartTexture = function (part) {
            if (part === void 0) { part = qmr.ActorPart.BODY; }
            return this.baseActor.getPart(part);
        };
        BaseMoverActor.prototype.setPartVisible = function (part, show) {
            return this.baseActor.setPartVisible(part, show);
        };
        Object.defineProperty(BaseMoverActor.prototype, "timeScale", {
            get: function () {
                if (this.baseActor) {
                    return this.baseActor.timeScale;
                }
                return 1;
            },
            set: function (value) {
                if (this.baseActor) {
                    this.baseActor.timeScale = value;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(BaseMoverActor.prototype, "isCanResetPos", {
            /**
             * 场景大小改变了，判断是否能够立刻改变位置，移动过程中不能改变立刻位置
             */
            get: function () {
                //闪现攻击，跑步，飞行
                if (this.lastStatus == qmr.Status.ATTACK2 || this.lastStatus == qmr.Status.MOVE || this.lastStatus == qmr.Status.FLY) {
                    return false;
                }
                return true;
            },
            enumerable: true,
            configurable: true
        });
        /**
         *  当物体死亡,需要被子类重写
         *  params死亡带的参数
         */
        BaseMoverActor.prototype.onDead = function (params) {
            if (params === void 0) { params = null; }
            this.stop();
            this.curHp = 0;
            this.removeBuff();
            this.changeStatus(qmr.Status.DEAD);
        };
        BaseMoverActor.prototype.removeBuff = function () {
        };
        BaseMoverActor.prototype.clearActor = function () {
            if (this.baseActor) {
                this.baseActor.dispos(false);
            }
        };
        /** 资源释放 */
        BaseMoverActor.prototype.dispos = function () {
            var t = this;
            t.curHp = 0;
            t.timeScale = 1;
            egret.Tween.removeTweens(t.baseActor);
            egret.Tween.removeTweens(t.container);
            qmr.FightTimer.instance.unRegisterTick(t.onBackPos, t);
            t.container.rotation = 0;
            t.container.x = t.container.y = 0;
            t.setActorScale(1);
            t.container.scaleX = t.container.scaleY = 1;
            if (t.currentController != null) {
                t.currentController.cancelExcute();
            }
            t.clearActor();
            _super.prototype.dispos.call(this);
        };
        return BaseMoverActor;
    }(qmr.BaseMover));
    qmr.BaseMoverActor = BaseMoverActor;
    __reflect(BaseMoverActor.prototype, "qmr.BaseMoverActor");
})(qmr || (qmr = {}));
//# sourceMappingURL=BaseMoverActor.js.map