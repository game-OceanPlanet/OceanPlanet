var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HelpTipCfg = (function (_super) {
        __extends(HelpTipCfg, _super);
        function HelpTipCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(HelpTipCfg.prototype, "id", {
            /**ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(HelpTipCfg.prototype, "title", {
            /**标题*/
            get: function () {
                return this.d["title"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(HelpTipCfg.prototype, "param", {
            /**参数*/
            get: function () {
                return this.d["param"];
            },
            enumerable: true,
            configurable: true
        });
        return HelpTipCfg;
    }(qmr.BaseBean));
    qmr.HelpTipCfg = HelpTipCfg;
    __reflect(HelpTipCfg.prototype, "qmr.HelpTipCfg");
    var PetCfg = (function (_super) {
        __extends(PetCfg, _super);
        function PetCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(PetCfg.prototype, "id", {
            /**宠物ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "name", {
            /**宠物名称*/
            get: function () {
                return this.d["name"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "resId", {
            /**模型编号*/
            get: function () {
                return this.d["resId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "level", {
            /**等级*/
            get: function () {
                return this.d["level"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "limitTime", {
            /**周期*/
            get: function () {
                return this.d["limitTime"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "monthly", {
            /**月化*/
            get: function () {
                return this.d["monthly"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "produce", {
            /**每日产出*/
            get: function () {
                return this.d["produce"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "directPerson", {
            /**直推人数*/
            get: function () {
                return this.d["directPerson"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "teamPerson", {
            /**团队规模*/
            get: function () {
                return this.d["teamPerson"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "UBuyPrice", {
            /**U购买价格*/
            get: function () {
                return this.d["UBuyPrice"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PetCfg.prototype, "price", {
            /**购买价格*/
            get: function () {
                return this.d["price"];
            },
            enumerable: true,
            configurable: true
        });
        return PetCfg;
    }(qmr.BaseBean));
    qmr.PetCfg = PetCfg;
    __reflect(PetCfg.prototype, "qmr.PetCfg");
    var MapCfg = (function (_super) {
        __extends(MapCfg, _super);
        function MapCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "mapId";
            return _this;
        }
        Object.defineProperty(MapCfg.prototype, "mapId", {
            /**地图ID*/
            get: function () {
                return this.d["mapId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MapCfg.prototype, "bgRetimes", {
            /**循环次数    (循环计算：①单波BOSS的 高度要有2000  ②无限重复的挂机地图 高度需要2000  ③3/4/5波怪的这种 需要配置BOSS地图+循环地图 总长度 超过2700，不要太长否则跑动的时间会增加）*/
            get: function () {
                return this.d["bgRetimes"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MapCfg.prototype, "bgHeight", {
            /**图片高度（美术输出的分辨率宽 和 高，750*1334 则填写1334，多张图用“|”隔开）*/
            get: function () {
                return this.d["bgHeight"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MapCfg.prototype, "bgNames", {
            /**资源名字1（支持配置多张地图，前面是循环图，BOSS是特殊图。多个地图用“|"隔开）*/
            get: function () {
                return this.d["bgNames"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MapCfg.prototype, "labelsEvent", {
            /**几波怪物的出生点，总长度的X%处出生，配置多波怪物用"|"分开*/
            get: function () {
                return this.d["labelsEvent"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MapCfg.prototype, "bgType", {
            /**背景类型:
        0：循环X波，出生点配置3个，3波怪
        1：挂机场景，一直循环
        2：一张背景图不循环，用于BOSS副本单关卡*/
            get: function () {
                return this.d["bgType"];
            },
            enumerable: true,
            configurable: true
        });
        return MapCfg;
    }(qmr.BaseBean));
    qmr.MapCfg = MapCfg;
    __reflect(MapCfg.prototype, "qmr.MapCfg");
    var XinHangUpCfg = (function (_super) {
        __extends(XinHangUpCfg, _super);
        function XinHangUpCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "mapId";
            return _this;
        }
        Object.defineProperty(XinHangUpCfg.prototype, "mapId", {
            /**战斗地图ID*/
            get: function () {
                return this.d["mapId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "name", {
            /**名字*/
            get: function () {
                return this.d["name"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "roadHeight", {
            /**挂机师徒四人位置高度，默认380*/
            get: function () {
                return this.d["roadHeight"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "mapResId", {
            /**挂机场景资源ID*/
            get: function () {
                return this.d["mapResId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "showUiModel", {
            /**小怪模型（多个用,分隔）*/
            get: function () {
                return this.d["showUiModel"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "bossShowUiModel", {
            /**BOSS模型（多个用,分隔）*/
            get: function () {
                return this.d["bossShowUiModel"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "time", {
            /**遇怪时长（最小时间,最大时间）*/
            get: function () {
                return this.d["time"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "step", {
            /**遇怪波数（最小波数,最大波数）*/
            get: function () {
                return this.d["step"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(XinHangUpCfg.prototype, "music", {
            /**背景音*/
            get: function () {
                return this.d["music"];
            },
            enumerable: true,
            configurable: true
        });
        return XinHangUpCfg;
    }(qmr.BaseBean));
    qmr.XinHangUpCfg = XinHangUpCfg;
    __reflect(XinHangUpCfg.prototype, "qmr.XinHangUpCfg");
    var SkillCfg = (function (_super) {
        __extends(SkillCfg, _super);
        function SkillCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "skillId";
            return _this;
        }
        Object.defineProperty(SkillCfg.prototype, "skillId", {
            /**技能id
    主角技能-101001-106000
    */
            get: function () {
                return this.d["skillId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "name", {
            /**名字*/
            get: function () {
                return this.d["name"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "level", {
            /**等级*/
            get: function () {
                return this.d["level"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "group", {
            /**技能分组*/
            get: function () {
                return this.d["group"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "seq", {
            /**概率技能优先级 多个概率技能优先级触发 普攻填0 能量型技能请填最大值100*/
            get: function () {
                return this.d["seq"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "desc", {
            /**描述*/
            get: function () {
                return this.d["desc"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "skillFightVal", {
            /**技能战斗力*/
            get: function () {
                return this.d["skillFightVal"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "icon", {
            /**图标*/
            get: function () {
                return this.d["icon"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "type", {
            /**类型 1普通技能、2概率性技能、3能量型技能*/
            get: function () {
                return this.d["type"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "nextSkillId", {
            /**下一级技能ID*/
            get: function () {
                return this.d["nextSkillId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "cost", {
            /**升级消耗*/
            get: function () {
                return this.d["cost"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "effectId", {
            /**效果ID*/
            get: function () {
                return this.d["effectId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "ultimateEffectId", {
            /**终极技能*/
            get: function () {
                return this.d["ultimateEffectId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillCfg.prototype, "isHide", {
            /**武将tips中是否不展示（1，不展示）*/
            get: function () {
                return this.d["isHide"];
            },
            enumerable: true,
            configurable: true
        });
        return SkillCfg;
    }(qmr.BaseBean));
    qmr.SkillCfg = SkillCfg;
    __reflect(SkillCfg.prototype, "qmr.SkillCfg");
    var TemplateCfg = (function (_super) {
        __extends(TemplateCfg, _super);
        function TemplateCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "mapId";
            return _this;
        }
        Object.defineProperty(TemplateCfg.prototype, "mapId", {
            /**地图ID*/
            get: function () {
                return this.d["mapId"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TemplateCfg.prototype, "mapname", {
            /**地图名*/
            get: function () {
                return this.d["mapname"];
            },
            enumerable: true,
            configurable: true
        });
        return TemplateCfg;
    }(qmr.BaseBean));
    qmr.TemplateCfg = TemplateCfg;
    __reflect(TemplateCfg.prototype, "qmr.TemplateCfg");
    var InjectCycleCfg = (function (_super) {
        __extends(InjectCycleCfg, _super);
        function InjectCycleCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(InjectCycleCfg.prototype, "id", {
            /**周期ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InjectCycleCfg.prototype, "weights", {
            /**权重*/
            get: function () {
                return this.d["weights"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InjectCycleCfg.prototype, "cycle", {
            /**周期时长*/
            get: function () {
                return this.d["cycle"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InjectCycleCfg.prototype, "des", {
            /**周期描述*/
            get: function () {
                return this.d["des"];
            },
            enumerable: true,
            configurable: true
        });
        return InjectCycleCfg;
    }(qmr.BaseBean));
    qmr.InjectCycleCfg = InjectCycleCfg;
    __reflect(InjectCycleCfg.prototype, "qmr.InjectCycleCfg");
    var TradeCostCfg = (function (_super) {
        __extends(TradeCostCfg, _super);
        function TradeCostCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(TradeCostCfg.prototype, "id", {
            /**编号*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TradeCostCfg.prototype, "count", {
            /**直推人数*/
            get: function () {
                return this.d["count"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TradeCostCfg.prototype, "precent", {
            /**手续费比例*/
            get: function () {
                return this.d["precent"];
            },
            enumerable: true,
            configurable: true
        });
        return TradeCostCfg;
    }(qmr.BaseBean));
    qmr.TradeCostCfg = TradeCostCfg;
    __reflect(TradeCostCfg.prototype, "qmr.TradeCostCfg");
    var CommonConfigCfg = (function (_super) {
        __extends(CommonConfigCfg, _super);
        function CommonConfigCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(CommonConfigCfg.prototype, "id", {
            /**ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(CommonConfigCfg.prototype, "param", {
            /**参数*/
            get: function () {
                return this.d["param"];
            },
            enumerable: true,
            configurable: true
        });
        return CommonConfigCfg;
    }(qmr.BaseBean));
    qmr.CommonConfigCfg = CommonConfigCfg;
    __reflect(CommonConfigCfg.prototype, "qmr.CommonConfigCfg");
    var SkillEffectCfg = (function (_super) {
        __extends(SkillEffectCfg, _super);
        function SkillEffectCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(SkillEffectCfg.prototype, "id", {
            /**技能效果ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "action_type", {
            /**动效类型（
        1.移动到目标位置攻击：普攻刀光。。
        2.突现到目标位置：闪现突刺
        3.远程，子弹飞行攻击：弹道
        4.远程，天降技能，同时受击：群疗类，群体效果，所有目标都会播放一个单独的表现效果，同时播放受击效果
        5.远程，天降技能，中心受击之后，外网再次受击（暂未测用）
        6.远程，闪攻击，目标依次受击：闪电链
        7.治疗，仅仅有施法，治疗受击：灵宠治疗
        8.远程，暴风雪在2和5、8和11之间释放一个效果：远程AOE，特效表现在固定点
        9.远程，播放一个弹道效果之后在2和5、8和11之间释放一个效果：对固定点播放弹道效果，弹道（AOE）特效的方向 需要旋转
        10.远程，播放一个弹道效果之后在2和5、8和11之间释放一个效果（无角度）对固定点播放弹道效果，弹道（AOE）无方向，不需要旋转
        11.远程，目标对应列下方飞出（男主飞剑技能）
        12.远程，播放一个弹道效果从己方外面，飞行到对面界面外）：牛魔王的蛮牛冲，坐骑部分技能*/
            get: function () {
                return this.d["action_type"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cast_effect", {
            /**起手特效*/
            get: function () {
                return this.d["cast_effect"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cast_showTime", {
            /**起手特效（持续播放时间）*/
            get: function () {
                return this.d["cast_showTime"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cast_time", {
            /**起手时间（多久之后播放表现特效）*/
            get: function () {
                return this.d["cast_time"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "show_effect", {
            /**表现特效*/
            get: function () {
                return this.d["show_effect"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "speed", {
            /**飞行速度，远程技能需要*/
            get: function () {
                return this.d["speed"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "orderly_effect", {
            /**闪电链/远程AOE依次触发效果*/
            get: function () {
                return this.d["orderly_effect"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "show_durotion", {
            /**表现持续时间*/
            get: function () {
                return this.d["show_durotion"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "show_time", {
            /**表现特效多久之后播放爆点的间隔时间*/
            get: function () {
                return this.d["show_time"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "multiTimes", {
            /**多段伤害（针对远程技能技能13类型，多次表现,时间间隔：3,100:就是表现三次，每次间隔100毫秒）*/
            get: function () {
                return this.d["multiTimes"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "multistage", {
            /**多段伤害（表现特效开始后爆伤害的时间，第一次伤害的权重；第二次爆伤害的时间，第二次伤害的权重。。。。）*/
            get: function () {
                return this.d["multistage"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "hit_effect", {
            /**击中特效*/
            get: function () {
                return this.d["hit_effect"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "hitDelay", {
            /**命中延迟（与show_time 共同控制多久后播放爆点）*/
            get: function () {
                return this.d["hitDelay"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "shake", {
            /**是否附带震屏效果*/
            get: function () {
                return this.d["shake"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "shakeTimePoint", {
            /**震屏时间点*/
            get: function () {
                return this.d["shakeTimePoint"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "shakeTime", {
            /**震屏持续时间*/
            get: function () {
                return this.d["shakeTime"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "node_duration", {
            /**整个效果持续时长*/
            get: function () {
                return this.d["node_duration"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cameraStartTime", {
            /**镜头缩放*/
            get: function () {
                return this.d["cameraStartTime"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cameraWaitTime", {
            /**镜头聚焦之后持续时间*/
            get: function () {
                return this.d["cameraWaitTime"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SkillEffectCfg.prototype, "cameraScaleTime", {
            /**聚焦时间*/
            get: function () {
                return this.d["cameraScaleTime"];
            },
            enumerable: true,
            configurable: true
        });
        return SkillEffectCfg;
    }(qmr.BaseBean));
    qmr.SkillEffectCfg = SkillEffectCfg;
    __reflect(SkillEffectCfg.prototype, "qmr.SkillEffectCfg");
    var EffectDataCfg = (function (_super) {
        __extends(EffectDataCfg, _super);
        function EffectDataCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(EffectDataCfg.prototype, "id", {
            /**特效Id*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "res", {
            /**特效引用资源hide*/
            get: function () {
                return this.d["res"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "playTimes", {
            /**播放次数hide*/
            get: function () {
                return this.d["playTimes"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "position", {
            /**播放位置*/
            get: function () {
                return this.d["position"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "scale", {
            /**缩放比*/
            get: function () {
                return this.d["scale"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "blendMode", {
            /**位图模式*/
            get: function () {
                return this.d["blendMode"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "isRandomPlay", {
            /**是否是随机从某一帧播放*/
            get: function () {
                return this.d["isRandomPlay"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "sound", {
            /**音效*/
            get: function () {
                return this.d["sound"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EffectDataCfg.prototype, "needOverturn", {
            /**是否需要垂直翻转*/
            get: function () {
                return this.d["needOverturn"];
            },
            enumerable: true,
            configurable: true
        });
        return EffectDataCfg;
    }(qmr.BaseBean));
    qmr.EffectDataCfg = EffectDataCfg;
    __reflect(EffectDataCfg.prototype, "qmr.EffectDataCfg");
    var CodeCfgCfg = (function (_super) {
        __extends(CodeCfgCfg, _super);
        function CodeCfgCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(CodeCfgCfg.prototype, "id", {
            /**ID*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(CodeCfgCfg.prototype, "msg", {
            /**消息描述*/
            get: function () {
                return this.d["msg"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(CodeCfgCfg.prototype, "type", {
            /**消息类型*/
            get: function () {
                return this.d["type"];
            },
            enumerable: true,
            configurable: true
        });
        return CodeCfgCfg;
    }(qmr.BaseBean));
    qmr.CodeCfgCfg = CodeCfgCfg;
    __reflect(CodeCfgCfg.prototype, "qmr.CodeCfgCfg");
    var ClientCnCfg = (function (_super) {
        __extends(ClientCnCfg, _super);
        function ClientCnCfg(element) {
            var _this = _super.call(this, element) || this;
            _this.key = "id";
            return _this;
        }
        Object.defineProperty(ClientCnCfg.prototype, "id", {
            /**键*/
            get: function () {
                return this.d["id"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ClientCnCfg.prototype, "value", {
            /**值*/
            get: function () {
                return this.d["value"];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ClientCnCfg.prototype, "colerType", {
            /**颜色:1：绿色，0：红色 --默认不填不设置颜色*/
            get: function () {
                return this.d["colerType"];
            },
            enumerable: true,
            configurable: true
        });
        return ClientCnCfg;
    }(qmr.BaseBean));
    qmr.ClientCnCfg = ClientCnCfg;
    __reflect(ClientCnCfg.prototype, "qmr.ClientCnCfg");
})(qmr || (qmr = {}));
//# sourceMappingURL=ConfigDB.js.map