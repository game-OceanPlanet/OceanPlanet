var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ConfigManagerAft = (function () {
        function ConfigManagerAft() {
        }
        /**
         * 获取全局配置
         */
        ConfigManagerAft.getCommonConfig = function (key) {
            var config = qmr.ConfigManager.getBean(qmr.ConfigEnum.COMMONCONFIG);
            var clientCnVo = config.get(key);
            if (clientCnVo) {
                return clientCnVo.param;
            }
            return "";
        };
        /**
         * 获取中文配置
         * @param  {string} key
         */
        ConfigManagerAft.getCNValue = function (key) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            var config = qmr.ConfigManager.getBean(qmr.ConfigEnumBase.CLIENTCN);
            var clientCnVo = config.get(key);
            if (clientCnVo) {
                var msg = clientCnVo.value;
                if (args && args.length > 0) {
                    args.unshift(msg);
                    msg = qmr.StringUtils.getmsg.apply(qmr.StringUtils, args);
                }
                return msg;
            }
            return "";
        };
        return ConfigManagerAft;
    }());
    qmr.ConfigManagerAft = ConfigManagerAft;
    __reflect(ConfigManagerAft.prototype, "qmr.ConfigManagerAft");
})(qmr || (qmr = {}));
//# sourceMappingURL=ConfigManagerAft.js.map