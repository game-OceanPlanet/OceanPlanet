var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ConfigEnum = (function () {
        function ConfigEnum() {
        }
        /**游戏帮助*/
        ConfigEnum.HELPTIP = 'HelpTip';
        /**宠物*/
        ConfigEnum.PET = 'Pet';
        /**地图*/
        ConfigEnum.MAP = 'Map';
        /**  新挂机*/
        ConfigEnum.XINHANGUP = 'XinHangUp';
        /**主动技能*/
        ConfigEnum.SKILL = 'Skill';
        /**模板*/
        ConfigEnum.TEMPLATE = 'Template';
        /**OTC*/
        ConfigEnum.INJECTCYCLE = 'InjectCycle';
        /**OTC*/
        ConfigEnum.TRADECOST = 'TradeCost';
        /**全局配置*/
        ConfigEnum.COMMONCONFIG = 'CommonConfig';
        /**技能效果*/
        ConfigEnum.SKILLEFFECT = 'SkillEffect';
        /**特效*/
        ConfigEnum.EFFECTDATA = 'EffectData';
        /**消息*/
        ConfigEnum.CODECFG = 'CodeCfg';
        /**中文配置*/
        ConfigEnum.CLIENTCN = 'ClientCn';
        return ConfigEnum;
    }());
    qmr.ConfigEnum = ConfigEnum;
    __reflect(ConfigEnum.prototype, "qmr.ConfigEnum");
})(qmr || (qmr = {}));
//# sourceMappingURL=ConfigEnum.js.map