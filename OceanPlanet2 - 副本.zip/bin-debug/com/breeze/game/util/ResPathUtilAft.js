var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ResPathUtilAft = (function () {
        function ResPathUtilAft() {
        }
        /** 头像icon资源路径 */
        ResPathUtilAft.getHeadUrl = function (headName) {
            return qmr.SystemPathAft.headPath + headName + ".png";
        };
        /** 获取bg图路径 */
        ResPathUtilAft.getBgUrl = function (resName) {
            return qmr.SystemPathAft.bgPath + resName + ".png";
        };
        /** 地图资源路径 */
        ResPathUtilAft.getMapUrl = function (mapName) {
            return qmr.SystemPathAft.mapPath + mapName;
        };
        return ResPathUtilAft;
    }());
    qmr.ResPathUtilAft = ResPathUtilAft;
    __reflect(ResPathUtilAft.prototype, "qmr.ResPathUtilAft");
})(qmr || (qmr = {}));
//# sourceMappingURL=ResPathUtilAft.js.map