var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var TweenEffectUtil = (function () {
        function TweenEffectUtil() {
        }
        /**
         * 设置对象注册点
         * @param object
         * @param anchorX
         * @param anchorY
         */
        TweenEffectUtil.setAnchorXY = function (object, anchorX, anchorY) {
            if (anchorX === void 0) { anchorX = 0.5; }
            if (anchorY === void 0) { anchorY = 0.5; }
            object.x += (anchorX - object.anchorOffsetX) * object.scaleX * object.width;
            object.y += (anchorY - object.anchorOffsetY) * object.scaleY * object.height;
            object.anchorOffsetX = anchorX;
            object.anchorOffsetY = anchorY;
        };
        /**
         * 从小到大
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.magnifyEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.scaleX = object.scaleY = object.alpha = 0;
            var total = total ? total : 300;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 重置元素
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.restoreEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "skewX": 0,
                        "skewY": 0,
                        "scaleX": 1,
                        "scaleY": 1,
                        "rotation": 0
                    }
                }
            ];
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从大到小淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.shrinkEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 0,
                        "scaleY": 0,
                        "alpha": 0
                    }
                }
            ];
            object.scaleX = object.scaleY = object.alpha = 1;
            var total = total ? total : 300;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左右飘动，alpha忽隐忽现
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.flutterEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "alpha": 0,
                        "anchorX": 1
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 1,
                        "anchorX": 0
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "alpha": 0,
                        "anchorX": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorX": 0
                    }
                }
            ];
            object.anchorOffsetX = object.alpha = 0;
            var total = total ? total : 6000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向右下角轻微缩小，再返回
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.flutterPositionEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.4,
                    "attr": {
                        "anchorX": -0.3,
                        "anchorY": -0.2,
                        "scaleX": 0.9,
                        "scaleY": 0.9,
                        "alpha": 0.7
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "anchorX": -0.2,
                        "anchorY": -0.1,
                        "scaleX": 0.95,
                        "scaleY": 0.95,
                        "alpha": 0.9
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorX": 0,
                        "anchorY": 0,
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.anchorOffsetX = object.anchorOffsetY = 0;
            object.scaleX = object.scaleY = object.alpha = 1;
            var total = total ? total : 6000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 淡入
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeInEffect = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            var total = total ? total : 500;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左侧淡入
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeInLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorOffsetX": 0
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetX = 50;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 右侧淡入
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeInRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorOffsetX": 0
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetX = -50;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 下侧淡入
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeInUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorOffsetY": 0
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetY = -50;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 下侧淡入
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeInDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorOffsetY": 0
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetY = 50;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeOut = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0,
                    }
                }
            ];
            object.alpha = 1;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左侧淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeOutLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0,
                        "anchorOffsetX": 50
                    }
                }
            ];
            object.alpha = 1;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左侧淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeOutRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0,
                        "anchorOffsetX": -50
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetX = 0;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 下侧淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeOutDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0,
                        "anchorOffsetY": -50
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 下侧淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.fadeOutUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0,
                        "anchorOffsetY": 50
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 800;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左右快速晃动
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.shake = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.22,
                    "attr": {
                        "anchorX": 0.1
                    }
                },
                {
                    "percent": 0.44,
                    "attr": {
                        "anchorX": -0.1
                    }
                },
                {
                    "percent": 0.66,
                    "attr": {
                        "anchorX": 0.1
                    }
                },
                {
                    "percent": 0.88,
                    "attr": {
                        "anchorX": -0.1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorX": 0
                    }
                }
            ];
            var total = total ? total : 450;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上压扁
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.skip = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "scaleY": 0.8
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleY": 1.2
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "scaleY": 0.8
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleY": 1
                    }
                }
            ];
            object.scaleY = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向下淡化再复位，最终alpha为透明
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.arrowDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 1,
                        "anchorY": -0.5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0.3,
                        "anchorY": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上淡化再复位
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.arrowUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 0.3,
                        "anchorY": 0.5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorY": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向右淡化再复位
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.arrowRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 0.3,
                        "anchorX": -0.5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1,
                        "anchorX": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetX = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向左淡化再复位
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.arrowLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 1,
                        "anchorX": 0.5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0.3,
                        "anchorX": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetX = 0;
            easeFunName = "backIn";
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 忽隐忽现
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.flash = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "alpha": 0.4
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 0.9
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "alpha": 0.2
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 1;
            var total = total ? total : 2000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 忽隐忽现入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.flashIn = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "alpha": 0
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "alpha": 0
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 忽隐忽现退场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.flashOut = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "alpha": 0
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 旋转一周
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotation = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 1000;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: object.rotation + 360 }, total, easeFun);
        };
        /**
         * 旋转入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationIn = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = object.scaleX = object.scaleY = object.alpha = 0;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: object.rotation + 360, scaleX: 1, scaleY: 1, alpha: 1 }, total, easeFun);
        };
        /**
         * 旋转退场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationOut = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = 0;
            object.scaleX = object.scaleY = object.alpha = 1;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: object.rotation + 360, scaleX: 0, scaleY: 0, alpha: 0 }, total, easeFun);
        };
        /**
         * 从左旋转入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationInLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = 30;
            object.alpha = 0;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: 0, alpha: 1 }, total, easeFun);
        };
        /**
         * 从右旋转入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationInRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = -30;
            object.alpha = 0;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: 0, alpha: 1 }, total, easeFun);
        };
        /**
         * 向左侧旋转淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationOutLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = 0;
            object.alpha = 1;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: 30, alpha: 0 }, total, easeFun);
        };
        /**
         * 向右侧旋转淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationOutRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            total = total ? total : 500;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            object.rotation = 0;
            object.alpha = 1;
            egret.Tween.get(object, { loop: isLoop }).wait(delay).to({ rotation: -30, alpha: 0 }, total, easeFun);
        };
        /**
         * 微微放大晃动再复位
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.scaleOutRock = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.1,
                    "attr": {
                        "scaleY": 0.9,
                        "scaleX": 0.9,
                        "rotation": -3
                    }
                },
                {
                    "percent": 0.2,
                    "attr": {
                        "scaleY": 0.9,
                        "scaleX": 0.9,
                        "rotation": -3
                    }
                },
                {
                    "percent": 0.3,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": 3
                    }
                },
                {
                    "percent": 0.4,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": -3
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": 3
                    }
                },
                {
                    "percent": 0.6,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": -3
                    }
                },
                {
                    "percent": 0.7,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": 3
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "scaleY": 1.1,
                        "scaleX": 1.1,
                        "rotation": 3
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleY": 1,
                        "scaleX": 1,
                        "rotation": 0
                    }
                }
            ];
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 橡皮圈晃动
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rubberBand = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.3,
                    "attr": {
                        "scaleX": 1.25,
                        "scaleY": 0.75
                    }
                },
                {
                    "percent": 0.4,
                    "attr": {
                        "scaleX": 0.75,
                        "scaleY": 1.25
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleX": 1.15,
                        "scaleY": 0.85
                    }
                },
                {
                    "percent": 0.65,
                    "attr": {
                        "scaleX": 0.95,
                        "scaleY": 1.05
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "scaleX": 1.05,
                        "scaleY": 0.95
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1
                    }
                }
            ];
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上侧微弹
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounce = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.4,
                    "attr": {
                        "anchorY": 0.1
                    }
                },
                {
                    "percent": 0.43,
                    "attr": {
                        "anchorY": 0.2
                    }
                },
                {
                    "percent": 0.7,
                    "attr": {
                        "anchorY": 0.1
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "anchorY": 0
                    }
                },
                {
                    "percent": 0.9,
                    "attr": {
                        "anchorY": 0.04
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorY": 0
                    }
                }
            ];
            object.anchorOffsetY = 0;
            var total = total ? total : 500;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 放大微微晃动
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceIn = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "scaleX": 1.1,
                        "scaleY": 1.1
                    }
                },
                {
                    "percent": 0.4,
                    "attr": {
                        "scaleX": 0.9,
                        "scaleY": 0.9
                    }
                },
                {
                    "percent": 0.6,
                    "attr": {
                        "scaleX": 1.03,
                        "scaleY": 1.03,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "scaleX": 0.97,
                        "scaleY": 0.97
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.scaleX = object.scaleY = 0.3;
            var total = total ? total : 500;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从下侧晃动入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceInDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.6,
                    "attr": {
                        "anchorOffsetY": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "anchorOffsetY": -10,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.9,
                    "attr": {
                        "anchorOffsetY": 5,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetY": 0,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetY = -3000;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从下侧晃动入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceInUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.6,
                    "attr": {
                        "anchorOffsetY": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "anchorOffsetY": -10,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.9,
                    "attr": {
                        "anchorOffsetY": 5,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetY": 0,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetY = 3000;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从左侧晃动入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceInLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.6,
                    "attr": {
                        "anchorOffsetX": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "anchorOffsetX": -10,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.9,
                    "attr": {
                        "anchorOffsetX": 5,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetX": 0,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetX = -3000;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从右侧晃动入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceInRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.6,
                    "attr": {
                        "anchorOffsetX": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "anchorOffsetX": -10,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.9,
                    "attr": {
                        "anchorOffsetX": 5,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetX": 0,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.anchorOffsetX = 3000;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 微微放大再缩小淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceOut = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "scaleX": 0.9,
                        "scaleY": 0.9
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleX": 1.1,
                        "scaleY": 1.1
                    }
                },
                {
                    "percent": 0.55,
                    "attr": {
                        "scaleX": 1.1,
                        "scaleY": 1.1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 0.3,
                        "scaleY": 0.3,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = object.scaleX = object.scaleY = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上侧快速出场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceOutUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "anchorOffsetY": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.40,
                    "attr": {
                        "anchorOffsetY": -20,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.45,
                    "attr": {
                        "anchorOffsetY": -20,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetY": 2000,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向下侧快速出场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceOutDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "anchorOffsetY": -10,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.40,
                    "attr": {
                        "anchorOffsetY": 20,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.45,
                    "attr": {
                        "anchorOffsetY": 20,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetY": -2000,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向左侧快速出场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceOutLeft = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "anchorOffsetX": -25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetX": 2000,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetX = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向右侧快速出场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.bounceOutRight = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "anchorOffsetX": 25,
                        "alpha": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorOffsetX": -2000,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.anchorOffsetX = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 摇摆
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.swing = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.2,
                    "attr": {
                        "rotation": 15
                    }
                },
                {
                    "percent": 0.4,
                    "attr": {
                        "rotation": -10
                    }
                },
                {
                    "percent": 0.6,
                    "attr": {
                        "rotation": 5
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "rotation": -5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "rotation": 0
                    }
                }
            ];
            object.rotation = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 微微放大到正常
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.scaleIn = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.scaleX = object.scaleY = 1.2;
            var total = total ? total : 500;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 正常到微微放大淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.scaleOut = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1.2,
                        "scaleY": 1.2,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 500;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从大到小入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.scaleInBig = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.alpha = 0;
            object.scaleX = object.scaleY = 3;
            var total = total ? total : 500;
            easeFunName = "quadIn";
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从小到大淡出
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.scaleOutBig = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 3,
                        "scaleY": 3,
                        "alpha": 0
                    }
                }
            ];
            object.alpha = 1;
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 500;
            easeFunName = "quadIn";
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 从右侧斜切入场
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rightSpeedIn = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.6,
                    "attr": {
                        "skewX": 20,
                        "alpha": 1,
                        "anchorX": -0.4
                    }
                },
                {
                    "percent": 0.8,
                    "attr": {
                        "skewX": -5,
                        "alpha": 1,
                        "anchorX": -0.2
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "skewX": 0,
                        "alpha": 1,
                        "anchorX": 0
                    }
                }
            ];
            object.skewX = object.alpha = 0;
            object.anchorOffsetX = -1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 微微放大再复位
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.pluse = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleX": 1.1,
                        "scaleY": 1.1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1
                    }
                }
            ];
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 微微摇摆
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.rotationFlash = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "rotation": 5
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "rotation": -5
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "rotation": 0
                    }
                }
            ];
            object.rotation = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 呼吸效果
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.breath = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "scaleX": 0.92,
                        "scaleY": 0.92,
                        "alpha": 0.7
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "scaleX": 0.92,
                        "scaleY": 0.92,
                        "alpha": 0.7
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "alpha": 1
                    }
                }
            ];
            object.scaleX = object.scaleY = object.alpha = 1;
            var total = total ? total : 5000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上快速移动再复原
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.shiftUp = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "anchorY": 1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorY": 0
                    }
                }
            ];
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向下快速移动再复原
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.shiftDown = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.5,
                    "attr": {
                        "anchorY": -1
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "anchorY": 0
                    }
                }
            ];
            object.anchorOffsetY = 0;
            var total = total ? total : 1000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 向上移动，放大 再复原
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.jump = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            var attr = [
                {
                    "percent": 0.4,
                    "attr": {
                        "scaleX": 1.1,
                        "scaleY": 0.9,
                        "anchorY": 0.8
                    }
                },
                {
                    "percent": 0.55,
                    "attr": {
                        "scaleX": 1.8,
                        "scaleY": 0.2,
                        "anchorY": 0.9
                    }
                },
                {
                    "percent": 0.65,
                    "attr": {
                        "scaleX": 0.6,
                        "scaleY": 1.4,
                        "anchorY": 0.3
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "anchorY": 0
                    }
                }
            ];
            object.anchorOffsetY = 0;
            object.scaleX = object.scaleY = 1;
            var total = total ? total : 2000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 左右快速摇摆，暂停
         * @param object
         * @param angle
         * @param dutation
         * @param isLoop
         */
        TweenEffectUtil.rock = function (object, angle, dutation, isLoop) {
            if (angle === void 0) { angle = 25; }
            if (dutation === void 0) { dutation = 70; }
            if (isLoop === void 0) { isLoop = false; }
            var _beginRotation = object.rotation;
            var _beginRotation1 = _beginRotation + 30;
            var _disx = Math.random() * 10 + 5;
            var oldX = object.x;
            egret.Tween.get(object, { loop: isLoop }).to({ x: oldX + _disx, rotation: angle + _beginRotation1 }, dutation).to({ x: oldX, rotation: _beginRotation1 }, dutation).to({ x: oldX - _disx, rotation: _beginRotation1 - angle }, dutation)
                .to({ rotation: _beginRotation1 }, dutation).to({ x: oldX, rotation: angle + _beginRotation1 }, dutation).to({ x: oldX + _disx, rotation: _beginRotation1 }, dutation).to({ x: oldX, rotation: _beginRotation }, dutation);
        };
        /**
         * 上下 左右浮动
         * @param object
         * @param duration
         * @param space
         * @param isLoop
         * @param direction 1上下浮动 其他
         */
        TweenEffectUtil.fly = function (object, duration, space, isLoop, direction) {
            if (duration === void 0) { duration = 500; }
            if (space === void 0) { space = 3; }
            if (isLoop === void 0) { isLoop = true; }
            if (direction === void 0) { direction = 1; }
            var _oldX, _oldY;
            _oldX = object.x;
            _oldY = object.y;
            if (direction == 1) {
                egret.Tween.get(object, { loop: isLoop }).to({ y: (_oldY + space) }, duration).to({ y: _oldY }, duration).to({ y: (_oldY - space) }, duration).to({ y: _oldY }, duration);
            }
            else {
                egret.Tween.get(object, { loop: isLoop }).to({ x: (_oldX + space) }, duration).to({ x: _oldX }, duration).to({ x: (_oldX - space) }, duration).to({ x: _oldX }, duration);
            }
        };
        /**
         * @description 按钮点击效果
         */
        TweenEffectUtil.clickEffect = function (object) {
            egret.Tween.get(object).to({ scaleX: 0.9, scaleY: 0.9 }, 100).to({ scaleX: 1, scaleY: 1 }, 80);
        };
        /**
         * 具体的动画实现
         * @param object
         * @param attr
         * @param delay
         * @param total
         * @param easeFunName
         * @param isLoop
         */
        TweenEffectUtil.start = function (object, attr, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            egret.Tween.removeTweens(object);
            TweenEffectUtil.removeTimeout(object);
            var index = 0;
            var attr = attr;
            var total = total;
            var tweenTime = 0;
            if (easeFunName) {
                var easeFun = eval("egret.Ease." + easeFunName);
            }
            else {
                easeFun = null;
            }
            var t = setTimeout(function loop() {
                if (index >= attr.length) {
                    if (isLoop) {
                        index = 0;
                    }
                    else {
                        return;
                    }
                }
                if (index > 0) {
                    tweenTime = (attr[index]["percent"] - attr[index - 1]["percent"]) * total;
                }
                else {
                    tweenTime = attr[index]["percent"] * total;
                }
                egret.Tween.get(object).to(attr[index]["attr"], tweenTime, easeFun).call(loop, this);
                index++;
            }, delay);
            TweenEffectUtil.addTimeout(object, t);
        };
        TweenEffectUtil.addTimeout = function (object, t) {
            if (!TweenEffectUtil._timeoutDic)
                TweenEffectUtil._timeoutDic = new qmr.Dictionary();
            TweenEffectUtil._timeoutDic.set(object, t);
        };
        TweenEffectUtil.removeTimeout = function (object) {
            if (TweenEffectUtil._timeoutDic) {
                var t = TweenEffectUtil._timeoutDic.get(object);
                if (t > 0)
                    clearInterval(t);
            }
        };
        /**
         * 向前缓动 模拟走路效果
         * @param target 缓动目标
         * @param isLoop 是否循环
         * @param offY 上下偏移量
         * @param time 缓动时间
         */
        TweenEffectUtil.walk = function (target, isLoop, offY, time) {
            if (offY === void 0) { offY = 8; }
            if (time === void 0) { time = 180; }
            var oldx = target.y;
            var upPos = oldx - 30;
            var downPos = oldx + 10;
            egret.Tween.get(target, { loop: isLoop }).
                to({ y: downPos, scaleX: 1.07, scaleY: 1.07 }, time).
                to({ y: upPos }, time + 20).
                to({ y: upPos, scaleX: 1, scaleY: 1 }, 30).
                to({ y: oldx }, time).wait(30);
        };
        /** 紫色卡牌呼吸效果 */
        TweenEffectUtil.breathe = function (object, delay, total, easeFunName, isLoop) {
            if (delay === void 0) { delay = 0; }
            if (total === void 0) { total = 0; }
            if (easeFunName === void 0) { easeFunName = ""; }
            if (isLoop === void 0) { isLoop = false; }
            // egret.Tween.removeTweens(object);
            TweenEffectUtil.removeTimeout(object);
            var oldx = object.scaleX;
            var oldy = object.scaleY;
            var attr = [
                {
                    "percent": 0.25,
                    "attr": {
                        "scaleX": 0.95 * oldx,
                        "scaleY": 0.95 * oldy,
                    }
                },
                {
                    "percent": 0.5,
                    "attr": {
                        "scaleX": oldx,
                        "scaleY": oldy,
                    }
                },
                {
                    "percent": 0.75,
                    "attr": {
                        "scaleX": 0.95 * oldx,
                        "scaleY": 0.95 * oldy,
                    }
                },
                {
                    "percent": 1,
                    "attr": {
                        "scaleX": oldx,
                        "scaleY": oldy,
                    }
                }
            ];
            object.scaleX = oldx;
            object.scaleY = oldy;
            var total = total ? total : 5000;
            TweenEffectUtil.start(object, attr, delay, total, easeFunName, isLoop);
        };
        /**
         * 震屏2
         * @param object 要做效果的对象
         * @param delay  延迟播放的时间
         * @param total  动画总时间
         * @param easeFunName 缓动方程
         * @param isLoop 是否循环
         */
        TweenEffectUtil.shake2 = function (object, total, easeFunName) {
            if (total === void 0) { total = 200; }
            if (easeFunName === void 0) { easeFunName = ""; }
            egret.Tween.removeTweens(object);
            var time = Math.floor(total / 50);
            var oldx = object.x;
            var oldy = object.y;
            var tox1 = oldx - 3;
            var tox2 = oldx + 3;
            var toy1 = oldy - 3;
            var toy2 = oldy + 3;
            var tzero = {
                "percent": 1, "attr": {
                    "x": oldx,
                    "y": oldy
                }
            };
            var t = time + 1;
            var attr = [];
            var toj;
            var pc = 0;
            for (var i = 1; i <= time; i++) {
                pc = parseFloat((i / t).toFixed(2));
                toj = { "percent": pc };
                if (i % 2 == 1) {
                    toj["attr"] = { "x": tox1, "y": toy1 };
                }
                else {
                    toj["attr"] = { "x": tox2, "y": toy2 };
                }
                attr.push(toj);
            }
            attr.push(tzero);
            var total = total ? total : 200;
            TweenEffectUtil.start(object, attr, 0, total, easeFunName, false);
        };
        TweenEffectUtil.stopWalk = function (target, time) {
            if (time === void 0) { time = 180; }
            egret.Tween.removeTweens(target);
            egret.Tween.get(target).to({ x: 0, y: 0 }, time);
        };
        /**
         * 卡牌原地远程攻击
         */
        TweenEffectUtil.attack = function (target, offY, time) {
            if (offY === void 0) { offY = 20; }
            if (time === void 0) { time = 200; }
            var oldy = target.y;
            var pos = oldy - offY;
            egret.Tween.removeTweens(target);
            egret.Tween.get(target).to({ y: pos, scaleX: 1.1, scaleY: 1.1 }, time, egret.Ease.quintOut).to({ y: oldy, scaleX: 1, scaleY: 1 }, time * 1.5, egret.Ease.quadOut);
        };
        /** 卡牌近战攻击 */
        TweenEffectUtil.attack2 = function (object, time) {
            if (time === void 0) { time = 200; }
            var _beginRotation1 = 30;
            var _beginRotation2 = -45;
            var _beginRotation3 = 25;
            var oldX = object.x;
            var oldY = object.y;
            var tx1 = oldX + 20;
            var ty1 = oldY + 10;
            var tx2 = oldX - 20;
            var ty2 = oldY - 40;
            egret.Tween.get(object).
                to({ x: tx1, y: ty1, rotation: _beginRotation1, scaleX: 0.7, scaleY: 0.7 }, time * 0.5).
                to({ x: tx2, y: ty2, rotation: _beginRotation2, scaleX: 1.1, scaleY: 1.1 }, time * 0.5).
                to({ x: oldX, y: oldY, rotation: _beginRotation3, scaleX: 1, scaleY: 1 }, time * 0.8).
                to({ rotation: 0 }, time * 0.3);
        };
        /** 卡牌受击 */
        TweenEffectUtil.playHit = function (target, time, offset) {
            if (time === void 0) { time = 100; }
            if (offset === void 0) { offset = 20; }
            var oldx = target.x;
            var oldy = target.y;
            var toPosx = oldx + offset;
            var toPosy = oldy + offset;
            var toPosx2 = oldx - offset;
            var toPosy2 = oldy - offset;
            egret.Tween.removeTweens(target);
            egret.Tween.get(target).
                to({ x: toPosx, y: toPosy }, time).
                to({ x: toPosx2, y: toPosy2 }, time, egret.Ease.cubicInOut).
                to({ x: oldx, y: oldy }, time);
        };
        /**
         * Npc 左右上下走动
         * @param object
         * @param duration
         * @param space
         * @param isLoop
         */
        TweenEffectUtil.npcfly = function (object, duration, spacex, spacey, isLoop, npc) {
            if (duration === void 0) { duration = 500; }
            if (spacex === void 0) { spacex = 3; }
            if (spacey === void 0) { spacey = 3; }
            console.log("npcfly............");
            var _oldX, _oldY;
            _oldX = object.x;
            _oldY = object.y;
            function changeNpcScale(targetScaleX) {
                npc.scaleX = targetScaleX;
            }
            var tween = egret.Tween.get(object, { loop: isLoop })
                .to({ y: spacey, x: spacex }, duration).wait(300).call(changeNpcScale, this, [-1]).wait(300)
                .to({ y: 900, x: 200 }, duration).wait(300)
                .to({ y: 400, x: 700 }, duration).wait(300).call(changeNpcScale, this, [1]).wait(300)
                .to({ y: 1200, x: 350 }, duration).wait(300).call(changeNpcScale, this, [-1]).wait(300)
                .to({ y: _oldY, x: _oldX }, duration).wait(300).call(changeNpcScale, this, [1]).wait(300);
            return tween;
        };
        /** 快速放大，暂停一会儿后，恢复原来大小，再停留一会儿后消失 */
        TweenEffectUtil.quiclyLargenThenResetSizeThenDisappear = function (disObject, largenTime, afterLargenWaitTime, resetSizeTime, afterResetWaitTime) {
            disObject.scaleX = 0;
            disObject.scaleY = 0;
            var t = this;
            egret.Tween.get(disObject).to({ scaleX: 1.3, scaleY: 1.3 }, largenTime).wait(afterLargenWaitTime).
                to({ scaleX: 1, scaleY: 1 }, resetSizeTime).wait(afterResetWaitTime).call(function () {
                egret.Tween.removeTweens(disObject);
                disObject.parent.removeChild(disObject);
            }, t);
            return true;
        };
        /**生成一个屏幕中间往上飘的图片提示 */
        TweenEffectUtil.generateImageTip = function (res) {
            var img = new eui.Image(res);
            var t = this;
            img.addEventListener(egret.Event.COMPLETE, function () {
                img.x = qmr.StageUtil.stageWidth / 2 - img.width / 2;
                img.y = qmr.StageUtil.stageHeight / 2;
                var targetY = qmr.StageUtil.stageHeight / 3;
                egret.Tween.get(img).to({ y: targetY }, 1000).call(function () {
                    egret.Tween.removeTweens(img);
                    img.parent.removeChild(img);
                }, t);
            }, t);
            qmr.StageUtil.stage.addChild(img);
        };
        TweenEffectUtil.createBullet = function (content) {
            var t = this;
            var bulletScreenPool = TweenEffectUtil.effectPool["bulletScreenPool"];
            if (!bulletScreenPool) {
                bulletScreenPool = TweenEffectUtil.effectPool["bulletScreenPool"] = [];
            }
            var bulletScreen;
            if (bulletScreenPool.length > 0) {
                bulletScreen = bulletScreenPool.pop();
                bulletScreen.text = content;
                qmr.LogUtil.log("createBullet bulletScreenPool pop", bulletScreenPool);
                return bulletScreen;
            }
            bulletScreen = new eui.Label(content);
            bulletScreen.fontFamily = "specialGameFont";
            bulletScreen.stroke = 1;
            bulletScreen.strokeColor = 0x803f07;
            bulletScreen.size = 26;
            bulletScreen.touchEnabled = false;
            bulletScreen.addEventListener(egret.Event.REMOVED_FROM_STAGE, function (e) {
                if (e.currentTarget.parent) {
                    e.currentTarget.parent.removeChild(e.currentTarget);
                }
                egret.Tween.removeTweens(e.currentTarget);
                TweenEffectUtil.releaseBullet(e.currentTarget);
            }, t);
            qmr.LogUtil.log("createBullet bulletScreenPool createBullet", bulletScreen);
            return bulletScreen;
        };
        TweenEffectUtil.releaseBullet = function (bulletScreen) {
            var bulletScreenPool = TweenEffectUtil.effectPool["bulletScreenPool"];
            // if (!bulletScreenPool)
            // {
            //     bulletScreenPool = [];
            // }
            bulletScreenPool.push(bulletScreen);
            qmr.LogUtil.log("releaseBullet bulletScreenPool", bulletScreenPool);
        };
        /** 生成一个弹幕 */
        TweenEffectUtil.generateBulletScreen = function (content, parent) {
            if (parent === void 0) { parent = null; }
            if (!parent) {
                parent = qmr.StageUtil.stage;
            }
            var t = this;
            // let label = new eui.Label(content);
            // label.fontFamily = "specialGameFont";
            // label.stroke = 1;
            // label.strokeColor = 0x803f07;
            // label.size = 22;
            // label.touchEnabled = false;
            var bulletScreen = TweenEffectUtil.createBullet(content);
            var initX = qmr.StageUtil.stage.stageWidth;
            var initY = Math.random() * (qmr.StageUtil.stage.stageHeight * 0.6) + qmr.StageUtil.stage.stageHeight * 0.2;
            bulletScreen.x = initX;
            bulletScreen.y = initY;
            var targetX = 0 - bulletScreen.width;
            content.length;
            var moveTime = 5000 + content.length * 70;
            egret.Tween.get(bulletScreen).to({ x: targetX }, moveTime).call(function () {
                egret.Tween.removeTweens(bulletScreen);
                bulletScreen.parent.removeChild(bulletScreen);
            }, t);
            parent.addChild(bulletScreen);
        };
        /** 特效对象池 */
        TweenEffectUtil.effectPool = {};
        return TweenEffectUtil;
    }());
    qmr.TweenEffectUtil = TweenEffectUtil;
    __reflect(TweenEffectUtil.prototype, "qmr.TweenEffectUtil");
})(qmr || (qmr = {}));
//# sourceMappingURL=TweenEffectUtil.js.map