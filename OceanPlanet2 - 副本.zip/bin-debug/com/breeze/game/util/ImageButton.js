var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ImageButton = (function () {
    function ImageButton(img) {
        var me = this;
        me._img = img;
        me._baseScaleX = img.scaleX;
        me._baseScaleY = img.scaleY;
        if (img.texture) {
            imgComplete();
        }
        else {
            img.once(egret.Event.COMPLETE, imgComplete, me);
        }
        img.addEventListener(egret.TouchEvent.TOUCH_BEGIN, me.onTouchBegin, me);
        function imgComplete() {
            var txt = img.texture;
            if (txt) {
                img.anchorOffsetX = txt.textureWidth >> 1;
                img.anchorOffsetY = txt.textureHeight >> 1;
                img.x += img.anchorOffsetX * me._baseScaleX;
                img.y += img.anchorOffsetY * me._baseScaleY;
                // img.$measureContentBounds = (bounds)=>{
                // 	var offsetX = ((img.width / img.scaleX)  - img.width) * 0.5;
                // 	var offsetY = ((img.height / img.scaleY)  - img.height) * 0.5;
                // 	bounds.setTo(-1 - offsetX, -1 - offsetY, img.width / img.scaleX + 2, img.height / img.scaleY + 2);
                // };
            }
        }
    }
    ImageButton.prototype.onTouchBegin = function () {
        var me = this;
        var img = me._img;
        if (img.touchEnabled) {
            var sc = 0.94;
            img.scaleX = sc * me._baseScaleX;
            img.scaleY = sc * me._baseScaleY;
            img.once(egret.TouchEvent.TOUCH_END, me.onTouchEnd, me);
        }
        // $sound.play(SoundStatic.BUTTON);
    };
    ImageButton.prototype.onTouchEnd = function (e) {
        var me = this;
        var img = me._img;
        if (img.touchEnabled) {
            img.scaleX = me._baseScaleX;
            img.scaleY = me._baseScaleY;
            if (e.target != img) {
                img.dispatchEventWith(egret.TouchEvent.TOUCH_TAP);
            }
        }
    };
    Object.defineProperty(ImageButton.prototype, "img", {
        get: function () {
            return this._img;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ImageButton.prototype, "enabled", {
        get: function () {
            return this._img ? this.img.touchEnabled : false;
        },
        set: function (bool) {
            var me = this;
            me.$setEnable(bool);
        },
        enumerable: true,
        configurable: true
    });
    ImageButton.prototype.$setEnable = function (bool) {
        var me = this;
        if (bool != me._img.touchEnabled) {
            me._img.touchEnabled = bool;
            // me._img.filters = bool ? null : FilterUtil.FILTER_GRAY;
        }
    };
    return ImageButton;
}());
__reflect(ImageButton.prototype, "ImageButton");
//# sourceMappingURL=ImageButton.js.map