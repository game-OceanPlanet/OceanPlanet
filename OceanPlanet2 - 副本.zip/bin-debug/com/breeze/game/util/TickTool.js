var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var TickTool = (function () {
        /**
         * label 更改的文本
         * des 描述
         * thisObj 对象
         */
        function TickTool(label, des, thisObj) {
            if (label === void 0) { label = null; }
            if (des === void 0) { des = null; }
            this.label = label;
            this.des = des;
            this.thisObj = thisObj;
        }
        /** 按钮描述 */
        TickTool.prototype.setDes = function (des) {
            this.des = des;
        };
        TickTool.prototype.startTick = function (count, gap) {
            if (gap === void 0) { gap = 1000; }
            this.runing = true;
            this.count = count;
            qmr.Ticker.getInstance().registerTick(this.tick, this, gap);
            this.showMsg();
        };
        TickTool.prototype.tick = function () {
            if (this.count-- < 1) {
                this.stopTick();
                if (this.backFun) {
                    this.backFun.call(this.thisObj);
                }
                return;
            }
            if (this.updateFun) {
                this.updateFun.call(this.thisObj);
            }
            this.showMsg();
        };
        TickTool.prototype.showMsg = function () {
            if (this.label) {
                if (this.des) {
                    this.label.text = qmr.CommonTool.getMsg(this.des, this.count);
                }
            }
            if (this.btn) {
                if (this.des) {
                    this.btn.label = qmr.CommonTool.getMsg(this.des, this.count);
                }
            }
        };
        TickTool.prototype.stopTick = function () {
            if (!this.runing) {
                return;
            }
            this.runing = false;
            qmr.Ticker.getInstance().unRegisterTick(this.tick, this);
        };
        return TickTool;
    }());
    qmr.TickTool = TickTool;
    __reflect(TickTool.prototype, "qmr.TickTool");
})(qmr || (qmr = {}));
//# sourceMappingURL=TickTool.js.map