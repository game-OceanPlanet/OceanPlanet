var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var StringUtils = (function () {
        function StringUtils() {
        }
        /**
         * {0}{1}....
         *
         */
        StringUtils.getmsg = function () {
            var arg = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                arg[_i] = arguments[_i];
            }
            var s = arg.shift();
            for (var key in arg) {
                var value = arg[key];
                s = s.replace(/\{\d+\}/, value);
            }
            return s;
        };
        StringUtils.getmsg2 = function (msg, arg) {
            for (var i = 0; i < arg.length; i++) {
                var value = arg[i];
                msg = msg.replace(/\{\d+\}/, value);
            }
            return msg;
        };
        /**
        * 获取字符串真实长度：1个汉字两个字符
        * @param str
        */
        StringUtils.getCharLength = function (str) {
            var realLength = 0;
            var len = str.length;
            var charCode = -1;
            for (var i = 0; i < len; i++) {
                charCode = str.charCodeAt(i);
                if (charCode >= 0 && charCode <= 128) {
                    realLength += 1;
                }
                else {
                    realLength += 2;
                }
            }
            return realLength;
        };
        /** 根据1-999 获取汉字数字， allowZero表示如果是0的话是否显示零 */
        StringUtils.getChineseNumber = function (num, allowZero) {
            if (allowZero === void 0) { allowZero = false; }
            var dayStr = "";
            if (num == 0) {
                if (allowZero) {
                    return "零";
                }
                return dayStr;
            }
            var numStr = num + "";
            if (num > 100) {
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(0)));
                dayStr += "百";
                var shi = parseInt(numStr.charAt(1));
                if (shi > 0) {
                    dayStr += StringUtils.getChineseNumber(shi);
                    dayStr += "十";
                }
                else {
                    dayStr += "零";
                }
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(2)));
                return dayStr;
            }
            else if (num == 100) {
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(0)));
                dayStr += "百";
                return dayStr;
            }
            else if (num > 19) {
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(0)));
                dayStr += "十";
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(1)));
                return dayStr;
            }
            else if (num > 10) {
                //dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(0)));
                dayStr += "十";
                dayStr += StringUtils.getChineseNumber(parseInt(numStr.charAt(1)));
                return dayStr;
            }
            switch (num) {
                case 1:
                    dayStr = "一";
                    break;
                case 2:
                    dayStr = "二";
                    break;
                case 3:
                    dayStr = "三";
                    break;
                case 4:
                    dayStr = "四";
                    break;
                case 5:
                    dayStr = "五";
                    break;
                case 6:
                    dayStr = "六";
                    break;
                case 7:
                    dayStr = "七";
                    break;
                case 8:
                    dayStr = "八";
                    break;
                case 9:
                    dayStr = "九";
                    break;
                case 10:
                    dayStr = "十";
                    break;
            }
            return dayStr;
        };
        StringUtils.getStepStr = function (step) {
            return StringUtils.getLevelStr(step) + "j";
        };
        /** 把战力转换为万单位，保留2位小数 */
        StringUtils.getFightToWanStr = function (fightVal) {
            fightVal = fightVal / 10000;
            fightVal = Math.floor(100 * fightVal) / 100;
            return fightVal.toString();
        };
        StringUtils.getLevelStr = function (level) {
            var str;
            str = "" + level;
            if (level == 0) {
                str = "z";
            }
            else if (level == 10) {
                str = "0";
            }
            else if (level > 10 && level < 20) {
                str = "0" + (level - 10);
            }
            else if (level > 20 && (level % 10 != 0)) {
                str = str.slice(0, 1) + "0" + str.slice(1);
            }
            return str;
        };
        StringUtils.getRedOrGreenNum = function (num, bRed) {
            var color = (bRed) ? qmr.ColorQualityConst.COLOR_RED : qmr.ColorQualityConst.COLOR_GREEN;
            var msg = qmr.HtmlUtil.getHtmlTexts([
                [color, "" + num],
            ]);
            return msg;
        };
        /**段落 \n */
        StringUtils.getSectionMsg = function (info) {
            return info.replace(/\\n/g, '\n');
            ;
        };
        //缩进
        StringUtils.padLeft = function (value, padding) {
            if (typeof padding === "number") {
                return Array(padding + 1).join(" ") + value;
            }
            if (typeof padding === "string") {
                return padding + value;
            }
            throw new Error("Expected string or number, got '" + padding + "'.");
        };
        /**拷贝字符串到剪贴板 */
        StringUtils.copyClipBoard = function (message) {
            if (1) {
                window.wx['setClipboardData']({
                    data: message,
                    success: function (res) {
                        window.wx['getClipboardData']({
                            success: function (res) {
                                // console.log(res.data)
                            }
                        });
                    }
                });
            }
            else if (1) {
                window.qq['setClipboardData']({
                    data: message,
                    success: function (res) {
                        window.qq['getClipboardData']({
                            success: function (res) {
                                qmr.TipManagerCommon.getInstance().createCommonColorTip("复制成功！", true);
                            }
                        });
                    }
                });
            }
            else if (1) {
                window.qg['setClipboardData']({
                    data: message,
                    success: function (res) {
                        qmr.TipManagerCommon.getInstance().createCommonColorTip("复制成功！", true);
                    }
                });
            }
            else {
                var input = document.createElement("input");
                input.value = message;
                document.body.appendChild(input);
                input.select();
                input.setSelectionRange(0, input.value.length);
                document.execCommand('Copy');
                document.body.removeChild(input);
                qmr.TipManagerCommon.getInstance().createCommonColorTip("复制成功！", true);
            }
        };
        return StringUtils;
    }());
    qmr.StringUtils = StringUtils;
    __reflect(StringUtils.prototype, "qmr.StringUtils");
})(qmr || (qmr = {}));
//# sourceMappingURL=StringUtils.js.map