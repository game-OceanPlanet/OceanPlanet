var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * 实现一个简单的链表结构
     */
    var LinkedList = (function () {
        function LinkedList() {
            this.nodeLen = 0; //节点长度
        }
        /**
         * 添加一个节点
         */
        LinkedList.prototype.append = function (element) {
            var node = new LinkNode(element);
            var current;
            if (!this._head) {
                this._head = node;
            }
            else {
                current = this._head;
                while (current.next) {
                    current = current.next;
                }
                current.next = node; //放到链表尾
            }
            this.nodeLen += 1;
        };
        /**获取节点索引*/
        LinkedList.prototype.indexOf = function (element) {
            if (!this._head)
                return -1;
            var index = -1;
            var current = this._head;
            while (current) {
                index += 1;
                if (current.current === element) {
                    return index;
                }
                current = current.next;
            }
            return -1;
        };
        /**
         * 移除某个索引位置的节点
         */
        LinkedList.prototype.removeAt = function (pos) {
            if (!this._head)
                return;
            if (pos > -1 && pos < this.size) {
                if (pos == 0) {
                    this._head = this._head.next;
                }
                else {
                    var currentNode = this.getNodeAt(pos);
                    var prevNode = this.getNodeAt(pos - 1);
                    if (currentNode && prevNode) {
                        prevNode.next = currentNode.next;
                    }
                }
                this.nodeLen -= 1;
            }
        };
        /**
         * 获取某个索引下的节点
         */
        LinkedList.prototype.getNodeAt = function (index) {
            if (!this._head)
                return null;
            var current = this._head;
            var ind = -1;
            while (current) {
                ind += 1;
                if (ind === index) {
                    return current;
                }
                current = current.next;
            }
            return null;
        };
        Object.defineProperty(LinkedList.prototype, "head", {
            /**获取一个头节点*/
            get: function () {
                return this._head;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(LinkedList.prototype, "size", {
            /**节点长度*/
            get: function () {
                return this.nodeLen;
            },
            enumerable: true,
            configurable: true
        });
        return LinkedList;
    }());
    qmr.LinkedList = LinkedList;
    __reflect(LinkedList.prototype, "qmr.LinkedList");
    /**
     * 链表中的节点
     */
    var LinkNode = (function () {
        function LinkNode(element) {
            this.current = element;
        }
        return LinkNode;
    }());
    qmr.LinkNode = LinkNode;
    __reflect(LinkNode.prototype, "qmr.LinkNode");
})(qmr || (qmr = {}));
//# sourceMappingURL=LinkedList.js.map