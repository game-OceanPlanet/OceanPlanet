var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * 功能：文本框显示宽度固定。
     * 根据字符数量控制文本框的宽度和scale
     */
    var TextFixWidthUtil = (function () {
        function TextFixWidthUtil() {
        }
        TextFixWidthUtil.getInstance = function () {
            if (this._instance == null) {
                this._instance = new TextFixWidthUtil();
            }
            return this._instance;
        };
        TextFixWidthUtil.prototype.strlen = function (str) {
            var len = 0;
            for (var i = 0; i < str.length; i++) {
                var c = str.charCodeAt(i);
                //单字节加1   
                if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                    len++;
                }
                else {
                    len += 2;
                }
            }
            return len;
        };
        TextFixWidthUtil.prototype.fixTextBox = function (fixWidth, label) {
            if (label.textWidth > fixWidth) {
                var scale = (fixWidth) / label.textWidth;
                label.width = Math.ceil(label.textWidth);
                label.scaleX = scale;
                return true;
            }
            return false;
        };
        return TextFixWidthUtil;
    }());
    qmr.TextFixWidthUtil = TextFixWidthUtil;
    __reflect(TextFixWidthUtil.prototype, "qmr.TextFixWidthUtil");
})(qmr || (qmr = {}));
//# sourceMappingURL=TextFixWidthUtil.js.map