var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var LabelTip = (function () {
        function LabelTip() {
        }
        LabelTip.getInstance = function () {
            if (!LabelTip.instance) {
                LabelTip.instance = new LabelTip();
            }
            return LabelTip.instance;
        };
        return LabelTip;
    }());
    qmr.LabelTip = LabelTip;
    __reflect(LabelTip.prototype, "qmr.LabelTip");
})(qmr || (qmr = {}));
//# sourceMappingURL=LabelTip.js.map