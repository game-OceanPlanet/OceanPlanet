var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * @description 系统设置的一个工具类
     */
    var SettingUtil = (function () {
        function SettingUtil() {
            this.sVariantType = 0;
            var flag = egret.localStorage.getItem(qmr.PlatformConfig.channelId + "zgmrsetting" + qmr.GlobalConfig.userId);
            if (flag && flag != "undefined") {
                this.sVariantType = parseInt(flag);
            }
        }
        /**
         * @description 获取单例对象
         */
        SettingUtil.getInstance = function () {
            if (SettingUtil.instance == null) {
                SettingUtil.instance = new SettingUtil();
            }
            return SettingUtil.instance;
        };
        /**
         * @description 根据类型获取是否是屏蔽状态
         */
        SettingUtil.prototype.getForbidState = function (bit) {
            return qmr.BitUtil.checkAvalibe(this.sVariantType, bit);
        };
        /**
         * @description 设置某一位的屏蔽状态
         */
        SettingUtil.prototype.setForbidState = function (bit, value) {
            this.sVariantType = qmr.BitUtil.changeBit(this.sVariantType, bit, value);
            egret.localStorage.setItem(qmr.PlatformConfig.channelId + "zgmrsetting" + qmr.GlobalConfig.userId, this.sVariantType + "");
        };
        return SettingUtil;
    }());
    qmr.SettingUtil = SettingUtil;
    __reflect(SettingUtil.prototype, "qmr.SettingUtil");
})(qmr || (qmr = {}));
//# sourceMappingURL=SettingUtil.js.map