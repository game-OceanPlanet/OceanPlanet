var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var DisplayUtils = (function () {
        function DisplayUtils() {
        }
        DisplayUtils.removeAllChild = function (dis) {
            if (!dis)
                return;
            while (dis.numChildren) {
                var c = dis.removeChildAt(0);
            }
        };
        DisplayUtils.removeDisplay = function (dis, parent) {
            if (parent === void 0) { parent = null; }
            if (!dis)
                return;
            if (!parent) {
                parent = dis.parent;
            }
            if (!parent)
                return;
            parent.removeChild(dis);
        };
        DisplayUtils.addDisplayToTop = function (dis, parent) {
            if (parent === void 0) { parent = null; }
            if (!dis)
                return;
            if (!parent) {
                parent = dis.parent;
            }
            if (!parent)
                return;
            parent.addChild(dis);
        };
        DisplayUtils.removeClick = function (target) {
            var tempEvent;
            for (var name_1 in this.eventDic) {
                tempEvent = this.eventDic[name_1];
                if (tempEvent.target == target) {
                    tempEvent.target.removeEventListener(tempEvent.type, tempEvent.callBack, tempEvent.thisObject);
                    tempEvent.target.removeEventListener(tempEvent.type, tempEvent.callFunc, tempEvent.thisCall);
                    delete this.eventDic[name_1];
                    break;
                }
            }
        };
        DisplayUtils.removeAllEvent = function (target) {
            var code = target.hashCode;
            delete this.eventDic[code + egret.TouchEvent.TOUCH_BEGIN];
            delete this.eventDic[code + egret.TouchEvent.TOUCH_END];
            delete this.eventDic[code + egret.TouchEvent.TOUCH_CANCEL];
            delete this.eventDic[code + egret.TouchEvent.TOUCH_RELEASE_OUTSIDE];
        };
        DisplayUtils.addClick = function (target, callBack, thisObject, longPressCallBack) {
            if (longPressCallBack === void 0) { longPressCallBack = null; }
            if (!target)
                return;
            if (this.eventDic == null) {
                this.eventDic = {};
            }
            if (target instanceof eui.Group) {
                target.touchChildren = false;
            }
            var eventParams = {};
            eventParams.target = target;
            eventParams.type = egret.TouchEvent.TOUCH_BEGIN;
            eventParams.thisObject = thisObject;
            eventParams.callFunc = this.onTouchBegin;
            eventParams.longPressCallBack = longPressCallBack;
            eventParams.thisCall = this;
            if (target && !this.eventDic[target.hashCode + eventParams.type]) {
                target.addEventListener(eventParams.type, this.onTouchBegin, this);
                this.eventDic[target.hashCode + eventParams.type] = eventParams;
            }
            var eventParamsEnd = {};
            eventParamsEnd.target = target;
            eventParamsEnd.type = egret.TouchEvent.TOUCH_END;
            eventParamsEnd.callBack = callBack;
            eventParamsEnd.thisObject = thisObject;
            eventParamsEnd.callFunc = this.onTouchEnd;
            eventParamsEnd.thisCall = this;
            if (target && !this.eventDic[target.hashCode + eventParamsEnd.type]) {
                target.addEventListener(eventParamsEnd.type, this.onTouchEnd, this);
                this.eventDic[target.hashCode + eventParamsEnd.type] = eventParamsEnd;
            }
            var eventParamsCancel = {};
            eventParamsCancel.target = target;
            eventParamsCancel.type = egret.TouchEvent.TOUCH_CANCEL;
            eventParamsCancel.callBack = callBack;
            eventParamsCancel.thisObject = thisObject;
            eventParamsCancel.callFunc = this.onTouchReleaseCancel;
            eventParamsCancel.thisCall = this;
            if (target && !this.eventDic[target.hashCode + eventParamsCancel.type]) {
                target.addEventListener(eventParamsCancel.type, this.onTouchReleaseCancel, this);
                this.eventDic[target.hashCode + eventParamsCancel.type] = eventParamsCancel;
            }
            var eventParamsOutSide = {};
            eventParamsOutSide.target = target;
            eventParamsOutSide.type = egret.TouchEvent.TOUCH_RELEASE_OUTSIDE;
            eventParamsOutSide.thisObject = thisObject;
            eventParamsOutSide.callFunc = this.onTouchReleaseOutSide;
            eventParamsOutSide.thisCall = this;
            if (target && !this.eventDic[target.hashCode + eventParamsOutSide.type]) {
                target.addEventListener(eventParamsOutSide.type, this.onTouchReleaseOutSide, this);
                this.eventDic[target.hashCode + eventParamsOutSide.type] = eventParamsOutSide;
            }
        };
        /**
         * @description 当点击开始
         */
        DisplayUtils.onTouchBegin = function (evt) {
            if (this.touchBeginTaret && this.touchBeginTaret == evt.target) {
                return;
            }
            if ((egret.getTimer() - this.lastTime) < 300) {
                return;
            }
            this.touchBeginTaret = evt.target;
            this.lastTime = egret.getTimer();
            egret.Tween.get(evt.target).to({ scaleX: 1.1, scaleY: 1.1 }, 50);
            qmr.Ticker.getInstance().registerTick(this.longPress, this, 300);
        };
        /**
         * @description 当点击结束
         */
        DisplayUtils.onTouchEnd = function (evt) {
            var t = this;
            var target = evt.target;
            if (this.touchBeginTaret != target)
                return;
            this.touchBeginTaret = null;
            egret.Tween.get(target).to({ scaleX: 1, scaleY: 1 }, 50).call(function () {
                for (var key in t.eventDic) {
                    var eventParams = t.eventDic[key];
                    if (eventParams.target == target && eventParams.type == egret.TouchEvent.TOUCH_END) {
                        eventParams.callBack.call(eventParams.thisObject);
                    }
                }
            }, this);
            qmr.Ticker.getInstance().unRegisterTick(this.longPress, this);
        };
        /**
         * @description 当点击结束的时候，按钮不在被点击的对象上
         */
        DisplayUtils.onTouchReleaseCancel = function (evt) {
            if (this.touchBeginTaret != evt.currentTarget)
                return;
            this.touchBeginTaret && egret.Tween.removeTweens(this.touchBeginTaret);
            this.touchBeginTaret = null;
            evt.currentTarget.scaleX = 1;
            evt.currentTarget.scaleY = 1;
        };
        /**
         * @description 当点击结束的时候，按钮不在被点击的对象上
         */
        DisplayUtils.onTouchReleaseOutSide = function (evt) {
            if (this.touchBeginTaret != evt.target)
                return;
            this.touchBeginTaret && egret.Tween.removeTweens(this.touchBeginTaret);
            this.touchBeginTaret = null;
            evt.target.scaleX = 1;
            evt.target.scaleY = 1;
        };
        DisplayUtils.longPress = function () {
            var t = this;
            for (var key in t.eventDic) {
                var eventParams = t.eventDic[key];
                if (eventParams.target == this.touchBeginTaret && eventParams.longPressCallBack) {
                    eventParams.longPressCallBack.call(eventParams.thisObject);
                }
            }
        };
        /**
         * 发光某个对象
         */
        DisplayUtils.setGlow = function (obj, isGrey) {
            if (isGrey) {
                if (!obj.filters || obj.filters.length == 0) {
                    obj.filters = [qmr.FilterUtil.glowFilter];
                }
            }
            else {
                obj.filters = [];
            }
        };
        /**
         * 置灰某个对象,设置按钮不用滤镜了，用setBtnGray 方法
         */
        DisplayUtils.setGrey = function (obj, isGrey, isSetEnabled) {
            if (isSetEnabled === void 0) { isSetEnabled = true; }
            if (obj instanceof eui.Button && isSetEnabled) {
                obj.enabled = !isGrey;
                return;
            }
            if (isGrey) {
                if (!obj.filters || obj.filters.length == 0) {
                    obj.filters = [qmr.FilterUtil.grayFilter];
                }
                if (isSetEnabled)
                    obj.touchEnabled = false;
            }
            else {
                obj.filters = [];
                if (isSetEnabled)
                    obj.touchEnabled = true;
            }
        };
        /**
         * 置灰某个对象
         */
        DisplayUtils.setBtnGray = function (obj, isGray, isSetEnabled, btnSkinType) {
            if (isSetEnabled === void 0) { isSetEnabled = true; }
            if (btnSkinType === void 0) { btnSkinType = 1; }
            if (isGray) {
                if (isSetEnabled) {
                    obj.currentState = "disabled";
                    obj.touchEnabled = false;
                }
                else
                    obj.skinName = DisplayUtils.getBtnSkin(btnSkinType, isGray);
            }
            else {
                if (isSetEnabled)
                    obj.currentState = "up";
                else
                    obj.skinName = DisplayUtils.getBtnSkin(btnSkinType, isGray);
                obj.touchEnabled = true;
            }
        };
        DisplayUtils.getBtnSkin = function (btnSkinType, isGray) {
            var skin = "ButtonYellowSkin";
            switch (btnSkinType) {
                case qmr.BtnSkinType.Type_1:
                    skin = isGray ? "ButtonYellowDisabledSkin" : "ButtonYellowSkin";
                    break;
                case qmr.BtnSkinType.Type_2:
                    skin = isGray ? "ButtonYellowDisabledSkin1" : "ButtonYellowSkin1";
                    break;
            }
            return skin;
        };
        /**
          * 置灰一组对象
          */
        DisplayUtils.setGreyGoup = function (objGoup, isGrey) {
            var _this = this;
            objGoup.forEach(function (element) {
                _this.setGrey(element, isGrey);
            });
        };
        /**
         * 设置不可选
         */
        DisplayUtils.setDisable = function (obj, isDisable) {
            this.setGrey(obj, isDisable);
            obj.touchEnabled = !isDisable;
        };
        //设置一个对象为相对于上个容器位置
        DisplayUtils.LoadResByNameAndWH = function (obj, objParent, width, height, x, y) {
            if (x === void 0) { x = 50; }
            if (y === void 0) { y = 50; }
            obj.width = width;
            obj.height = height;
            obj.anchorOffsetX = obj.width / 2;
            obj.anchorOffsetY = obj.height / 2;
            obj.x = (objParent.width / 100) * x;
            obj.y = (objParent.height / 100) * y;
            return obj;
        };
        /**
         * 更新星星方法
         * max-星星组
         * lightNum-当前要亮的星数
         */
        DisplayUtils.updateStar = function (starGroup, lightNum) {
            var num = starGroup.numChildren;
            var star;
            for (var i = 0; i < num; i++) {
                star = starGroup.getChildAt(i);
                if (i < lightNum)
                    star.imgStar.visible = true;
                else
                    star.imgStar.visible = false;
            }
        };
        /**
         * 获取一个对象全局坐标点
         */
        DisplayUtils.getGlobelPoint = function (target) {
            if (target.parent) {
                return target.parent.localToGlobal(target.x, target.y);
            }
            return null;
        };
        return DisplayUtils;
    }());
    qmr.DisplayUtils = DisplayUtils;
    __reflect(DisplayUtils.prototype, "qmr.DisplayUtils");
})(qmr || (qmr = {}));
//# sourceMappingURL=DisplayUtils.js.map