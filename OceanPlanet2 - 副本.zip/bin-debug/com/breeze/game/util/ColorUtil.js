var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var ColorUtil = (function () {
        function ColorUtil() {
        }
        /**
         * @desc 根据品质返回对应颜色
         */
        ColorUtil.getColorByQuality = function (quality) {
            switch (quality) {
                case 1:
                    return qmr.ColorQualityConst.COLOR_G; //默认颜色改成默认颜色试试
                //return ColorConst.COLOR_WHITE;
                case 2:
                    return qmr.ColorQualityConst.COLOR_GREEN;
                case 3:
                    return qmr.ColorQualityConst.COLOR_BLUE;
                case 4:
                    return qmr.ColorQualityConst.COLOR_VIOLET;
                case 5:
                    return qmr.ColorQualityConst.COLOR_CADMIUM;
                case 6:
                    return qmr.ColorQualityConst.COLOR_RED;
                case 7:
                    return qmr.ColorQualityConst.COLOR_DIAMOND;
            }
            return qmr.ColorQualityConst.COLOR_G;
        };
        /**
         * 若类型为8，则1=绿品，2=蓝品，3=紫品，4=金品，5=红品
         * @desc 根据subType返回日常任务品质颜色
         */
        ColorUtil.getColorBySubType = function (subType) {
            switch (subType) {
                case 2:
                    return qmr.ColorQualityConst.COLOR_GREEN;
                case 3:
                    return qmr.ColorQualityConst.COLOR_BLUE;
                case 4:
                    return qmr.ColorQualityConst.COLOR_VIOLET;
                case 5:
                    return qmr.ColorQualityConst.COLOR_CADMIUM;
                case 6:
                    return qmr.ColorQualityConst.COLOR_RED;
            }
            return qmr.ColorQualityConst.COLOR_G;
        };
        ColorUtil.getTipColorByType = function (colorType) {
            switch (colorType) {
                case 0:
                    return 0xFF0000; //红色
                case 1:
                    return 0x09a608; //绿色
            }
            return 0xffffff; //白色
        };
        return ColorUtil;
    }());
    qmr.ColorUtil = ColorUtil;
    __reflect(ColorUtil.prototype, "qmr.ColorUtil");
})(qmr || (qmr = {}));
//# sourceMappingURL=ColorUtil.js.map