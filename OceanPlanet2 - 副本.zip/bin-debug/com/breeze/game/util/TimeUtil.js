var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /*
    * name;
    */
    var TimeUtil = (function () {
        function TimeUtil() {
        }
        /**
         * 根据时间返回字符串时间
         * */
        TimeUtil.getTimeBySecond = function (second) {
            var str = "";
            if (second >= 60) {
                str = this.dateStringFillZero(Math.floor(second / 60)) + ":";
            }
            str += this.dateStringFillZero(Math.floor(second % 60));
            return str;
        };
        TimeUtil.getDateByTimer = function (time) {
            if (!TimeUtil.date) {
                TimeUtil.date = new Date();
            }
            TimeUtil.date.setTime(time);
            var year = TimeUtil.date.getFullYear();
            var month = TimeUtil.date.getMonth() + 1;
            var day = TimeUtil.date.getDate();
            var hour = TimeUtil.date.getHours();
            var min = TimeUtil.date.getMinutes();
            var sec = TimeUtil.date.getSeconds();
            var monthStr = month < 10 ? ("0" + month) : month.toString();
            var dayStr = day < 10 ? ("0" + day) : day.toString();
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return year + "-" + monthStr + "-" + dayStr + " " + hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 根据时间戳返回字符串 xxxx-xx-xx 00:00:00
         * @time 秒
         */
        TimeUtil.getDateByTimerSecond = function (time) {
            return TimeUtil.getDateByTimer(time * 1000);
        };
        /**
         * 获取当前时间到明天00:00:00还有多少秒
         */
        TimeUtil.getDayOverTime = function () {
            var date = qmr.ServerTime.getSeverDate();
            var toDate = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
            return (toDate.getTime() - date.getTime()) / 1000;
        };
        /**
         * 获取当前时间点
         */
        TimeUtil.getDayTime = function () {
            var date = qmr.ServerTime.getSeverDate();
            var toDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            return (date.getTime() - toDate.getTime()) / 1000;
        };
        /**
         * 转换成今天的时间点
         */
        TimeUtil.getTimeToNow = function (time) {
            var date = new Date(time);
            var toDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            return (date.getTime() - toDate.getTime()) / 1000;
        };
        /**
         * 根据时间返回字符串 00:00:00
         */
        TimeUtil.formatDate = function (date) {
            var hour = date.getHours();
            var min = date.getMinutes();
            var sec = date.getMilliseconds();
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 根据时间返回字符串 00:00:00,超过24小时，只会显示超过的时间
         */
        TimeUtil.formatTime = function (second) {
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 根据时间返回字符串 00:00:00
         */
        TimeUtil.formatTime1 = function (second) {
            var hour = Math.floor(second / 60 / 60);
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 小时分钟
         * @param second
         * @return
         */
        TimeUtil.formatTime4 = function (second) {
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            var hourStr = hour < 10 ? ("" + hour) : hour.toString();
            var minStr = min < 10 ? ("" + min) : min.toString();
            return hourStr + this.CN_HOUR + minStr + this.CN_MIN;
        };
        /**
             *根据时间返回字符串 00分00秒
         */
        TimeUtil.formatTime5 = function (second) {
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            if (hour > 0) {
                return hourStr + this.CN_HOUR + minStr + this.CN_MIN + secStr + this.CN_SEC;
            }
            return minStr + this.CN_MIN + " " + secStr + this.CN_SEC;
        };
        /**
         * 根据时间返回字符串 00:00
         */
        TimeUtil.formatTime2 = function (second) {
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return (minStr + ":" + secStr);
        };
        /**
         * 根据时间返回字符串 00:00:00
         */
        TimeUtil.formatTime3 = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            var hour = Math.floor(second / 60 / 60) % 24 + day * 24;
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 根据时间返回字符串 xx分xx秒
         */
        TimeUtil.formatTime6 = function (second) {
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return (minStr + "分" + secStr + "秒");
        };
        /** 00:00 一天当中的多少小时分钟 */
        TimeUtil.formatTime7 = function (second) {
            var date = new Date(second);
            var min = date.getMinutes();
            var hour = date.getHours();
            var hourStr = hour < 10 ? ("0" + hour) : hour.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            return hourStr + ":" + minStr;
        };
        /**
         * 格式化数据网格列日期 MM-DD JJ:NN
         */
        TimeUtil.formatColumnDate = function (tempDate) {
            var m = ((tempDate.getMonth() + 1 < 10) ? "0" : "") + (tempDate.getMonth() + 1);
            var day = ((tempDate.getDate() < 10) ? "0" : "") + tempDate.getDate();
            var rect = "";
            rect += m + "-" + day + " ";
            rect += ((tempDate.getHours() < 10) ? "0" : "") + tempDate.getHours();
            rect += ":";
            rect += ((tempDate.getMinutes() < 10) ? "0" : "") + tempDate.getMinutes();
            return rect;
        };
        /**
         *
         * @param date
         * @return
         * 2012/12/12 12:12
         */
        TimeUtil.formatDate1 = function (date) {
            var year = date.getFullYear().toString();
            var month = ((date.getMonth() + 1 < 10) ? "0" : "") + (date.getMonth() + 1);
            var day = ((date.getDate() < 10) ? "0" : "") + date.getDate();
            var hour = date.getHours() < 10 ? ("0" + date.getHours()) : date.getHours().toString();
            var min = date.getMinutes() < 10 ? ("0" + date.getMinutes()) : date.getMinutes().toString();
            return year + "/" + month + "/" + day + " " + hour + ":" + min;
        };
        /**
         * XX年XX月XX日
         */
        TimeUtil.formatYMD = function (date) {
            var time = date.getFullYear() + this.CN_YEAR
                + (date.getMonth() + 1) + this.CN_MONTH
                + date.getDate() + this.CN_SUN;
            return time;
        };
        /**
         * 显示时间（英文格式）月/日/年
         * @return
         */
        TimeUtil.formatYMDForEn = function (date) {
            var time = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
            return time;
        };
        /**
         * 年/月/日（例：2012/12/12）
         */
        TimeUtil.formatYMD1 = function (date) {
            var time = date.getFullYear() + "/"
                + (date.getMonth() + 1) + "/"
                + date.getDate() + "/";
            return time;
        };
        /**
         * 返回月/日
         * @param date
         */
        TimeUtil.formatMD = function (date) {
            var time = (date.getMonth() + 1) + "/"
                + date.getDate();
            return time;
        };
        /**
         * XX天XX时XX分XX秒
         */
        TimeUtil.formatRemain = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            return day + this.CN_DAY + " " + hour + this.CN_HOUR + " " + min + this.CN_MIN + " " + sec + this.CN_SEC;
        };
        /**
         * XX天XX时XX分
         */
        TimeUtil.formatRemain1 = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            return day + this.CN_DAY + hour + this.CN_HOUR + min + this.CN_MIN;
        };
        TimeUtil.formatRemain3 = function (second) {
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            return hour + " " + this.CN_HOUR + " " + min + " " + this.CN_MIN;
        };
        /**
         *
         * @param second
         * @return [day,hour,min]
         *
         */
        TimeUtil.formatRemain2 = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            var hour = Math.floor(second / 60 / 60) % 24;
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            return [day, hour, min];
        };
        /**
         * 返回不为0的格式
         */
        TimeUtil.formatRemain4 = function (second) {
            var str = "";
            var getZeroize = TimeUtil.getZeroize;
            var day = Math.floor(second / 60 / 60 / 24);
            if (day != 0) {
                str += getZeroize(day) + this.CN_DAY;
            }
            var hour = Math.floor(second / 60 / 60) % 24;
            if (hour != 0) {
                str += getZeroize(hour) + this.CN_HOUR;
            }
            var min = Math.floor(second / 60) % 60;
            if (min != 0) {
                str += getZeroize(min) + this.CN_MIN;
            }
            var sec = Math.floor(second % 60);
            if (sec != 0) {
                str += getZeroize(sec) + this.CN_SEC;
            }
            return str;
        };
        /**
         * xxd,xxh,xxm,xxs
         */
        TimeUtil.formatRemain5 = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            if (day != 0) {
                return day + "d";
            }
            var hour = Math.floor(second / 60 / 60) % 24;
            if (hour != 0) {
                return hour + "h";
            }
            var min = Math.floor(second / 60) % 60;
            if (min != 0) {
                return min + "m";
            }
            var sec = Math.floor(second % 60);
            if (sec != 0) {
                return sec + "s";
            }
            return "";
        };
        /**
         *  xd 00:00:00
         */
        TimeUtil.formatRemain6 = function (second) {
            var str = "";
            var getZeroize = TimeUtil.getZeroize;
            var day = Math.floor(second / 60 / 60 / 24);
            if (day != 0) {
                str += day + this.CN_DAY + " ";
            }
            var hour = Math.floor(second / 60 / 60) % 24;
            if (hour != 0) {
                str += getZeroize(hour) + ":";
            }
            else {
                str += "00" + ":";
            }
            var min = Math.floor(second / 60) % 60;
            if (min != 0) {
                str += getZeroize(min) + ":";
            }
            else {
                str += "00" + ":";
            }
            var sec = Math.floor(second % 60);
            if (sec != 0) {
                str += getZeroize(sec);
            }
            else {
                str += "00";
            }
            return str;
        };
        /**
         *  xd 00:00:00 / 00:00
         */
        TimeUtil.formatRemain7 = function (second) {
            var str = "";
            var getZeroize = TimeUtil.getZeroize;
            var day = Math.floor(second / 60 / 60 / 24);
            if (day != 0) {
                str += day + this.CN_DAY + " ";
            }
            var hour = Math.floor(second / 60 / 60) % 24;
            if (hour != 0) {
                str += getZeroize(hour) + ":";
            }
            var min = Math.floor(second / 60) % 60;
            if (min != 0) {
                str += getZeroize(min) + ":";
            }
            else {
                str += "00" + ":";
            }
            var sec = Math.floor(second % 60);
            if (sec != 0) {
                str += getZeroize(sec);
            }
            else {
                str += "00";
            }
            return str;
        };
        /**
         * 返回不为0的格式X天X小时X分钟X秒
         */
        TimeUtil.formatRemain8 = function (second) {
            var str = "";
            var getZeroize = TimeUtil.getZeroize;
            var day = Math.floor(second / 60 / 60 / 24);
            if (day != 0) {
                str += day + this.CN_DAY;
            }
            var hour = Math.floor(second / 60 / 60) % 24;
            if (hour != 0) {
                str += hour + this.CN_HOUR;
            }
            var min = Math.floor(second / 60) % 60;
            if (min != 0) {
                str += min + this.CN_MIN + "钟";
            }
            var sec = Math.floor(second % 60);
            if (sec != 0) {
                str += sec + this.CN_SEC;
            }
            return str;
        };
        /**
         * 00:00:00
         */
        TimeUtil.formatRemainForEn = function (second) {
            var day = Math.floor(second / 60 / 60 / 24);
            var hour = Math.floor(second / 60 / 60) % 24;
            var totalH = (day * 24 + hour);
            var min = Math.floor(second / 60) % 60;
            var sec = Math.floor(second % 60);
            var hourStr = totalH < 10 ? ("0" + totalH) : totalH.toString();
            var minStr = min < 10 ? ("0" + min) : min.toString();
            var secStr = sec < 10 ? ("0" + sec) : sec.toString();
            return hourStr + ":" + minStr + ":" + secStr;
        };
        /**
         * 获取两个时间之间的相差（天、时、分、秒）
         * @param time1:Number 时间1(ms)
         * @param time2:Number 时间2(ms)
         * @return Array = [天,时,分,秒]
         */
        TimeUtil.getTimeDifference = function (time1, time2) {
            var res = [0, 0, 0, 0];
            var val = time2 - time1;
            res[0] = Math.floor(val / 86400000);
            res[1] = Math.floor(val % 86400000 / 3600000);
            res[2] = Math.floor(val % 86400000 % 3600000 / 60000);
            res[3] = Math.floor(val % 86400000 % 3600000 % 60000 / 1000);
            return res;
        };
        TimeUtil.prototype.timeStrToDate = function (timeStr) {
            var arr = timeStr.split(" ");
            var yearArr = (arr[0]).split("-");
            var timeArr = (arr[1]).split("-");
            var date = new Date(yearArr[0], yearArr[1], yearArr[2], timeArr[0], timeArr[1], timeArr[2]);
            return date;
        };
        /**
         * 不够两位的补零
         */
        TimeUtil.dateStringFillZero = function (num) {
            return (num >= 10 ? ((num * 0.1) >> 0).toString() : "0") + (num % 10).toString();
        };
        TimeUtil.gettodayTimeByHour = function (hour) {
            var data = qmr.ServerTime.getZoneOffsetSeverDate();
            data.setHours(hour);
            data.setMinutes(0);
            data.setSeconds(0);
            return data.getTime() / 1000;
        };
        /**
         * 获取时分秒
         * @param _second
         * @return
         *
         */
        TimeUtil.changeServerTimeToSeconds = function (_second) {
            var date = new Date(_second);
            var seconds = (date.getHours() * 3600) + (date.getMinutes() * 60) + date.getSeconds();
            return seconds;
        };
        /**
         * 将当日时间(非时间戳)转为毫秒
         * @param hours 小时
         * @param minutes 分钟
         * @param seconds 秒
         * @return 当日时间毫秒数
         */
        TimeUtil.timeToMilSeconds = function (hours, minutes, seconds) {
            if (hours === void 0) { hours = 0; }
            if (minutes === void 0) { minutes = 0; }
            if (seconds === void 0) { seconds = 0; }
            var time = (hours * 3600 + minutes * 60 + seconds) * 1000;
            return time;
        };
        /**
         * 获取一个指定月日时分秒时间戳（毫秒）
         */
        TimeUtil.getTimeStamp2 = function (month, day, hours, minutes, seconds) {
            if (month === void 0) { month = 0; }
            if (day === void 0) { day = 0; }
            if (hours === void 0) { hours = 0; }
            if (minutes === void 0) { minutes = 0; }
            if (seconds === void 0) { seconds = 0; }
            var date = new Date(qmr.ServerTime.serverTime);
            date.setMonth(month - 1);
            date.setDate(day);
            date.setHours(hours);
            date.setMinutes(minutes);
            date.setSeconds(seconds);
            date.setMilliseconds(0);
            return date.getTime();
        };
        /**
         * 获取一个指定年月日时分秒时间戳（毫秒）
         */
        TimeUtil.getTimeStamp3 = function (year, month, day, hours, minutes, seconds) {
            if (year === void 0) { year = 0; }
            if (month === void 0) { month = 0; }
            if (day === void 0) { day = 0; }
            if (hours === void 0) { hours = 0; }
            if (minutes === void 0) { minutes = 0; }
            if (seconds === void 0) { seconds = 0; }
            var date = new Date();
            date.setFullYear(year);
            date.setMonth(month - 1);
            date.setDate(day);
            date.setHours(hours);
            date.setMinutes(minutes);
            date.setSeconds(seconds);
            date.setMilliseconds(0);
            return date.getTime();
        };
        /**
         * 获取当前服务器时间是周几
         */
        TimeUtil.getCurDay = function () {
            var date = new Date(qmr.ServerTime.serverTime);
            var day = date.getDay();
            if (day == 0)
                day = 7;
            return day;
        };
        /**
        * 获取指定时 分 服务器所在的时间戳(毫秒)
        * @param hour
        * @param minutes
        */
        TimeUtil.getTimeStamp = function (hour, minutes) {
            var date = new Date(qmr.ServerTime.serverTime);
            date.setHours(hour);
            date.setMinutes(minutes);
            date.setSeconds(0);
            date.setMilliseconds(0);
            return date.getTime();
        };
        /**
         * 获取距离当前时间间隔天数的时间戳
         */
        TimeUtil.getDayTimeStamp = function (addDay) {
            var timeStamp = qmr.ServerTime.serverTime + addDay * 24 * 60 * 60 * 1000;
            return timeStamp;
        };
        /**
        * 获取指定时 分 指定时间点所在的时间戳(毫秒)
        * @param hour
        * @param minutes
        */
        TimeUtil.getTimeStampByTime = function (timeStamp, hour, minutes) {
            var date = new Date(timeStamp);
            date.setHours(hour);
            date.setMinutes(minutes);
            date.setSeconds(0);
            date.setMilliseconds(0);
            return date.getTime();
        };
        /**
         *获取日期之间相距的天数
         * @param startDate
         * @param endDate
         * @return
         *
         */
        TimeUtil.getBetweenDays = function (endTime, startTime) {
            return this.getTotalDaysByTime(endTime) - this.getTotalDaysByTime(startTime);
        };
        /**
        *获取经过的总天数。距离 1970 年 1 月 1 日
        * @param date
        * @return
        *
        */
        TimeUtil.getTotalDays = function (date) {
            var localTimeZone = -8;
            return Math.floor(date.getTime() - localTimeZone * 60 * 60 * 1000) / (24 * 60 * 60 * 1000);
        };
        /**
         *获取经过的总天数。距离 1970 年 1 月 1 日
         * @param time	毫秒级时间
         * @return
         *
         */
        TimeUtil.getTotalDaysByTime = function (time) {
            var localTimeZone = -8;
            return Math.floor((time - localTimeZone * 60 * 60 * 1000) / (24 * 60 * 60 * 1000));
        };
        /**
         * 把一个时间戳转化为年月日
         */
        TimeUtil.getTimeNoHourSecond = function (time) {
            var date = new Date(time);
            var toDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            return toDate.getTime();
        };
        /** 不足两位补0 */
        TimeUtil.getZeroize = function (time) {
            return (time < 10) ? "0" + time : time + "";
        };
        /** 去掉小时，分，秒今天的时间戳 */
        TimeUtil.getTodayStartTime = function () {
            return TimeUtil.getTimeNoHourSecond(qmr.ServerTime.serverTime);
        };
        /**
         * 时间格式拆分返回
         * timeStr  --"2018-10-19 19:07:00"
         */
        TimeUtil.getTimesplit = function (timeStr) {
            var timeObj = {};
            var timeArr = timeStr.split(" ");
            var timeStr1 = timeArr[0];
            var timeStr2 = timeArr[1];
            var timeStr1Arr = timeStr1.split("-");
            timeObj["year"] = parseInt(timeStr1Arr[0]);
            timeObj["month"] = parseInt(timeStr1Arr[1]);
            timeObj["day"] = parseInt(timeStr1Arr[2]);
            var timeStr2Arr = timeStr2.split(":");
            timeObj["hour"] = parseInt(timeStr2Arr[0]);
            timeObj["minute"] = parseInt(timeStr2Arr[1]);
            timeObj["second"] = parseInt(timeStr2Arr[2]);
            return timeObj;
        };
        /**
         * 获取今天凌晨的时间戳（昨晚12点）
         */
        TimeUtil.fun10 = function () {
            var today = new Date();
            return today.getTime() - today.getHours() * 60 * 60 * 1000 - today.getMinutes() * 60 * 1000 - today.getSeconds() * 1000 - today.getMilliseconds();
        };
        /** 根据年月日获取星期几 0表示星期日,1表示星期一*/
        TimeUtil.getWeekByTime = function (year, month, day) {
            if (month == 1 || month == 2) {
                month += 12;
                --year;
            }
            var week = (day + 2 * month + Math.floor(3 * (month + 1) / 5) + year +
                Math.floor(year / 4) - Math.floor(year / 100) + Math.floor(year / 400) + 1) % 7;
            return week;
        };
        /** 根据年月日获取星期几 0表示星期日,1表示星期一*/
        TimeUtil.getWeekByTimeStr = function (year, month, day) {
            var week = TimeUtil.getWeekByTime(year, month, day);
            var weekStr = "";
            switch (week) {
                case 1:
                    weekStr = "星期一";
                    break;
                case 2:
                    weekStr = "星期二";
                    break;
                case 3:
                    weekStr = "星期三";
                    break;
                case 4:
                    weekStr = "星期四";
                    break;
                case 5:
                    weekStr = "星期五";
                    break;
                case 6:
                    weekStr = "星期六";
                    break;
                case 0:
                    weekStr = "星期日";
                    break;
            }
            return weekStr;
        };
        /** 一天的毫秒数 **/
        TimeUtil.DAY_MICRO_SECONDS = 24 * 3600 * 1000;
        /** 一小时的毫秒数 **/
        TimeUtil.HOUR_MICRO_SECONDS = 3600 * 1000;
        /** 一分钟的毫秒数 **/
        TimeUtil.MINUTE_MICRO_SECONDS = 60 * 1000;
        /** 一秒钟的毫秒数 **/
        TimeUtil.SECOND_MICRO_SECONDS = 1000;
        /** 年 **/
        TimeUtil.CN_YEAR = "年";
        /** 月 **/
        TimeUtil.CN_MONTH = "月";
        /** 日 **/
        TimeUtil.CN_SUN = "日";
        /** 天 **/
        TimeUtil.CN_DAY = "天";
        /** 小时 **/
        TimeUtil.CN_HOUR = "小时";
        /** 分 **/
        TimeUtil.CN_MIN = "分";
        /** 秒 **/
        TimeUtil.CN_SEC = "秒";
        return TimeUtil;
    }());
    qmr.TimeUtil = TimeUtil;
    __reflect(TimeUtil.prototype, "qmr.TimeUtil");
})(qmr || (qmr = {}));
var TimeUtil = qmr.TimeUtil;
//# sourceMappingURL=TimeUtil.js.map