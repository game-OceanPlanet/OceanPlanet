var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var LabelUtil = (function () {
        function LabelUtil() {
        }
        LabelUtil.setLabelText = function (lab, key) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            var msg = qmr.ConfigManagerAft.getCNValue(key);
            if (args && args.length > 0) {
                args.unshift(msg);
                msg = qmr.StringUtils.getmsg.apply(qmr.StringUtils, args);
            }
            lab.textFlow = qmr.HtmlUtil.htmlParse.parser(msg);
        };
        LabelUtil.setLabel = function (lab, msg, isGray) {
            if (isGray === void 0) { isGray = false; }
            if (msg) {
                msg = qmr.StringUtils.getSectionMsg(msg);
                var textElement = qmr.HtmlUtil.htmlParse.parser(msg);
                if (isGray) {
                    var count = textElement.length;
                    for (var i = 0; i < count; i++) {
                        var t = textElement[i];
                        if (t.style)
                            t.style.textColor = 0x78685f;
                        else
                            t.style = { textColor: 0x78685f };
                    }
                }
                lab.textFlow = textElement;
            }
            else {
                lab.text = "";
            }
        };
        /** 设置次数样式 */
        LabelUtil.setLabelCount = function (lab, msg, count, pre) {
            if (pre === void 0) { pre = false; }
            var textColor = count > 0 ? qmr.ColorQualityConst.COLOR_GREEN : qmr.ColorQualityConst.COLOR_RED;
            var txt = "<font color='" + textColor + "'>" + count + "</font>";
            lab.textFlow = qmr.HtmlUtil.htmlParse.parser(pre ? txt + msg : msg + txt);
        };
        /** 设置次数样式 */
        LabelUtil.setLabelCount2 = function (lab, msg, count, pre) {
            if (pre === void 0) { pre = false; }
            var textColor = count > 0 ? qmr.ColorQualityConst.COLOR_RED : qmr.ColorQualityConst.COLOR_GREEN;
            var txt = "<font color='" + textColor + "'>" + count + "</font>";
            lab.textFlow = qmr.HtmlUtil.htmlParse.parser(pre ? txt + msg : msg + txt);
        };
        /** 设置超链接文本 */
        LabelUtil.addLabelEvent = function (label, callBack, thisObject, key) {
            if (key === void 0) { key = ""; }
            var args = [];
            for (var _i = 4; _i < arguments.length; _i++) {
                args[_i - 4] = arguments[_i];
            }
            var msg = "";
            if (args == undefined || args.length == 0) {
                var labName = "<u>" + label.text + "</u>";
                args = [label.hashCode, labName];
            }
            if (key == "")
                key = "CN_119";
            msg = qmr.ConfigManagerAft.getCNValue(key);
            if (args && args.length > 0) {
                args.unshift(msg);
                msg = qmr.StringUtils.getmsg.apply(qmr.StringUtils, args);
            }
            label.textFlow = qmr.HtmlUtil.htmlParse.parser(msg);
            if (label.hasEventListener(egret.TextEvent.LINK))
                return;
            if (callBack) {
                label.addEventListener(egret.TextEvent.LINK, callBack, thisObject);
            }
        };
        LabelUtil.removeLabelEvent = function (label, callBack, thisObject) {
            if (label) {
                label.name = "";
                label.removeEventListener(egret.TextEvent.LINK, callBack, thisObject);
            }
        };
        LabelUtil.addInputListener = function (textInput, thisObject) {
            textInput.addEventListener(egret.FocusEvent.FOCUS_IN, LabelUtil.focusInTxtHandler, thisObject);
            textInput.addEventListener(egret.FocusEvent.FOCUS_OUT, LabelUtil.focusInTxtHandler, thisObject);
        };
        LabelUtil.removeInputListener = function (textInput, thisObject) {
            textInput.addEventListener(egret.FocusEvent.FOCUS_IN, LabelUtil.focusInTxtHandler, thisObject);
            textInput.addEventListener(egret.FocusEvent.FOCUS_OUT, LabelUtil.focusInTxtHandler, thisObject);
        };
        LabelUtil.focusInTxtHandler = function () {
            var inputFocus = function () {
                if (document && document.body) {
                    setTimeout(function () {
                        if (window.scrollTo) {
                            window.scrollTo(0, document.body.clientHeight);
                        }
                    }, 400);
                }
            };
            inputFocus();
        };
        return LabelUtil;
    }());
    qmr.LabelUtil = LabelUtil;
    __reflect(LabelUtil.prototype, "qmr.LabelUtil");
})(qmr || (qmr = {}));
//# sourceMappingURL=LabelUtil.js.map