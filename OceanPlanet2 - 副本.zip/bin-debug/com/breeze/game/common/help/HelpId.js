var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    var HelpId = (function () {
        function HelpId() {
        }
        /** 兑换面板帮助说明*/
        HelpId.ID_1 = 1;
        /** 兑换面板帮助说明*/
        HelpId.ID_2 = 2;
        /** 兑换面板帮助说明*/
        HelpId.ID_3 = 3;
        /** 兑换面板帮助说明*/
        HelpId.ID_4 = 4;
        /** 兑换面板帮助说明*/
        HelpId.ID_5 = 5;
        /** 兑换面板帮助说明*/
        HelpId.ID_6 = 6;
        return HelpId;
    }());
    qmr.HelpId = HelpId;
    __reflect(HelpId.prototype, "qmr.HelpId");
})(qmr || (qmr = {}));
//# sourceMappingURL=HelpId.js.map