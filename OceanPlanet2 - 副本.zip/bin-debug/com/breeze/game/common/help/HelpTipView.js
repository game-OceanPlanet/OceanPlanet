var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var HelpTipView = (function (_super) {
        __extends(HelpTipView, _super);
        function HelpTipView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "HelpTipSkin";
            _this.isNeedMask = true;
            return _this;
        }
        HelpTipView.prototype.initComponent = function () {
            var t = this;
            _super.prototype.initComponent.call(this);
        };
        HelpTipView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var t = this;
            t.updateView();
        };
        HelpTipView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnClose, t.closeView, t);
        };
        HelpTipView.prototype.updateView = function () {
            var t = this;
            var id = t.data;
            if (!id) {
                return;
            }
            var cfg = qmr.ConfigManager.getConf(qmr.ConfigEnum.HELPTIP, id);
            if (cfg) {
                t.txt_title.text = cfg.title;
                t.txt_content.textFlow = qmr.HtmlUtil.getHtmlString(cfg.param);
            }
        };
        HelpTipView.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
        };
        return HelpTipView;
    }(qmr.BaseModule));
    qmr.HelpTipView = HelpTipView;
    __reflect(HelpTipView.prototype, "qmr.HelpTipView");
})(qmr || (qmr = {}));
//# sourceMappingURL=HelpTipView.js.map