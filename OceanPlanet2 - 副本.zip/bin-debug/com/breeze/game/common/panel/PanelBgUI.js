var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * 通用背景
     */
    var PanelBgUI = (function (_super) {
        __extends(PanelBgUI, _super);
        function PanelBgUI() {
            var _this = _super.call(this) || this;
            _this._isChangeTitle = true; //一些特殊的活动不用更新标题
            _this.skinName = "PanelBg";
            _this.registerNotify(qmr.NotifyConstLogin.UPDATE_MODULE_TITLE, _this.onUpdateName);
            return _this;
        }
        PanelBgUI.prototype.initComponent = function () {
            this.lbl_title.text = this._title;
        };
        PanelBgUI.prototype.addedToStage = function (evt) {
            _super.prototype.addedToStage.call(this, evt);
            if (this._isChangeTitle) {
                this.registerNotify(qmr.NotifyConstLogin.UPDATE_MODULE_TITLE, this.onUpdateName);
            }
        };
        PanelBgUI.prototype.removeFromStage = function (evt) {
            _super.prototype.removeFromStage.call(this, evt);
            if (this._isChangeTitle) {
                this.unRegisterNotify(qmr.NotifyConstLogin.UPDATE_MODULE_TITLE, this.onUpdateName);
            }
        };
        PanelBgUI.prototype.onUpdateName = function (t) {
            if (t.owner) {
                if (t.owner instanceof qmr.BaseModule) {
                    if (!t.owner.contains(this)) {
                        return;
                    }
                }
                else {
                    var tParent = this.parent;
                    var moduleName = void 0;
                    while (tParent) {
                        if (tParent instanceof qmr.BaseModule) {
                            moduleName = tParent.moduleName;
                            if (moduleName && moduleName != t.owner.moduleName) {
                                return;
                            }
                            break;
                        }
                        tParent = tParent.parent;
                    }
                }
            }
            if (!this._isChangeTitle) {
                this.unRegisterNotify(qmr.NotifyConstLogin.UPDATE_MODULE_TITLE, this.onUpdateName);
                return;
            }
            if (t.title != undefined) {
                if (t.title == "") {
                    this.lbl_title.visible = false;
                }
                else {
                    this.title = t.title;
                }
            }
            if (t.ruleId && t.ruleId > 0) {
            }
            else {
            }
        };
        Object.defineProperty(PanelBgUI.prototype, "title", {
            /** 设置标题之后不在更新 */
            set: function (value) {
                this._title = value;
                if (this.lbl_title && this.isSkinLoaded) {
                    this.lbl_title.text = value;
                    this.lbl_title.visible = true;
                }
            },
            enumerable: true,
            configurable: true
        });
        /** 设置标题之后不在更新 */
        PanelBgUI.prototype.onUpdateNameNoChange = function (title) {
            this.title = title;
            this._isChangeTitle = false;
            this.unRegisterNotify(qmr.NotifyConstLogin.UPDATE_MODULE_TITLE, this.onUpdateName);
        };
        return PanelBgUI;
    }(qmr.UIComponent));
    qmr.PanelBgUI = PanelBgUI;
    __reflect(PanelBgUI.prototype, "qmr.PanelBgUI");
})(qmr || (qmr = {}));
//# sourceMappingURL=PanelBgUI.js.map