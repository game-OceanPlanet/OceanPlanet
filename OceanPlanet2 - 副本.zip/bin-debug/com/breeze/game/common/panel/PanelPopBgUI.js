var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * 通用背景
     */
    var PanelPopBgUI = (function (_super) {
        __extends(PanelPopBgUI, _super);
        function PanelPopBgUI() {
            var _this = _super.call(this) || this;
            _this.skinName = "PanelPopBg";
            return _this;
        }
        PanelPopBgUI.prototype.initComponent = function () {
            this.lbl_title.text = this._title;
        };
        Object.defineProperty(PanelPopBgUI.prototype, "title", {
            /** 设置标题之后不在更新 */
            set: function (value) {
                this._title = value;
                if (this.lbl_title) {
                    this.lbl_title.text = value;
                    this.lbl_title.visible = true;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PanelPopBgUI.prototype, "bottomTips", {
            /**
             * set bottomTip
             */
            set: function (value) {
                this.lbl_bottom.visible = value;
            },
            enumerable: true,
            configurable: true
        });
        return PanelPopBgUI;
    }(qmr.UIComponent));
    qmr.PanelPopBgUI = PanelPopBgUI;
    __reflect(PanelPopBgUI.prototype, "qmr.PanelPopBgUI");
})(qmr || (qmr = {}));
//# sourceMappingURL=PanelPopBgUI.js.map