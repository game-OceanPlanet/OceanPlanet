var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PromptView = (function (_super) {
        __extends(PromptView, _super);
        function PromptView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "PromptSkin";
            _this.isNeedMask = true;
            return _this;
        }
        PromptView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var data = this.data;
            if (data) {
                this.checkbox.selected = false;
                this.showPrompt(data.type, data.title, data.content, data.confirmFun, data.caller, data.confirmData, data.cancelFun, data.confirmTxt, data.cancelTxt, data.cacheKey);
            }
        };
        PromptView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.btnSure.scaleX = t.btnSure.scaleY = 1.0;
            t.btnCancel.scaleX = t.btnCancel.scaleY = 1.0;
            t.addClickEvent(t.btnSure, t.onConfirm, t);
            t.addClickEvent(t.btnCancel, t.onClickCancle, t);
            t.addClickEvent(t.btnClose, t.onClickCancle, t);
            t.addEvent(t.checkbox, egret.Event.CHANGE, t.onCheckChange, t);
        };
        PromptView.prototype.showPrompt = function (type, title, content, confirmFun, caller, confirmData, cancelFun, confirmTxt, cancelTxt, cacheKey) {
            if (type === void 0) { type = AlertEnumType.GB; }
            if (type == AlertEnumType.GB) {
                this.btnCancel.visible = true;
                this.btnSure.x = 381;
            }
            else {
                this.btnCancel.visible = false;
                this.btnSure.x = 296;
            }
            this.confirmFun = confirmFun;
            this.caller = caller;
            this.cancelFun = cancelFun;
            this.confirmData = confirmData;
            this.cacheKey = cacheKey;
            if (!cacheKey || cacheKey == "") {
                this.checkbox.visible = false;
            }
            else {
                this.checkbox.visible = true;
            }
            this.txt_title.text = title;
            qmr.LabelUtil.setLabel(this.labContent, content);
            if (confirmTxt) {
                this.txt_sure.text = confirmTxt;
            }
            if (cancelTxt) {
                this.txt_cancel.text = cancelTxt;
            }
        };
        /** 确定购买 */
        PromptView.prototype.onConfirm = function () {
            var func = this.confirmFun;
            var caller = this.caller;
            var funcData = this.confirmData;
            if (func) {
                egret.callLater(function () {
                    func.apply(caller, [funcData]);
                }, this);
            }
            this.onClose();
        };
        /** 取消购买 */
        PromptView.prototype.onClickCancle = function () {
            if (this.cancelFun) {
                this.cancelFun.apply(this.caller);
            }
            this.onClose();
        };
        PromptView.prototype.onCheckChange = function () {
            if (this.cacheKey && this.cacheKey != "") {
                qmr.CacheManager.setOneCache(this.cacheKey, this.checkbox.selected ? 1 : 0);
            }
        };
        PromptView.prototype.onClose = function () {
            this.confirmFun = null;
            this.cancelFun = null;
            this.caller = null;
            this.confirmData = null;
            this.hide();
        };
        return PromptView;
    }(qmr.BaseModule));
    qmr.PromptView = PromptView;
    __reflect(PromptView.prototype, "qmr.PromptView");
    /**弹框按钮类型*/
    var AlertEnumType;
    (function (AlertEnumType) {
        /**有确定和取消两个选择*/
        AlertEnumType[AlertEnumType["GB"] = 1] = "GB";
        /**只有确定按钮*/
        AlertEnumType[AlertEnumType["UN_GB"] = 2] = "UN_GB";
    })(AlertEnumType = qmr.AlertEnumType || (qmr.AlertEnumType = {}));
})(qmr || (qmr = {}));
//# sourceMappingURL=PromptView.js.map