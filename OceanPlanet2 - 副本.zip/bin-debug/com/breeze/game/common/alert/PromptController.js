var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * 通用弹框控制器
     */
    var PromptController = (function () {
        function PromptController() {
        }
        /**
         * 弹框
         * @param  {string} content 显示的内容
         * @param  {Function} confirmFun 确定回调函数
         * @param  {any} caller? 回调作用域
         * @param  {any} confirmData? 确定附带回调数据
         * @param  {Function} cancelFun? 取消回调函数
         * @param  {AlertEnumType=AlertEnumType.GB} type GB = 1： 有确定和取消两个选择 ， UN_GB = 2： 只有确定btn ，确定或取消的逻辑由后面自定义参数 confirmFun cancelFun
         * @param  {string="提示"} title 提示标题
         * @param  {string} confirmTxt? 确定按钮文本
         * @param  {string} cancelTxt? 取消按钮文本
         * @param  {string} cacheKey? 本次登录不提示
         * @returns void
         */
        PromptController.prototype.showPrompt = function (content, confirmFun, caller, confirmData, cancelFun, type, title, confirmTxt, cancelTxt, cacheKey) {
            if (type === void 0) { type = qmr.AlertEnumType.GB; }
            if (title === void 0) { title = "提示"; }
            if (confirmTxt === void 0) { confirmTxt = "确定"; }
            if (cancelTxt === void 0) { cancelTxt = "取消"; }
            //构建要传递的数据
            var data = {};
            data.title = title;
            data.content = content;
            data.type = type;
            data.confirmFun = confirmFun;
            data.cancelFun = cancelFun;
            data.caller = caller;
            data.confirmData = confirmData;
            data.confirmTxt = confirmTxt;
            data.cancelTxt = cancelTxt;
            data.cacheKey = cacheKey;
            //本次登录不提示
            if (cacheKey && qmr.CacheManager.getOneCache(cacheKey, 0)) {
                egret.callLater(confirmFun, caller, confirmData);
            }
            else {
                qmr.ModuleManager.popModule(qmr.ModuleNameConst.PROMPT_VIEW, data, null, false, false);
            }
        };
        /**
         
         * @returns void
         */
        /**
         *
         * 弹框
         * @param  {string} content 显示的内容
         * @param  {Function} confirmFun 确定回调函数
         * @param  {any} caller? 回调作用域
         * @param  {any} confirmData? 确定附带回调数据
         * @param  {Function} cancelFun? 取消回调函数
         * @param  {string="提示"} title 提示标题
         * @param  {string} confirmTxt? 确定按钮文本
         * @param  {number} max? 输入框最大输入数量
         * @param  {number} min? 输入框最小输入数量
         * @param  {number} price? 单价
         * @param  {number} total? 拥有数量
         */
        PromptController.prototype.showPromptInput = function (content, confirmFun, caller, confirmData, cancelFun, title, confirmTxt, max, min, price, total) {
            if (title === void 0) { title = "提示"; }
            if (confirmTxt === void 0) { confirmTxt = "确定"; }
            //构建要传递的数据
            var data = {};
            data.title = title;
            data.content = content;
            data.confirmFun = confirmFun;
            data.cancelFun = cancelFun;
            data.caller = caller;
            data.confirmData = confirmData;
            data.confirmTxt = confirmTxt;
            data.max = max;
            data.min = min;
            data.price = price;
            data.total = total;
            qmr.ModuleManager.popModule(qmr.ModuleNameConst.PROMPT_INPUT_VIEW, data, null, false, false);
        };
        Object.defineProperty(PromptController, "instance", {
            get: function () {
                return this._instance || (this._instance = new PromptController());
            },
            enumerable: true,
            configurable: true
        });
        return PromptController;
    }());
    qmr.PromptController = PromptController;
    __reflect(PromptController.prototype, "qmr.PromptController");
})(qmr || (qmr = {}));
//# sourceMappingURL=PromptController.js.map