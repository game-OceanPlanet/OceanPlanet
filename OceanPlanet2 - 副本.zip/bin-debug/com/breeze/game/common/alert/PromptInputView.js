var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var PromptInputView = (function (_super) {
        __extends(PromptInputView, _super);
        function PromptInputView() {
            var _this = _super.call(this) || this;
            _this.qmrSkinName = "PromptInputSkin";
            _this.isNeedMask = true;
            return _this;
        }
        PromptInputView.prototype.initData = function () {
            _super.prototype.initData.call(this);
            var data = this.data;
            if (data) {
                this.showPrompt(data.title, data.content, data.confirmFun, data.caller, data.confirmData, data.cancelFun, data.confirmTxt, data.max, data.min, data.price, data.total);
            }
            this.txt_price.text = "0";
            this.txt_account.text = "";
        };
        PromptInputView.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
            var t = this;
            t.addClickEvent(t.btnSure, t.onConfirm, t);
            t.addClickEvent(t.btnClose, t.onClickCancle, t);
            t.addEvent(t.txt_account, egret.Event.CHANGE, t.onTextInputChange, t);
            t.txt_account.restrict = "0-9";
        };
        PromptInputView.prototype.onTextInputChange = function (evt) {
            var t = this;
            var str = evt.target.text;
            if (qmr.RegexpUtil.IsNull(str)) {
                return;
            }
            if (!qmr.RegexpUtil.IsInteger(str)) {
                return;
            }
            var num = parseInt(str.trim());
            if (t.max) {
                if (num > t.max) {
                    qmr.TipManagerCommon.getInstance().createCommonTip("输入数量不能大于可购买总量");
                    return;
                }
            }
            if (t.min) {
                if (num < t.min) {
                    qmr.TipManagerCommon.getInstance().createCommonTip("输入数量不能小于最小购买数量");
                    return;
                }
            }
            if (t.total) {
                if (num > t.total) {
                    qmr.TipManagerCommon.getInstance().createCommonTip("输入的数量不能大于拥有的总量");
                    return;
                }
            }
            if (!t.price) {
                return;
            }
            t.txt_price.text = num * t.price + "";
        };
        PromptInputView.prototype.showPrompt = function (title, content, confirmFun, caller, confirmData, cancelFun, confirmTxt, max, min, price, total) {
            this.confirmFun = confirmFun;
            this.caller = caller;
            this.cancelFun = cancelFun;
            this.confirmData = confirmData;
            this.max = max;
            this.min = min;
            this.price = price;
            this.total = total;
            this.txt_title.text = title;
            qmr.LabelUtil.setLabel(this.labContent, content);
            if (confirmTxt) {
                this.txt_sure.text = confirmTxt;
            }
        };
        /** 确定购买 */
        PromptInputView.prototype.onConfirm = function () {
            var t = this;
            var func = this.confirmFun;
            var caller = this.caller;
            var funcData = this.confirmData;
            var txt = t.txt_account.text;
            if (qmr.RegexpUtil.IsNull(txt)) {
                return;
            }
            if (!qmr.RegexpUtil.IsInteger(txt)) {
                return;
            }
            var count = Number(txt.trim());
            if (count <= 0) {
                qmr.TipManagerCommon.getInstance().createCommonTip("请重新输入数量");
                return;
            }
            if (this.max) {
                if (count > this.max) {
                    qmr.TipManagerCommon.getInstance().createCommonTip("输入数量不能大于：" + this.max);
                    return;
                }
            }
            if (this.min) {
                if (count < this.min) {
                    qmr.TipManagerCommon.getInstance().createCommonTip("输入数量不能小于：" + this.max);
                    return;
                }
            }
            if (func) {
                egret.callLater(function () {
                    func.apply(caller, [count]);
                }, this);
            }
            this.onClose();
        };
        /** 取消购买 */
        PromptInputView.prototype.onClickCancle = function () {
            if (this.cancelFun) {
                this.cancelFun.apply(this.caller);
            }
            this.onClose();
        };
        PromptInputView.prototype.onClose = function () {
            this.confirmFun = null;
            this.cancelFun = null;
            this.caller = null;
            this.confirmData = null;
            this.hide();
        };
        return PromptInputView;
    }(qmr.BaseModule));
    qmr.PromptInputView = PromptInputView;
    __reflect(PromptInputView.prototype, "qmr.PromptInputView");
})(qmr || (qmr = {}));
//# sourceMappingURL=PromptInputView.js.map