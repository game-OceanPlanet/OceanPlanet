var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var qmr;
(function (qmr) {
    /**
     * coler
     * @desc 漂字提示管理器
     */
    var FloatManager = (function () {
        function FloatManager() {
        }
        /**
         * 创建一个飘血的提示
         * @param  hurtType类型，1代表自己被攻击，0代表别的物体被攻击,2代表加血,3代表buff,4代表反伤
         * @param hp 变更血量
         * @param x 飘字X坐标
         * @param y 飘字Y坐标
         * @param dir 飘字方向
         * @param buffName buff名字，如果是BUFF才有效
         */
        FloatManager.createFloatHp = function (hurtType, hp, x, y, times, dir, buffName) {
            if (times === void 0) { times = 1; }
            if (dir === void 0) { dir = 0; }
            if (buffName === void 0) { buffName = ""; }
            // if (times <= 1)
            // {
            // 	let floatHp: FloatHpTxt = FloatPool.getInstance().createFloatHp();
            // 	floatHp.flyUp(hurtType, hp, x, y, dir, buffName);
            // } else
            // {
            // 	new MultiFloatHp(hurtType, hp, x, y, times, dir);
            // }
        };
        return FloatManager;
    }());
    qmr.FloatManager = FloatManager;
    __reflect(FloatManager.prototype, "qmr.FloatManager");
})(qmr || (qmr = {}));
//# sourceMappingURL=FloatManager.js.map