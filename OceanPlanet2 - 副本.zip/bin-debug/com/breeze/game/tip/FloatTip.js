var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     * @author eric
     * @desc 飘浮提示
     */
    var FloatTip = (function (_super) {
        __extends(FloatTip, _super);
        function FloatTip() {
            var _this = _super.call(this) || this;
            _this.iscompleted = false;
            _this.isSeted = false;
            _this.skinName = "FloatTipSkin";
            return _this;
        }
        FloatTip.prototype.initComponent = function () {
            _super.prototype.initComponent.call(this);
            this.iscompleted = true;
            // this.lbl_tips.strokeColor = ColorConst.COLOR_BLACK;
            // this.lbl_tips.stroke = 0.5;
            //this.bgd.visible = false;
            //this.lbl_tipMsg0.visible = true;
            this.touchEnabled = this.touchChildren = false;
        };
        FloatTip.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
        };
        FloatTip.prototype.initData = function () {
            _super.prototype.initData.call(this);
            this.setTip();
        };
        FloatTip.prototype.onStageResize = function () {
            _super.prototype.onStageResize.call(this);
            this.width = qmr.StageUtil.stageWidth;
        };
        FloatTip.prototype.showTip = function (data) {
            this.data = data;
            if (this.iscompleted) {
                this.setTip();
            }
        };
        FloatTip.prototype.setTip = function () {
            var t = this;
            if (!t.data)
                return;
            if (t.isSeted)
                return;
            t.isSeted = true;
            t.alpha = 1;
            t.lbl_tips.textFlow = qmr.HtmlUtil.htmlParse.parser(t.data.mess);
            t.y = t.data.yPos ? t.data.yPos : qmr.StageUtil.stageHeight / 2 - t.height / 2;
            var offset = t.y - 60;
            if (t.data.itemcfg) {
                qmr.ImageUtil.setItemIcon(t.img_icon, t.data.itemcfg.icon, t.data.itemcfg.page);
            }
            egret.Tween.get(t)
                .to({ y: offset }, 800)
                .wait(50)
                .to({ y: offset - 30, alpha: 0 }, 400)
                .call(t.dispose, t);
        };
        FloatTip.prototype.dispose = function () {
            this.data = null;
            this.isSeted = false;
            this.lbl_tips.textFlow = [];
            this.img_icon.source = null;
            _super.prototype.dispose.call(this);
            egret.Tween.removeTweens(this);
        };
        return FloatTip;
    }(qmr.UIComponent));
    qmr.FloatTip = FloatTip;
    __reflect(FloatTip.prototype, "qmr.FloatTip");
})(qmr || (qmr = {}));
//# sourceMappingURL=FloatTip.js.map