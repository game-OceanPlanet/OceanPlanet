var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    /**
     *
     * @author coler
     * @description 飘血动画
     *
     */
    var FloatHpTxt = (function (_super) {
        __extends(FloatHpTxt, _super);
        function FloatHpTxt() {
            var _this = _super.call(this) || this;
            _this.touchEnabled = _this.touchChildren = false;
            _this.txt_hp = new eui.BitmapLabel();
            _this.txt_hp.letterSpacing = -5;
            _this.addChild(_this.txt_hp);
            return _this;
        }
        /**
         * @description 飘血/加血
         * @param  hurtType类型，1代表自己被攻击，0代表别的物体被攻击,2代表加血,3代表buff,4代表反伤
         * @param hp 变更血量
         * @param x 飘字X坐标
         * @param y 飘字Y坐标
         * @param dir 飘字方向
         * @param buffName buff名字，如果是BUFF才有效
         */
        FloatHpTxt.prototype.flyUp = function (hurtType, hp, x, y, dir, buffName) {
            if (dir === void 0) { dir = 0; }
            if (buffName === void 0) { buffName = ""; }
            var t = this;
            var txt_hp = t.txt_hp;
            var len = hp.toString().length;
            txt_hp.text = '';
            switch (hurtType) {
            }
            //console.log("FloatHpTxt:",txt_hp.font, txt_hp.text);
            t.x = x;
            t.y = y + 50;
            t.anchorOffsetX = t.txt_hp.width >> 1;
            t.anchorOffsetY = t.txt_hp.height >> 1;
            t.scaleX = t.scaleY = 1;
            var mx = t.x;
            var my = t.y;
            var ran = Math.floor(Math.random() * 40);
            my -= ran;
            egret.Tween.get(t).to({ x: mx, y: my - 50, scaleX: 2, scaleY: 2 }, 200).wait(50)
                .to({ scaleX: 1, scaleY: 1 }, 200).wait(300)
                .to({ x: mx, y: my - 80, alpha: 0.7 }, 300)
                .to({ x: mx, y: my - 120, alpha: 0 }, 300)
                .call(function () {
                // FloatPool.getInstance().recycleFloatHp(t);
            }, t);
            qmr.SceneManager.instance.addToFront(t);
        };
        return FloatHpTxt;
    }(egret.DisplayObjectContainer));
    qmr.FloatHpTxt = FloatHpTxt;
    __reflect(FloatHpTxt.prototype, "qmr.FloatHpTxt");
})(qmr || (qmr = {}));
//# sourceMappingURL=FloatHpTxt.js.map