var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var qmr;
(function (qmr) {
    var FloatImgLabel = (function (_super) {
        __extends(FloatImgLabel, _super);
        function FloatImgLabel() {
            var _this = _super.call(this) || this;
            _this.iscompleted = false;
            _this.isSeted = false;
            _this.skinName = "FloatImgLabelSkin";
            return _this;
        }
        FloatImgLabel.prototype.initComponent = function () {
            _super.prototype.initComponent.call(this);
            this.bit_label.font = "recovery_fnt";
            this.iscompleted = true;
            this.touchEnabled = false;
            this.x = -64;
        };
        FloatImgLabel.prototype.initListener = function () {
            _super.prototype.initListener.call(this);
        };
        FloatImgLabel.prototype.initData = function () {
            _super.prototype.initData.call(this);
            this.setTip();
        };
        FloatImgLabel.prototype.showTip = function (data) {
            this.data = data;
            if (this.iscompleted) {
                this.setTip();
            }
        };
        FloatImgLabel.prototype.setTip = function () {
            if (!this.data)
                return;
            if (this.isSeted)
                return;
            this.isSeted = true;
            this.alpha = 1;
            this.img_icon.texture = RES.getRes(this.data.icon);
            this.bit_label.text = "+" + this.data.count;
            this.x = -this.width / 2;
            // this.y = -SingleModel.getInstance().sceneModel.hero.actorHeight - 20;
            var offset = this.y - 60;
            egret.Tween.get(this)
                .to({ y: offset }, 800)
                .wait(50)
                .to({ y: offset - 30, alpha: 0 }, 400)
                .call(this.dispose, this);
        };
        FloatImgLabel.prototype.dispose = function () {
            this.data = null;
            this.isSeted = false;
            _super.prototype.dispose.call(this);
            egret.Tween.removeTweens(this);
            // TipManager.getInstance().recycleFloatImgTip(this);
        };
        return FloatImgLabel;
    }(qmr.UIComponent));
    qmr.FloatImgLabel = FloatImgLabel;
    __reflect(FloatImgLabel.prototype, "qmr.FloatImgLabel");
})(qmr || (qmr = {}));
//# sourceMappingURL=FloatImgLabel.js.map