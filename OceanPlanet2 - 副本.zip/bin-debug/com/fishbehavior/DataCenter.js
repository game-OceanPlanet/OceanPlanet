// TypeScript file
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var DataCenter = (function (_super) {
    __extends(DataCenter, _super);
    function DataCenter() {
        var _this = _super.call(this) || this;
        _this.pathJsonData = undefined;
        _this.mPaths = new Array();
        _this.LoadData();
        return _this;
    }
    Object.defineProperty(DataCenter, "Instance", {
        get: function () {
            if (this.m_Instance == null)
                this.m_Instance = new DataCenter();
            return this.m_Instance;
        },
        enumerable: true,
        configurable: true
    });
    DataCenter.clearInstance = function () {
        this.m_Instance.destroy();
        this.m_Instance = null;
    };
    DataCenter.prototype.LoadData = function () {
        this.loadDataFromUrl();
    };
    DataCenter.prototype.calcAngleAndDistance = function (p1, p2) {
        var p2p1x = p2.x - p1.x;
        var p2p1y = p2.y - p1.y;
        var angle = 0;
        if (p2p1x < 0.001 && p2p1x > -0.001) {
            if (p2p1y < 0) {
                angle = 90;
            }
            else {
                angle = 270;
            }
        }
        else {
            angle = Math.atan(p2p1y / p2p1x) * 180;
        }
        var dist = Math.sqrt(p2p1x * p2p1x + p2p1y * p2p1y);
        return { angle: angle, dist: dist };
    };
    DataCenter.prototype.getPathIds = function () {
        var ids = [];
        for (var i = 0; i < this.mPaths.length; i++) {
            ids.push(this.mPaths[i].id);
        }
        return ids;
    };
    //根据索引获取数据;
    DataCenter.prototype.getDataByPathIndex = function (index) {
        return this.mPaths[index];
    };
    //根据ID获取数据;
    DataCenter.prototype.getDataByPathId = function (id) {
        var fpath = undefined;
        this.mPaths.some(function (value) {
            if (value.id = id) {
                fpath = value;
                return true;
            }
            return false;
        });
        return fpath;
    };
    //添加一个数据;
    DataCenter.prototype.addData = function (id, path) {
        for (var _i = 0, _a = this.mPaths; _i < _a.length; _i++) {
            var pathNode = _a[_i];
            if (pathNode.id == id) {
                return false;
            }
        }
        this.mPaths.push({ id: id, path: path });
        return true;
    };
    //修改数据;
    DataCenter.prototype.setData = function (index, id, path) {
        //检查是否由相同的id
        for (var i = 0; i < this.mPaths.length; i++) {
            if (i != index && this.mPaths[i].id == id) {
                return false;
            }
        }
        this.mPaths[index] = { id: id, path: path };
        return true;
    };
    DataCenter.prototype.removeData = function (index) {
        this.mPaths.splice(index, 1);
    };
    DataCenter.prototype.loadDataFromUrl = function () {
        this._url = "resource/table/TableFishPath.json"; //$res.getFishPath();
        if (!RES.hasRes(this._url)) {
            if (this._url != null && RES.hasRes(this._url))
                RES.destroyRes(this._url);
            RES.getResByUrl(this._url, this.loadedComplete, this, RES.ResourceItem.TYPE_JSON);
            // let data: any[] = RES.getRes("TableFishPath_json");
            // this.loadedComplete(data, this._url);
        }
        else {
            var data = RES.getRes(this._url);
            this.loadedComplete(data, this._url);
        }
    };
    DataCenter.prototype.loadedComplete = function (data, url) {
        this.pathJsonData = data;
        //最好在这里加一个时间抛出去，等路径JSON加载完了以后，再去给鱼安装行为管理器
        if (data && this._url == url) {
            egret.log("onLoadUrlComplete!");
            var mPaths = {};
            var len = data.length;
            for (var i = 0; i < len; i++) {
                var node = data[i];
                var id = node.id;
                var path_1 = mPaths[id] || [];
                path_1.push(node);
                mPaths[id] = path_1;
            }
            for (var key in mPaths) {
                if (mPaths.hasOwnProperty(key)) {
                    var path = mPaths[key];
                    DataCenter.Instance.addData(key, path);
                }
            }
        }
        else {
            RES.destroyRes(url);
        }
    };
    DataCenter.prototype.destroy = function () {
    };
    DataCenter.superpositionOption = [];
    //保存远程路径
    DataCenter.SAVE_REMOTE_DATA_URL = "http://172.33.0.2:8090/saveresult.php";
    // http://123.207.4.125/fish/saveresult.php
    //保存成json格式的远程路径
    DataCenter.SAVE_JSON_DATA_URL = "http://172.33.0.2:8090/savejsonresult.php";
    // http://172.33.0.2:8089/platformCfg/baseConfig.json
    // http://172.33.0.2:8090/savejsonresult.php
    // http://123.207.4.125/fish/savejsonresult.php
    //读取远程路径
    DataCenter.LOAD_REMOTE_DATA_URL = "http://123.207.4.125/fish/loadresult.php";
    //下载配置
    DataCenter.DOWNLOAD_CONFIG_URL = "http://123.207.4.125/fish/pathresult.csv";
    return DataCenter;
}(egret.EventDispatcher));
__reflect(DataCenter.prototype, "DataCenter");
//# sourceMappingURL=DataCenter.js.map